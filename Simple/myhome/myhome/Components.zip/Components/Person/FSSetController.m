//
//  FSSetController.m
//  myhome
//
//  Created by FudonFuchina on 2016/12/19.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSSetController.h"
#import "FSCacheManager.h"
#import "FSAccountConfiger.h"
#import "FSTuple.h"
#import "FSGestureController.h"
#import "FSAppConfig.h"
#import "FSUIKit.h"
#import "FSToast.h"
#import "FSMacro.h"
#import "FSTrackKeys.h"

@interface FSSetController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) NSArray        *datas;

@end

@implementation FSSetController{
    UITableViewCell     *_firstCell;
    Tuple2              *_t1;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Set", nil);
    [self setHandleDatas];
    [FSTrack event:_UMeng_Event_set];
}

- (void)setHandleDatas{
    NSString *mail = [FSAppConfig objectForKey:_appCfg_receivedEmail];
    if (!_fs_isValidateString(mail)) {
        mail = NSLocalizedString(@"You can config an email", nil);
    }
    Tuple2 *t2 = [Tuple2 v1:NSLocalizedString(@"Config email", nil) v2:mail];
    
    NSString *pdfPwd = [FSAppConfig objectForKey:_appCfg_pdfPassword];
    if (!_fs_isValidateString(pdfPwd)) {
        pdfPwd = NSLocalizedString(@"You can config a password", nil);
    }
    Tuple2 *t3 = [Tuple2 v1:NSLocalizedString(@"The password for Pdf file", nil) v2:pdfPwd];
    
    BOOL g = [FSGestureController hasSettedPassword];
    NSString *ges = nil;
    if (g) {
        ges = NSLocalizedString(@"Update gesture code", nil);
    }else{
        ges = NSLocalizedString(@"Unset", nil);
    }
    Tuple2 *t4 = [Tuple2 v1:NSLocalizedString(@"Gesture code", nil) v2:ges];
    
    if (!_t1) {
        _t1 = [Tuple2 v1:NSLocalizedString(@"Clear cache", nil) v2:NSLocalizedString(@"Count...", nil)];
    }
    
    NSString *lockTime = [FSAppConfig objectForKey:_appCfg_lockTime];
    NSString *ltShow = [[NSString alloc] initWithFormat:@"%ld s",lockTime.integerValue];
    Tuple2 *t5 = [Tuple2 v1:NSLocalizedString(@"Lock time", nil) v2:ltShow];

    self.datas = @[_t1,t2,t3,t4,t5];
    [self setDesignViews];
    
    [FSCacheManager allCacheSize:^(NSUInteger bResult) {
        NSString *cache = _fs_KMGUnit(bResult);
        self->_t1._2 = cache;
        self->_firstCell.detailTextLabel.text = cache;
    }];
}

- (void)setDesignViews{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.rowHeight = 55;
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
        
        UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, 10)];
        _tableView.tableHeaderView = headView;
    }else{
        [_tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _datas.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *first = @"first";
    static NSString *identifier = nil;
    identifier = indexPath.row?@"cell":first;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.textLabel.font = FONTFC(14);
        cell.detailTextLabel.font = FONTFC(14);
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.detailTextLabel.textColor = APPCOLOR;
    }
    NSInteger row = indexPath.row;
    Tuple2 *t = _datas[row];
    cell.textLabel.text = t._1;
    cell.detailTextLabel.text = t._2;
    if (indexPath.row == 0) {
        _firstCell = cell;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self cellAction:indexPath table:tableView];
}

- (void)cellAction:(NSIndexPath *)IP table:(UITableView *)tableView{
    WEAKSELF(this);
    if (IP.row == 0) {
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Tips", nil) message:NSLocalizedString(@"Clear cache", nil) actionTitles:@[NSLocalizedString(@"Clear", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            [self showWaitView:YES];
            [FSCacheManager clearAllCache:^{
                [self showWaitView:NO];
                self->_t1._2 = @"0.00 K";
                [tableView reloadRowsAtIndexPaths:@[IP] withRowAnimation:UITableViewRowAnimationFade];
            }];
        }];
    }else if (IP.row == 1){
        BOOL hasConfiged = NO;
        NSString *mail = [FSAppConfig objectForKey:_appCfg_receivedEmail];
        if (_fs_isValidateString(mail)) {
            hasConfiged = YES;
        }
        [FSUIKit alertInput:1 controller:self title:hasConfiged?NSLocalizedString(@"Update email", nil):NSLocalizedString(@"Config email", nil) message:hasConfiged?mail:@"eg:fuswift@163.com" ok:NSLocalizedString(@"Confirm", nil) handler:^(UIAlertController *bAlert, UIAlertAction *action) {
            UITextField *tf = [bAlert.textFields firstObject];
            if (![FSKit isValidateEmail:tf.text]) {
                [FSToast show:NSLocalizedString(@"Please input a right email", nil)];
                return;
            }
            [FSAppConfig saveObject:tf.text forKey:_appCfg_receivedEmail];
            [this setHandleDatas];
        } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:nil completion:nil];
    }else if (IP.row == 2){
        [FSUIKit alertInput:1 controller:self title:NSLocalizedString(@"Tips", nil) message:NSLocalizedString(@"Pdf password for file", nil) ok:NSLocalizedString(@"Confirm", nil) handler:^(UIAlertController *bAlert, UIAlertAction *action) {
            UITextField *tf = [bAlert.textFields firstObject];
            if (tf.text.length < 6) {
                [FSToast show:NSLocalizedString(@"Password must 6 or more", nil)];
                return;
            }
            [FSAppConfig saveObject:tf.text forKey:_appCfg_pdfPassword];
            [this setHandleDatas];
        } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:^(UITextField *textField) {
            textField.secureTextEntry = YES;
        } completion:nil];
    }else if (IP.row == 3){
        BOOL has = [FSGestureController hasSettedPassword];
        FSGestureController *g = [[FSGestureController alloc] init];
        if (has) {
            g.mode = FSGestureModeChange;
        }else{
            g.mode = FSGestureModeSet;
        }
        g.hiddenTopLeftCancelButton = YES;
        [self.navigationController pushViewController:g animated:YES];
        __weak typeof(self)this = self;
        g.setedSuccess = ^(FSGestureController *bVC) {
            [bVC.navigationController popViewControllerAnimated:YES];
            [this setHandleDatas];
        };
    }else if (IP.row == 4){
        [FSUIKit alertInput:1 controller:self title:NSLocalizedString(@"Tips", nil) message:NSLocalizedString(@"The time of lock screen", nil) ok:NSLocalizedString(@"Confirm", nil) handler:^(UIAlertController *bAlert, UIAlertAction *action) {
            UITextField *tf = [bAlert.textFields firstObject];
            NSInteger t = tf.text.integerValue;
            if (t < 0 || t > 180) { // iOS7之后app在后台运行时间为3分钟
                [FSToast show:NSLocalizedString(@"The time between 0 and 180", nil)];
                return;
            }
            [FSAppConfig saveObject:tf.text forKey:_appCfg_lockTime];
            [this setHandleDatas];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"JZChangeDelaySecondsNotification" object:nil];
        } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"0 - 180";
        } completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
