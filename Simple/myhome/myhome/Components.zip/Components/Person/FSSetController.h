//
//  FSSetController.h
//  myhome
//
//  Created by FudonFuchina on 2016/12/19.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSSetController : FSBaseController

@end
