//
//  FSChangeCorePwdController.m
//  myhome
//
//  Created by FudonFuchina on 2018/4/24.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSChangeCorePwdController.h"
#import "FSLabelTextField.h"
#import <FSUIKit.h>
#import "FSPwdAPI.h"
#import "UIViewController+BackButtonHandler.h"
#import "FuSoft.h"
#import "FSToast.h"
#import "FSMacro.h"

@interface FSChangeCorePwdController ()

@end

@implementation FSChangeCorePwdController{
    UILabel         *_label;
    UIButton        *_button;
    BOOL            _completion;
    BOOL            _withOldPassword;
    NSString        *_oldPwd;
    NSString        *_newPwd;
    UILabel         *_tail;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _completion = YES;
    [self corePwdDesignViews];
}

- (void)corePwdDesignViews{
    self.title = @"更改核心密码";
    
    NSArray *titles = @[@"原密码",@"新密码"];
    FSLabelTextField *textField = nil;
    for (int x = 0; x < titles.count; x ++) {
        textField = [[FSLabelTextField alloc] initWithFrame:CGRectMake(0, 74 + (FS_iPhone_X?22:0) + 45 * x, WIDTHFC, 44) text:titles[x] textFieldText:nil placeholder:NSLocalizedString(@"Please input", nil)];
        textField.tag = TAG_TEXTFIELD + x;
        [self.view addSubview:textField];
    }
    
    _button = [FSViewManager buttonWithFrame:CGRectMake(15, textField.bottom + 20, WIDTHFC - 30, 44) title:NSLocalizedString(@"Confirm", nil) titleColor:[UIColor whiteColor] backColor:FSAPPCOLOR fontInt:0 tag:0 target:self selector:@selector(countAction)];
    [self.view addSubview:_button];
    
    UILabel *tail = [[UILabel alloc] initWithFrame:CGRectMake(15, _button.bottom + 10, WIDTHFC - 30, 14)];
    tail.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    tail.textAlignment = NSTextAlignmentRight;
    tail.textColor = FSAPPCOLOR;
    [self.view addSubview:tail];_tail = tail;
    _tail.text = [FSPwdAPI nowPwd];
    
    UIButton *forget = [FSViewManager buttonWithFrame:CGRectMake(0, HEIGHTFC - 44 - FS_iPhone_X * 34, WIDTHFC, 44) title:@"忘记原密码也可以改密码啦" titleColor:APPCOLOR backColor:UIColor.whiteColor fontInt:0 tag:0 target:self selector:@selector(forgetChange)];
    forget.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    [self.view addSubview:forget];
}

- (void)forgetChange{
    _withOldPassword = NO;
    NSString *message = @"为防更新出现问题，请先保存原数据库；不要在手机快没电的情况下更新核心密码！";
    [FSUIKit alertInput:1 controller:self title:@"提示" message:message ok:@"确定" handler:^(UIAlertController *bAlert, UIAlertAction *action) {
        UITextField *tf = bAlert.textFields.firstObject;
        NSString *newPwd = tf.text;
        if (!_fs_isValidateString(newPwd)) {
            [FSToast show:@"请输入新密码"];
            return;
        }
        self -> _newPwd = newPwd;
        [self showSecondConfirmAlertView];
    } cancel:@"取消" handler:nil textFieldConifg:^(UITextField *textField) {
        textField.placeholder = @"请输入新密码";
    } completion:nil];
}

- (void)countAction{
    [self.view endEditing:YES];
    
    FSLabelTextField *oldTF = (FSLabelTextField *)[self.view viewWithTag:TAG_TEXTFIELD];
    _oldPwd = oldTF.textField.text;
    if (!_fs_isValidateString(_oldPwd)) {
        [FSToast toast:@"请输入原密码"];
        return;
    }
    FSLabelTextField *newTF = (FSLabelTextField *)[self.view viewWithTag:TAG_TEXTFIELD + 1];
    _newPwd = newTF.textField.text;
    if (!_fs_isValidateString(_newPwd)) {
        [FSToast toast:@"请输入新密码"];
        return;
    }
    _label.text = nil;
    _withOldPassword = YES;

    [self showFirstAlertView];
}

- (void)showFirstAlertView{
    NSString *message = @"为防更新出现问题，请先保存原数据库；不要在手机快没电的情况下更新核心密码！";
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:message actionTitles:@[@"我已保存原数据库"] styles:@[@(UIAlertActionStyleDestructive)] handler:^(UIAlertAction *action) {
        [self showSecondConfirmAlertView];
    }];
}

- (void)showSecondConfirmAlertView{
    NSString *message = @"确认已保存原数据库？";
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:message actionTitles:@[@"确认"] styles:@[@(UIAlertActionStyleDestructive)] handler:^(UIAlertAction *action) {
        [self updateActionExection];
    }];
}

- (void)updateActionExection{
    [self showWaitView:YES];
    _completion = NO;
    __block BOOL canStep = NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        _fs_spendTimeInDoSomething(^{
            NSString *error = nil;
            if (self -> _withOldPassword) {
                error = [FSPwdAPI changeCorePasswordWithOld:self -> _oldPwd new:self -> _newPwd];
            }else{
                error = [FSPwdAPI changeCorePasswordOnlyWithNewPwd:self -> _newPwd];
            }
            if (error) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self showWaitView:NO];
                    self->_completion = YES;
                    
                    self.label.text = error;
                    self.label.textColor = [UIColor redColor];
                });
            }else{
                canStep = YES;
            }
        }, ^(double time) {
            NSString *last = [[NSString alloc] initWithFormat:@"更新完成，共耗时%.2f秒",time];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self showWaitView:NO];
                if (canStep) {
                    [FSPwdAPI completionHandle:self -> _newPwd];
                    
                    self -> _completion = YES;
                    self.label.text = last;
                    self.label.textColor = FS_GreenColor;
                    self->_button.enabled = NO;
                    self->_button.alpha = .5;
                    
                    self -> _tail.text = [FSPwdAPI nowPwd];
                }
            });
        });
    });
}

- (UILabel *)label{
    if (!_label) {
        CGFloat top = _button.bottom + 20;
        _label = [[UILabel alloc] initWithFrame:CGRectMake(15, top, WIDTHFC, 50)];
        _label.font = [UIFont systemFontOfSize:13];
        _label.textColor = FS_GreenColor;
        _label.numberOfLines = 2;
        [self.view addSubview:_label];
    }
    return _label;
}

- (BOOL)navigationShouldPopOnBackButton{
    return _completion;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
