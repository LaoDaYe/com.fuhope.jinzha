//
//  HARewardPolicyController.h
//  myhome
//
//  Created by FudonFuchina on 2016/12/9.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface HARewardPolicyController : FSBaseController

@end
