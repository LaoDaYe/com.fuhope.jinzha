//
//  FSNoticeViewController.m
//  myhome
//
//  Created by FudonFuchina on 2018/5/9.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSNoticeViewController.h"
#import "FSNoteView.h"
#import "FSKit.h"
#import "FSToast.h"
#import "FSTrackKeys.h"

@interface FSNoticeViewController ()

@end

@implementation FSNoticeViewController{
    FSNoteView      *_noteView;
    BOOL            _justOneTime;
    NSInteger       _index;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Notice", nil);
    
    _fs_dispatch_main_queue_async(^{
        [self setupBBI];
    });
}

- (void)setupBBI{
    UIButton *b = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 40)];
    [b addTarget:self action:@selector(bclick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithCustomView:b];
    self.navigationItem.rightBarButtonItem = bbi;
}

- (void)bclick:(UIButton *)button{
    NSInteger margin = 30;
    if (_index < margin) {
        _index ++;return;
    }
    [FSToast toast:@"被你发现啦" tap:^{
        [self bbiClick];
    }];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:@"旧密码系统" style:UIBarButtonItemStylePlain target:self action:@selector(bbiClick)];
    self.navigationItem.rightBarButtonItem = bbi;
}

- (void)bbiClick{
    [FSKit pushToViewControllerWithClass:@"FSOldPasswordSystemController" navigationController:self.navigationController param:nil configBlock:nil];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (!_justOneTime) {
        _justOneTime = YES;
        [self noticeDesignViews];
    }
}

- (void)noticeDesignViews{
    [FSTrack event:_UMeng_Event_see_noteView];
    
    if (!_noteView) {
        _noteView = [[FSNoteView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
        [self.view addSubview:_noteView];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
