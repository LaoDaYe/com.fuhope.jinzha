//
//  FSNoticeViewController.h
//  myhome
//
//  Created by FudonFuchina on 2018/5/9.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSNoticeViewController : FSBaseController

@end
