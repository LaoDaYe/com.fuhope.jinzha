//
//  FSWSKController.m
//  FTK
//
//  Created by fudon on 2017/2/3.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSWSKController.h"
#import "FSWSKCell.h"

@interface FSWSKController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray *pukes;

@end

@implementation FSWSKController
{
    NSInteger   _popCount;
    UITableView *_tableView;
    UILabel     *_bombLabel;// 炸弹
    UILabel     *_thrLabel; // 三个
    UILabel     *_wskLabel; // 五十K
}

- (void)popActionBase
{
    if (_popCount) {
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        _popCount ++;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"五十K";
    _pukes = [[NSMutableArray alloc] initWithArray:@[@{@"type":@"3",@"colors":@[@1,@2,@3,@4]},@{@"type":@"4",@"colors":@[@1,@2,@3,@4]},
                                                     @{@"type":@"5",@"colors":@[@1,@2,@3,@4]},@{@"type":@"6",@"colors":@[@1,@2,@3,@4]},
                                                     @{@"type":@"7",@"colors":@[@1,@2,@3,@4]},@{@"type":@"8",@"colors":@[@1,@2,@3,@4]},
                                                     @{@"type":@"9",@"colors":@[@1,@2,@3,@4]},@{@"type":@"10",@"colors":@[@1,@2,@3,@4]},
                                                     @{@"type":@"J",@"colors":@[@1,@2,@3,@4]},@{@"type":@"Q",@"colors":@[@1,@2,@3,@4]},
                                                     @{@"type":@"K",@"colors":@[@1,@2,@3,@4]},@{@"type":@"A",@"colors":@[@1,@2,@3,@4]},
                                                     @{@"type":@"2",@"colors":@[@1,@2,@3,@4]},@{@"type":@"JOKER",@"colors":@[@1,@2]},
                                                    ]];
    
    UITableView *table = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    _tableView = table;
    
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 100)];
    headView.backgroundColor = [UIColor greenColor];
    table.tableHeaderView = headView;
    
    _bombLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, headView.bounds.size.width - 20, 30)];
    [headView addSubview:_bombLabel];
    _thrLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 35, headView.bounds.size.width - 20, 30)];
    [headView addSubview:_thrLabel];
    _wskLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 65, headView.bounds.size.width - 20, 30)];
    [headView addSubview:_wskLabel];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _pukes.count;
}

- (FSWSKCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    FSWSKCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSWSKCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        __weak FSWSKController *this = self;
        [cell setAddAction:^(NSInteger bType, NSInteger bColor) {
            [this addActionWithType:bType color:bColor isAdd:YES];
        }];
        [cell setDeleteAction:^(NSInteger bType, NSInteger bColor) {
            [this addActionWithType:bType color:bColor isAdd:NO];
        }];
    }
    cell.dic = [_pukes objectAtIndex:indexPath.row];
    cell.type = indexPath.row;
    return cell;
}

- (void)addActionWithType:(NSInteger)type color:(NSInteger)color isAdd:(BOOL)isAdd
{
    NSDictionary *dic = [_pukes objectAtIndex:type];
    if (isAdd) {    // 增加
        NSArray *colors = [dic objectForKey:@"colors"];
        if ([colors containsObject:@(color)]) {
            return;
        }
        NSMutableArray *array = [[NSMutableArray alloc] initWithArray:colors];
        [array addObject:@(color)];
        NSMutableDictionary *mDic = [[NSMutableDictionary alloc] initWithDictionary:dic];
        [mDic setObject:array forKey:@"colors"];
        [_pukes replaceObjectAtIndex:type withObject:mDic];
    }else{          // 删除
        NSArray *colors = [dic objectForKey:@"colors"];
        if (![colors containsObject:@(color)]) {
            return;
        }
        NSMutableArray *array = [[NSMutableArray alloc] initWithArray:colors];
        [array removeObject:@(color)];

        NSMutableDictionary *mDic = [[NSMutableDictionary alloc] initWithDictionary:dic];
        [mDic setObject:array forKey:@"colors"];
        [_pukes replaceObjectAtIndex:type withObject:mDic];
    }
    
    NSIndexPath *indexPath= [NSIndexPath indexPathForRow:type inSection:0];
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    
    // 检查炸弹
    NSMutableArray *bArray = [[NSMutableArray alloc] init];
    NSMutableArray *tArray = [[NSMutableArray alloc] init];
//    NSMutableArray *wArray = [[NSMutableArray alloc] init];
    for (int x = 0; x < _pukes.count; x ++) {
        NSDictionary *dic = _pukes[x];
        NSArray *colors = [dic objectForKey:@"colors"];
        if (colors.count == 4) {
            [bArray addObject:[dic objectForKey:@"type"]];
            [tArray addObject:[dic objectForKey:@"type"]];
        }else if (colors.count == 3){
            [tArray addObject:[dic objectForKey:@"type"]];
        }
    }
    
    NSMutableString *bombStr = [[NSMutableString alloc] init];
    for (int x = 0; x < bArray.count; x ++) {
        if (x) {
            [bombStr appendString:[[NSString alloc] initWithFormat:@"、%@",bArray[x]]];
        }else{
            [bombStr appendString:bArray[x]];
        }
    }
    _bombLabel.text = [[NSString alloc] initWithFormat:@"炸弹:%@",bombStr];
    
    NSMutableString *thrStr = [[NSMutableString alloc] init];
    for (int x = 0; x < tArray.count; x ++) {
        if (x) {
            [thrStr appendString:[[NSString alloc] initWithFormat:@"、%@",tArray[x]]];
        }else{
            [thrStr appendString:tArray[x]];
        }
    }
    _thrLabel.text = [[NSString alloc] initWithFormat:@"三个:%@",thrStr];
    
    
    
    
    
    _wskLabel.text = [[NSString alloc] initWithFormat:@"五十K:"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
