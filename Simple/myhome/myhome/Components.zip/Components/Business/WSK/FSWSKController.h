//
//  FSWSKController.h
//  FTK
//
//  Created by fudon on 2017/2/3.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSWSKController : UIViewController

@end
