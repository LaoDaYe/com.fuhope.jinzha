//
//  FSWSKCell.m
//  FTK
//
//  Created by fudon on 2017/2/3.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSWSKCell.h"

@implementation FSWSKCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        CGFloat width = self.bounds.size.width / 5;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(0, 0, width - 1, self.bounds.size.height);
        button.tag = 1000;
        button.backgroundColor = [UIColor colorWithRed:240 / 255.0 green:240 / 255.0 blue:240 / 255.0 alpha:1];
        [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
    return self;
}

- (void)setType:(NSInteger)type
{
    _type = type;
    
    UIButton *first = [self viewWithTag:1000];
    [first setTitle:[self wskTitle:type] forState:UIControlStateNormal];
    
    for (UIButton *subBtn in self.subviews) {
        if ([subBtn isKindOfClass:UIButton.class] && subBtn.tag > 1000) {
            [subBtn removeFromSuperview];
        }
    }
    
    CGFloat width = self.bounds.size.width / 5;
    NSArray *colors = [self.dic objectForKey:@"colors"];
    for (int x = 0; x < colors.count; x ++) {
        NSNumber *number = colors[x];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(width + x * width, 0, width - 1, self.bounds.size.height);
        button.tag = [number integerValue] + 1000;
        [button setTitle:[self titleForColor:[number integerValue]] forState:UIControlStateNormal];
        button.backgroundColor = [UIColor colorWithRed:240 / 255.0 green:240 / 255.0 blue:240 / 255.0 alpha:1];
        [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
}

- (NSString *)titleForColor:(NSInteger)color
{
    NSArray *titles = @[@"",@"♠",@"♣",@"🍧",@"♦"];
    return titles[color % titles.count];
}

- (NSString *)wskTitle:(NSUInteger)row
{
    if (row < 8) {
        return @(row + 3).stringValue;
    }else if (row == 8){
        return @"J";
    }else if (row == 9){
        return @"Q";
    }else if (row == 10){
        return @"K";
    }else if (row == 11){
        return @"A";
    }else if (row == 12){
        return @"2";
    }else{
        return @"JOKER";
    }
}

- (void)click:(UIButton *)button{
    if (button.tag == 1000) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[[NSString alloc] initWithFormat:@"增加一张:%@",[self wskTitle:self.type]] message:@"请选择类型" delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", nil) otherButtonTitles:@"♠",@"♣",@"🍧",@"♦", nil];
        [alert show];
    }else{
        if (self.deleteAction) {
            NSInteger tag = button.tag - 1000;
            [button removeFromSuperview];
            self.deleteAction(self.type,tag);
        }
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != 0) {
        if (self.addAction) {
            self.addAction(self.type,buttonIndex);
        }
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
