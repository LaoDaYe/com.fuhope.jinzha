//
//  FSSave.m
//  FSSave
//
//  Created by fudon on 2017/1/9.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSSave.h"
#import <FSKit.h>
#import <FSUIKit.h>
#import <FSDate.h>

#define Path_Image          @"ImagesPath"       // 可清理目录，主要用于保存图片
#define Path_LikeSQL        @"LikeSQLDir"       // 类数据库目录
#define Path_KeyValue       @"KeyValueDir"      // 键值对目录

#define Key_Data            @"data"
#define Key_Time            @"time"
#define ConfigTime_Day      (24 * 3600)         // 1天

@implementation FSSave

+ (void)saveImage:(UIImage *)image forKey:(NSString *)url{
    BOOL validateUrl = [url isKindOfClass:NSString.class] && url.length;
    if ((![image isKindOfClass:UIImage.class]) || (!validateUrl)) {
        return;
    }
    NSString *imagePath = [[self cacheDirectory] stringByAppendingPathComponent:Path_Image];
    NSString *key = _fs_md5(url);
    NSString *filePath = [imagePath stringByAppendingPathComponent:key];

    NSFileManager *manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]) {
        return;
    }
    
    _fs_dispatch_global_queue_async(^{
        UIImage *cacheImage = [FSUIKit compressImage:image];
        NSData *data = UIImageJPEGRepresentation(cacheImage, 1);
        NSInteger time = (NSInteger)[[NSDate date] timeIntervalSince1970];
        NSDictionary *dic = @{Key_Time:@(time),Key_Data:data};
        [NSKeyedArchiver archiveRootObject:dic toFile:filePath];
    });
}

+ (void)saveObject:(id)object forKey:(NSString *)customKey{
    if (!([customKey isKindOfClass:NSString.class] && customKey.length) && !object) {
        return;
    }
    NSString *key = _fs_md5(customKey);
    NSString *filePath = [[[self cacheDirectory] stringByAppendingPathComponent:Path_KeyValue] stringByAppendingPathComponent:key];
    
    [NSKeyedArchiver archiveRootObject:object toFile:filePath];
}

+ (id)objectForKey:(NSString *)key{
    if ([key isKindOfClass:NSString.class]  && key.length) {
        NSString *md5Key = _fs_md5(key);
        NSString *filePath = [[[self cacheDirectory] stringByAppendingPathComponent:Path_KeyValue] stringByAppendingPathComponent:md5Key];
        NSFileManager *manager = [NSFileManager defaultManager];
        BOOL isExist = [manager fileExistsAtPath:filePath];
        if (isExist) {
            return [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        }
    }
    return nil;
}

+ (void)addObject:(id)object table:(NSString *)table{
    if (!object || !([table isKindOfClass:NSString.class] && table.length)) {
        return;
    }
    NSString *path = [self tablePathForTable:table];
    if (path) {
        NSDateComponents *components = [FSDate componentForDate:[NSDate date]];
        NSString *key = [[NSString alloc] initWithFormat:@"%@%@%@%@%@%@",@(components.year),[FSKit twoChar:components.month],[FSKit twoChar:components.day],[FSKit twoChar:components.hour],[FSKit twoChar:components.minute],[FSKit twoChar:components.second]];
        
        NSString *filePath = [path stringByAppendingPathComponent:key];
        [NSKeyedArchiver archiveRootObject:object toFile:filePath];
    }
}

+ (NSArray *)selectWithTable:(NSString *)table condition:(NSString *)condition
{
    
    return nil;
}

+ (NSString *)tablePathForTable:(NSString *)table
{
    if ([table isKindOfClass:NSString.class] && table.length) {
        NSString *tablePath = [[[self cacheDirectory] stringByAppendingPathComponent:Path_LikeSQL] stringByAppendingPathComponent:table];
        
        NSFileManager *manager = [NSFileManager defaultManager];
        BOOL isDirectory;
        BOOL exist = [manager fileExistsAtPath:tablePath isDirectory:&isDirectory];
        if (!(isDirectory && exist)){
            [manager createDirectoryAtPath:tablePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        return tablePath;
    }
    return nil;
}

+ (void)clearDiskCacheBeforeDays:(NSInteger)days
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSInteger day = MAX(days, 1);
        
        NSString *cachePath = [[self cacheDirectory] stringByAppendingPathComponent:Path_Image];
        NSFileManager *manager = [NSFileManager defaultManager];
        NSError *error = nil;
        NSArray *paths = [manager subpathsOfDirectoryAtPath:cachePath error:&error];
        NSInteger now = (NSInteger)[[NSDate date] timeIntervalSince1970];
        if ((!error) && paths.count && ([manager fileExistsAtPath:cachePath])) {
            for (NSString *path in paths) {
                NSString *filePath = [cachePath stringByAppendingPathComponent:path];
                NSDictionary *dic = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
                if (dic) {
                    NSInteger time = [dic[Key_Time] integerValue];
                    if ((now - time) > (ConfigTime_Day * day)) {
                        [manager removeItemAtPath:filePath error:nil];
                    }
                }
            }
        }
    });
}

+ (void)deleteDiskCache{
    NSString *cachePath = [[self cacheDirectory] stringByAppendingPathComponent:Path_Image];
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:cachePath]) {
        return;
    }
    NSError *error = nil;
    BOOL result = [manager removeItemAtPath:cachePath error:&error];
    if (!result) {
    }
}

+ (UIImage *)imageFromCacheWithUrl:(NSString *)url
{
    if (!([url isKindOfClass:NSString.class] && url.length)) {
        return nil;
    }
    
    NSFileManager *manager = [NSFileManager defaultManager];
    NSString *filePath = [[[self cacheDirectory] stringByAppendingPathComponent:Path_Image] stringByAppendingPathComponent:_fs_md5(url)];
    
    if ([manager fileExistsAtPath:filePath]) {
        
        NSDictionary *dic = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        NSData *data = dic[Key_Data];
        if (data) {
            UIImage *image = [FSUIKit compressImageData:data];
            return image;
        }
        return nil;
    }
    return nil;
}

+ (NSString *)cacheDirectory
{
    NSFileManager *manager = [NSFileManager defaultManager];
    NSString *cachePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath = [cachePath stringByAppendingPathComponent:NSStringFromClass(self.class)];
    BOOL isDirectory;
    BOOL exist = [manager fileExistsAtPath:filePath isDirectory:&isDirectory];
    if (!(isDirectory && exist)) {
        [manager createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        
        // 可清理目录
        NSString *canClearDir = [filePath stringByAppendingPathComponent:Path_Image];
        [manager createDirectoryAtPath:canClearDir withIntermediateDirectories:YES attributes:nil error:nil];
        
        // 类数据库目录 (用于保存数组，数组中的元素是字典或字符串等)
        NSString *likeSQLDir = [filePath stringByAppendingPathComponent:Path_LikeSQL];
        [manager createDirectoryAtPath:likeSQLDir withIntermediateDirectories:YES attributes:nil error:nil];

        // 保存key-value的目录
        NSString *kvDir = [filePath stringByAppendingPathComponent:Path_KeyValue];
        [manager createDirectoryAtPath:kvDir withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return filePath;
}

@end
