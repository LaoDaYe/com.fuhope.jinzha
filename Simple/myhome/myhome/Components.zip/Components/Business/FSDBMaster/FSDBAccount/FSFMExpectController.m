//
//  FSFMExpectController.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/9/10.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSFMExpectController.h"
#import "FSShare.h"
#import "FSAccountConfiger.h"
#import "FSDBTool.h"
#import "FSDBFlowController.h"
#import "FSPublic.h"
#import <FSUIKit.h>
#import <FSDate.h>
#import "FSTrackKeys.h"
#import "FSKitDuty.h"

#define Key_Year_Many           5
#define Days_Holddays           365 * 5.0
#define Days_Holddays_Power     365 * 2.5
#define Days_Cashdays           365 * 1.5

@interface FSFMExpectController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSArray        *textSource;
@property (nonatomic,assign) CGFloat        dayMoney;

@property (nonatomic,assign) CGFloat        deltaMoney; // 每个月的增量
@property (nonatomic,assign) CGFloat        addMoney;   // 存量

@property (nonatomic,strong) UIView         *headView;
@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) UILabel        *rateLabel;
@property (nonatomic,strong) UISlider       *slider;
@property (nonatomic,strong) UILabel        *startLabel;
@property (nonatomic,assign) BOOL           hasFirst;
@property (nonatomic,strong) UIButton       *selectButton;
@property (nonatomic,assign) NSTimeInterval firstTime;
@property (nonatomic,assign) CGFloat        newCost;

@end

@implementation FSFMExpectController{
    FSSQLEntity         *_entity;
    CGFloat             _jzc;
    CGFloat             _sr;
    CGFloat             _cb;
}

- (void)actionOfChoose{
    WEAKSELF(this);
    [FSUIKit alertInput:1 controller:self title:NSLocalizedString(@"Set space", nil) message:NSLocalizedString(@"You can set days to count income or cost", nil) ok:@"OK" handler:^(UIAlertController *bAlert, UIAlertAction *action) {
        UITextField *tf = bAlert.textFields.firstObject;
        NSString *text = tf.text;
        if (!_fs_isPureInt(text)) {
            [FSToast show:NSLocalizedString(@"Please input number", nil)];
            return;
        }
        NSInteger days = [text integerValue];
        if (days <= 0) {
            [FSToast show:NSLocalizedString(@"Please input a number > zero", nil)];
            return;
        }
        NSString *num = [[NSString alloc] initWithFormat:@"%@%@%@",NSLocalizedString(@"Pass", nil),@(days),NSLocalizedString(@"day", nil)];
        [this.selectButton setTitle:num forState:UIControlStateNormal];
        NSTimeInterval time = _fs_timeIntevalSince1970() - days * 24 * 3600;
        this.firstTime = MAX(this.theEarliestTime, time);
        NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:this.firstTime];
        this.startLabel.text = [FSDate stringWithDate:date formatter:nil];
        this.hasFirst = NO;
        [this expectHandleDatas];
    } cancel:@"Cancel" handler:nil textFieldConifg:^(UITextField *textField) {
        textField.placeholder = NSLocalizedString(@"Pass days", nil);
        textField.keyboardType = UIKeyboardTypeNumberPad;
    } completion:nil];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = FS_GreenColor;
    
    [FSTrack event:_UMeng_Event_acc_expect];
    
    CGFloat dayUnit = 24 * 3600;
    _firstTime = MAX(_theEarliestTime, _fs_timeIntevalSince1970() - 365 * dayUnit);
    NSInteger day = (_fs_timeIntevalSince1970() - _firstTime) / dayUnit;
    NSString *text = [[NSString alloc] initWithFormat:@"%@%@%@",NSLocalizedString(@"Pass", nil),@((NSInteger)day),NSLocalizedString(@"day", nil)];
    
    _selectButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _selectButton.frame = CGRectMake(0, 0, 140, 44);
    [_selectButton setTitle:text forState:UIControlStateNormal];
    _selectButton.titleLabel.font = [UIFont boldSystemFontOfSize:17];
    [_selectButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_selectButton addTarget:self action:@selector(actionOfChoose) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationItem setTitleView:_selectButton];
    
    UIBarButtonItem *item = [FSViewManager bbiWithSystemType:UIBarButtonSystemItemAdd target:self action:@selector(bbiAction)];
    self.navigationItem.rightBarButtonItem = item;
    
    _textSource = @[NSLocalizedString(@"One years later", nil),NSLocalizedString(@"Three years later", nil),NSLocalizedString(@"Five years later", nil)];
    
    _fs_dispatch_global_queue_async(^{
        self->_entity = [FSDBTool fasterEntityFromDB:self->_accountName start:_fs_timeIntevalSince1970()];
        [self expectHandleDatas];
    });
}

- (void)shakeEndActionFromShakeBase{
    [FSPublic shareAction:self view:_tableView];
}

- (void)expectHandleDatas{
//#if DEBUG
//    NSTimeInterval start = FSTimeIntevalSince1970();
//#endif
    
    NSInteger page = 0;
    NSString *sql = [self sql:_firstTime page:page];
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSMutableArray *list = [master querySQL:sql tableName:_accountName];
    _sr = 0;
    _cb = 0;
    CGFloat *sp = &_sr;
    CGFloat *cp = &_cb;
    while (_fs_isValidateArray(list)) {
        for (NSDictionary *m in list) {
            CGFloat je = [m[@"je"] doubleValue];
            [self handleSRAndCB:sp cb:cp je:je type:m[@"atype"]];
            [self handleSRAndCB:sp cb:cp je:je type:m[@"btype"]];
        }
        page ++;
        sql = [self sql:_firstTime page:page];
        list = [master querySQL:sql tableName:_accountName];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
//#if DEBUG
//        NSTimeInterval end = FSTimeIntevalSince1970();
//        [FSToast show:[[NSString alloc] initWithFormat:@"耗时:%.6f",end - start]];
//#endif
        [self expectDesignViews];
    });
}

- (void)handleSRAndCB:(CGFloat *)sr cb:(CGFloat *)cb je:(CGFloat)je type:(NSString *)type{
    if (![type isKindOfClass:NSString.class]) {
        return;
    }
    if ([type containsString:_subject_SR]) {
        BOOL plus = [type hasSuffix:_ING_KEY];
        BOOL mius = [type hasSuffix:_ED_KEY];
        if (plus) {
            *sr = *sr + je;
        }else if (mius){
            *sr = *sr - je;
        }
    }else if ([type containsString:_subject_CB]){
        BOOL plus = [type hasSuffix:_ING_KEY];
        BOOL mius = [type hasSuffix:_ED_KEY];
        if (plus) {
            *cb = *cb + je;
        }else if (mius){
            *cb = *cb - je;
        }
    }
}

- (NSString *)sql:(NSInteger)start page:(NSInteger)page{
    NSInteger unit = 200;
    static NSString *sring = nil;
    if (sring == nil) {
        sring = [[NSString alloc] initWithFormat:@"%@%@",_subject_SR,_ING_KEY];
    }
    static NSString *sred = nil;
    if (sred == nil) {
        sred = [[NSString alloc] initWithFormat:@"%@%@",_subject_SR,_ED_KEY];
    }
    static NSString *cbing = nil;
    if (cbing == nil) {
        cbing = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ING_KEY];
    }
    static NSString *cbed = nil;
    if (cbed == nil) {
        cbed = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ED_KEY];
    }
    
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@') and cast(time as REAL) > %@ limit %@,%@;",_accountName,sring,sring,sred,sred,cbing,cbing,cbed,cbed,@(start - 10),@(page * unit),@(unit)];
    return sql;
}

- (void)doSomethingRepeatedly{
    [self expectDesignViews];
    
    __weak typeof(self) weakSelf = self;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [weakSelf doSomethingRepeatedly];
    });
}

- (void)expectDesignViews{
    CGFloat days = (_fs_timeIntevalSince1970() - _firstTime) / 86400.0;
    CGFloat newCost = _newCost / 30.0;
    _dayMoney = (_sr - _cb - newCost) / days +  self.deltaMoney / 30;
    
    CGFloat ys = [_entity.ys doubleValue];
    CGFloat xj = [_entity.xj doubleValue];
    CGFloat ch = [_entity.ch doubleValue];
    CGFloat tz = [_entity.tz doubleValue];
    CGFloat gz = [_entity.gz doubleValue];
    CGFloat tx = [_entity.tx doubleValue];
    CGFloat fz = [_entity.fz doubleValue];
    CGFloat ps = [_entity.ps doubleValue];
    
    CGFloat assets = ys + xj + ch + tz + gz + tx;
    CGFloat debts = fz + ps;
    _jzc = assets - debts;
    
    CGFloat holdDays = 0;
    CGFloat holdDaysPower = 0;
    CGFloat cashHoldDays = 0;
    CGFloat cbPerday = _cb / days + newCost;
    if (_cb > 0) {
        holdDaysPower = (xj * 1.05 + _addMoney + ch * .9 + ys * .8 + tz * .7 + gz * .6 + tx * 0.5 - debts * 1.1) / cbPerday;
        holdDays = (xj + _addMoney + ch + ys + tz + gz + tx - debts) / cbPerday;
        cashHoldDays = (xj + _addMoney) / cbPerday;
    }
    // 现金不需要减去负债，不然得出的值的参考意义不大
    
    NSString *holdDaysString = [self dayMonthYearForNumber:holdDays type:@(Days_Holddays * 12 / 365).stringValue];
    NSString *holdDaysPowerString = [self dayMonthYearForNumber:holdDaysPower type:@(Days_Holddays_Power * 12 / 365).stringValue];
    NSString *holdDaysCashString = [self dayMonthYearForNumber:cashHoldDays type:@(Days_Cashdays * 12 / 365).stringValue];

    NSString *rate = [[NSString alloc] initWithFormat:@"%.2f%%",((_sr - _cb) / MAX(_sr, 0.01)) * 100];
    NSArray *values = @[[self moneyFormat:_sr],[self moneyFormat:_cb],[self moneyFormat:_sr - _cb],rate,[self moneyFormat:_dayMoney],[self moneyFormat:_dayMoney * 30],[self moneyFormat:cbPerday],[self moneyFormat:cbPerday * 30],holdDaysString,holdDaysPowerString,holdDaysCashString];
    
    if (!_headView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 20 + 30 * values.count + 220)];
        _headView.backgroundColor = FS_GreenColor;
        NSArray *titles = @[NSLocalizedString(@"Start time", nil),NSLocalizedString(@"Current income", nil),NSLocalizedString(@"Current cost", nil),NSLocalizedString(@"Current profit", nil),NSLocalizedString(@"Profit ratio of sales", nil),NSLocalizedString(@"Profit per day", nil),NSLocalizedString(@"Profit per month", nil),NSLocalizedString(@"Cost per day", nil),NSLocalizedString(@"Cost per month", nil),NSLocalizedString(@"Asset can pay", nil),NSLocalizedString(@"Asset can pay(power)", nil),NSLocalizedString(@"Cash can pay", nil)];
        for (int x = 0; x < titles.count; x ++) {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 10 + 30 * x, WIDTHFC, 30)];
            label.text = titles[x];
            label.textColor = [UIColor whiteColor];
            [_headView addSubview:label];
            
            UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.view.bounds.size.width / 3, label.top, self.view.bounds.size.width * 2 / 3 - 15, 30)];
            valueLabel.textAlignment = NSTextAlignmentRight;
            valueLabel.tag = TAG_LABEL + x - 1;
            valueLabel.text = (x == 0? nil:values[x - 1]);
            valueLabel.textColor = [UIColor whiteColor];
            [_headView addSubview:valueLabel];
            if (x == 0) {
                _startLabel = valueLabel;
                NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:_firstTime];
                _startLabel.text = [FSDate stringWithDate:date formatter:nil];
            }
            if (x == 9) {
                valueLabel.textColor = (holdDays < Days_Holddays ? [UIColor yellowColor]:[UIColor whiteColor]);
            }
            if (x == 10) {
                valueLabel.textColor = (cashHoldDays < Days_Holddays_Power ? [UIColor yellowColor]:[UIColor whiteColor]);
            }
            if (x == 11) {
                valueLabel.textColor = (cashHoldDays < Days_Cashdays ? [UIColor yellowColor]:[UIColor whiteColor]);
            }
        }
        
        UILabel *zLabel = [FSViewManager labelWithFrame:CGRectMake(15, 20 + 30 * titles.count + FS_LineThickness, WIDTHFC - 15, 30) text:NSLocalizedString(@"Debt asset ratio change:", nil) textColor:[UIColor whiteColor] backColor:nil font:nil textAlignment:NSTextAlignmentLeft];
        [_headView addSubview:zLabel];
        _rateLabel = [FSViewManager labelWithFrame:CGRectMake(WIDTHFC - 100, zLabel.top, 85, 30) text:@"0.00%" textColor:[UIColor yellowColor] backColor:nil font:nil textAlignment:NSTextAlignmentRight];
        [_headView addSubview:_rateLabel];
        
        _slider = [[UISlider alloc] initWithFrame:CGRectMake(10, _rateLabel.bottom + 10, WIDTHFC - 20, 36)];
        [_slider addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventValueChanged];
        _slider.minimumValue = 0;
        _slider.maximumValue = 1;
        _slider.tintColor = [UIColor whiteColor];
        [_headView addSubview:_slider];
        
        NSArray *zTitles = @[NSLocalizedString(@"All assets", nil),NSLocalizedString(@"All liabilities", nil),NSLocalizedString(@"Repaying capability", nil)];
        for (int x = 0; x < 3; x ++) {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, _slider.bottom + 10 + 30 * x, WIDTHFC, 30)];
            label.text = zTitles[x];
            label.textColor = [UIColor whiteColor];
            [_headView addSubview:label];
            
            UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, label.top, self.view.bounds.size.width - 15, 30)];
            valueLabel.textAlignment = NSTextAlignmentRight;
            valueLabel.tag = TAG_BUTTON + x;
            valueLabel.text = (x == 0?[self tenthousandForMoney:_jzc]:@"0.00");
            valueLabel.textColor = [UIColor whiteColor];
            [_headView addSubview:valueLabel];
        }
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.tableHeaderView = _headView;
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
        _tableView.showsVerticalScrollIndicator = NO;
        [self doSomethingRepeatedly];
    }else{
        for (int x = 0; x < values.count; x ++) {
            UILabel *label = [_headView viewWithTag:TAG_LABEL + x];
            label.text = values[x];
        }
        
        if (_hasFirst) {
            return;
        }else{
            _hasFirst = YES;
        }
        
        CGFloat jzc = _jzc + _addMoney;
        CGFloat debt = Key_Year_Many * 365 * _dayMoney;
        /*
          * debt不包含将要承担的利息，所以如果利率很高，就会不适用
            
            CGFloat debt = (_dayMoney / 2.0f) * DAYS_IN_A_MONTH * self.loanMonth / times - _debt;
            方法一：CGFloat debt = (_dayMoney / 2.0f) * DAYS_IN_A_MONTH * self.loanMonth / [FuData DEBXWithYearRate:self.loanRate monthes:self.loanMonth] - _debt;
            原理：在还款时限内，只一半的预期净收入用于偿还所有的债务和利息
            优点：看似留足了足够的边际
            缺点：平时不能做那么长的预测，特别是十多年。
         
            方法二：CGFloat debt = 6 * 365 * _dayMoney;
            原理：美元通胀率4.05%，人民币通胀率6%，物价每年复合上涨6.38%。
            格雷厄姆认为16倍市盈率是安全的最上边界，巴菲特打4折即6.4倍市盈率就是留有“足够的”安全边际
            优点：容易理解
            缺点：有点生硬，如果短期借款太多就会不太适用，因为把余钱全用来还债不太符合现实情况
         */
        
        UILabel *debtLabel = [_headView viewWithTag:TAG_BUTTON + 1];
        debtLabel.text = [self tenthousandForMoney:debt];
        
        CGFloat time = (debt / MAX(0.01, _dayMoney)) / 365;
        UILabel *payLabel = [_headView viewWithTag:TAG_BUTTON + 2];
        payLabel.text = [[NSString alloc] initWithFormat:@"%.2f%@",time,NSLocalizedString(@"year", nil)];
        if (time > 5.0) {
            payLabel.textColor = [UIColor yellowColor];
        }else{
            payLabel.textColor = [UIColor whiteColor];
        }
        
        UILabel *allLabel = [_headView viewWithTag:TAG_BUTTON];
        allLabel.text = [self tenthousandForMoney:jzc + debt];
        CGFloat rate = debt / MAX(0.01, (debt + jzc));
        _slider.value = rate;
        _rateLabel.text = [[NSString alloc] initWithFormat:@"%.2f%@",_slider.value * 100,@"%"];
        _rateLabel.textColor = (rate > 0.6)?[UIColor yellowColor]:[UIColor whiteColor];

        [_tableView reloadData];
        self.view.backgroundColor = [UIColor whiteColor];
    }
}

- (void)sliderAction:(UISlider *)slider{
    if (slider.value == 1) {
        return;
    }
    CGFloat rate = slider.value;
    _rateLabel.text = [[NSString alloc] initWithFormat:@"%.2f%@",rate * 100,@"%"];

    CGFloat debt = _jzc * rate / (1 - rate);
    CGFloat allM = debt + _jzc;
    CGFloat payBack = debt / MAX(_dayMoney, 0.01);
    
    UIColor *yellowColor = [UIColor yellowColor];
    UIColor *whiteColor = [UIColor whiteColor];
    
    NSArray *texts = @[[[NSString alloc] initWithFormat:@"%@",[self tenthousandForMoney:allM]],[[NSString alloc] initWithFormat:@"%@",[self tenthousandForMoney:debt]],[[NSString alloc] initWithFormat:@"%@",[FSKitDuty dayMonthYearForNumber:payBack]]];
    for (int x = 0; x < 3; x ++) {
        UILabel *label = [_headView viewWithTag:TAG_BUTTON + x];
        label.text = texts[x];
        
        if (x == 2) {
            BOOL overPay = payBack > Key_Year_Many * 365;
            label.textColor = overPay?yellowColor:whiteColor;
            _rateLabel.textColor = overPay?yellowColor:whiteColor;
        }
    }
}

- (void)bbiAction{
    WEAKSELF(this);
    [FSUIKit alertInput:3 controller:self title:NSLocalizedString(@"Increase and stock", nil) message:NSLocalizedString(@"Unit:ten thousand", nil) ok:@"OK" handler:^(UIAlertController *bAlert, UIAlertAction *action) {
        UITextField *textField = bAlert.textFields.firstObject;
        UITextField *addTF = bAlert.textFields[1];
        UITextField *costTF = bAlert.textFields[2];
        this.deltaMoney = [textField.text doubleValue] * 10000;
        this.addMoney = [addTF.text doubleValue] * 10000;
        this.newCost = [costTF.text doubleValue] * 10000;
        this.hasFirst = NO;
        [this expectDesignViews];
    } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
        if (textField.tag == 1) {
            textField.placeholder = NSLocalizedString(@"Stock(unit:ten thousand)", nil);
        }else if (textField.tag == 0){
            textField.placeholder = NSLocalizedString(@"Increase pey month(unit:ten thousand)", nil);
        }else if (textField.tag == 2){
            textField.placeholder = @"每个月的成本增量（单位：万）";
        }
    } completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.textSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    cell.textLabel.text = _textSource[indexPath.row];
    if (indexPath.row <= 2) {
        NSInteger number = 365 * (1 + indexPath.row * 2);
        cell.detailTextLabel.text = [self tenthousandForMoney:_addMoney + _jzc + number * _dayMoney];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (NSString *)tenthousandForMoney:(CGFloat)money{
    if (money < 10000) {
        return [[NSString alloc] initWithFormat:@"%.2f",money];
    }else{
        return [[NSString alloc] initWithFormat:@"%.2f万",money / 10000.0];
    }
}

- (NSString *)moneyFormat:(CGFloat)je{
    return [[NSString alloc] initWithFormat:@"%.2f",je];
}

- (NSString *)dayMonthYearForNumber:(CGFloat)number type:(NSString *)insert{
    if (number > 365) {
        return [[NSString alloc] initWithFormat:@"%.2f%@%@",number / 365.0,insert,NSLocalizedString(@"year", nil)];
    }else if (number > 30){
        return [[NSString alloc] initWithFormat:@"%.2f%@%@",number / 30,insert,NSLocalizedString(@"month", nil)];
    }else{
        return [[NSString alloc] initWithFormat:@"%.2f%@%@",number,insert,NSLocalizedString(@"day", nil)];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
