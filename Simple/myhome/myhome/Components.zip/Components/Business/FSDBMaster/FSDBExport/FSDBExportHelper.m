//
//  FSDBExportHelper.m
//  myhome
//
//  Created by FudonFuchina on 2017/9/15.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSDBExportHelper.h"
#import "FATool.h"
#import "FSMacro.h"
#import "FSDBMaster.h"
#import "FSABModel.h"
#import "FSABTrackModel.h"
#import "FSContactModel.h"
#import "FSPwdBookModel.h"
#import "FSDiaryModel.h"
#import "FSLocationModel.h"
#import "FSABBirthModel.h"
#import "FSAlertModel.h"
#import <FSRuntime.h>

@implementation FSDBExportHelper

+ (Class)classFromDic:(NSDictionary *)dic{
    NSString *table = [dic objectForKey:_transfer_table_name];
    Class name = NSClassFromString(table);
    if (!name) {
        return nil;
    }
    return NSClassFromString([self classForTable:table]);
}

+ (NSString *)classForTable:(NSString *)table{
    NSString *className = nil;
    if ([table hasPrefix:@"ab_"]) {
        className = @"FSABModel";
    }else{
        if ([table isEqualToString:_tb_abTrack]) {      // 账本增减记录表
            return @"FSABTrackModel";
        }else if ([table isEqualToString:_tb_abname]){  // 账本名
            
        }else if ([table isEqualToString:_tb_abform]){  // 账本模板
            
        }else if ([table isEqualToString:_tb_net]){     // 增加网址
            
        }else if ([table isEqualToString:_tb_url]){     // 网址导航
            
        }else if ([table isEqualToString:_tb_contact]){// 通讯录
            return @"FSContactModel";
        }else if ([table isEqualToString:_tb_birth]){   // 生日表
            return @"FSABBirthModel";
        }else if ([table isEqualToString:_tb_diary]){   // 日记
            return @"FSDiaryModel";
        }else if ([table isEqualToString:_tb_alert]){   // 提醒
            return @"FSFutureAlertModel";
        }else if ([table isEqualToString:_tb_location]){// 地址
            return @"FSLocationModel";
        }else if ([table isEqualToString:_tb_password]){// 密码
            return @"FSPwdBookModel";
        }
    }
        return className;
}

+ (NSString *)hansForModel:(Class)Model field:(NSString *)field value:(NSString *)value{
    if ([field isEqualToString:@"time"]) {
        return [FSKit ymdhsByTimeIntervalString:value];
    }
    
    if ([[Model new] isKindOfClass:NSClassFromString(@"FSABModel")]) {
        if ([field isEqualToString:@"atype"] || [field isEqualToString:@"btype"]) {
            return [FATool noticeForType:value];
        }
    }
    return value;
}

@end
