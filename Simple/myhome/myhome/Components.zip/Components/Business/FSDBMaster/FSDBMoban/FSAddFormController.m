//
//  FSAddFormController.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/20.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSAddFormController.h"
#import "FATool.h"
#import "FSDBSupport.h"
#import "FSDBTool.h"
#import "FSHalfView.h"
#import "FSFormModel.h"
#import <FSUIKit.h>

static  NSString    *_sep_flag = @"|";

static NSString     *_key_db_form = @"_key_db_form";
@interface FSAddFormController ()

@property (nonatomic,strong) NSMutableArray     *list;
@property (nonatomic,strong) FSHalfView         *halfView;
@property (nonatomic,strong) UIButton           *selButton;
@property (nonatomic,copy)   NSString           *atype;
@property (nonatomic,copy)   NSString           *btype;

@end

@implementation FSAddFormController{
    UITextField     *_textField;
    NSDictionary    *_cacheDic;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Add form", nil);
    if (!_abtype) {
        NSDictionary *dic = _fs_userDefaults_objectForKey(_key_db_form);
        if ([dic isKindOfClass:NSDictionary.class]) {
            _atype = [dic objectForKey:@"a"];
            _btype = [dic objectForKey:@"b"];
        }else{
            _atype = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ING_KEY];
            _btype = [[NSString alloc] initWithFormat:@"%@%@",_subject_XJ,_ED_KEY];
        }
        _abtype = [[NSString alloc] initWithFormat:@"%@%@%@",_atype,_sep_flag,_btype];
    }else{
        NSArray *types = [_abtype componentsSeparatedByString:_sep_flag];
        if (types.count == 2) {
            _atype = types.firstObject;
            _btype = types.lastObject;
        }else{
            _atype = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ING_KEY];
            _btype = [[NSString alloc] initWithFormat:@"%@%@",_subject_XJ,_ED_KEY];
            _abtype = [[NSString alloc] initWithFormat:@"%@%@%@",_atype,_sep_flag,_btype];
        }
    }
    [self addFormDesignViews];
}

- (void)addFormDesignViews{
    CGFloat btnWidth = (WIDTHFC - 40) / 2;
    NSArray *titles = @[[FATool noticeForType:_atype],[FATool noticeForType:_btype]];
    for (int x = 0; x < 2; x ++) {
        UIButton *button = [FSViewManager buttonWithFrame:CGRectMake(15 + x * (btnWidth + 10),20, btnWidth, 44) title:titles[x] titleColor:[UIColor whiteColor] backColor:THISCOLOR fontInt:15 tag:TAG_BUTTON + x target:self selector:@selector(btnClick:)];
        button.layer.cornerRadius = 3;
        [self.scrollView addSubview:button];
    }
    _textField = [FSViewManager textFieldWithFrame:CGRectMake(15, 90, self.view.frame.size.width - 30, 44) placeholder:NSLocalizedString(@"Please input message", nil) textColor:nil backColor:[UIColor whiteColor]];
    _textField.layer.cornerRadius = 3;
    _textField.textAlignment = NSTextAlignmentCenter;
    [self.scrollView addSubview:_textField];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(15, 154, WIDTHFC - 30, 44);
    btn.backgroundColor = THISCOLOR;
    [btn setTitle:NSLocalizedString(@"Commit", nil) forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(addMoban) forControlEvents:UIControlEventTouchUpInside];
    [self.scrollView addSubview:btn];
}

- (void)addMoban{
    if (_textField.text.length == 0) {
        [FSToast show:NSLocalizedString(@"Please Input Note", nil)];
        return;
    }
    Tuple2 *t2 = [FSDBTool returnErrorStringIfOccurrError:@[_atype,_btype]];
    if (![t2._1 boolValue]) {
        [FSUIKit showAlertWithMessage:t2._2 controller:self];
        return;
    }
    
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE abtype = '%@' and bz = '%@' limit 0,1;",_tb_abform,_abtype,_textField.text];
    NSMutableArray *list = [FSDBSupport querySQL:sql class:FSFormModel.class tableName:_tb_abform];
    if (list.count) {
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }    
    NSString *error = [master insert_fields_values:@{
                                                     @"time":@(_fs_integerTimeIntevalSince1970()),
                                                     @"abtype":_abtype,
                                                     @"bz":_textField.text,
                                                     @"type":self.type,
                                                     @"freq":@"0"
                                                     } table:_tb_abform];
    
    if (error) {
        [FSUIKit showAlertWithMessage:error controller:self];
        return;
    }
    _fs_userDefaults_setObjectForKey(@{@"a":_atype,@"b":_btype}, _key_db_form);
    [FSToast show:@"增加模板成功"];
    if (![FSKit popToController:@"FSDBMobanController" navigationController:self.navigationController animated:YES]) {
        [self.navigationController popViewControllerAnimated:YES];
    };
}

- (void)btnClick:(UIButton *)button{
    _selButton = button;
    [self showHalfView];
}

- (void)showHalfView{
    [self.view endEditing:YES];
    
    if (!self.list) {
        _list = [[NSMutableArray alloc] initWithArray:[FATool debtors]];
        [_list addObjectsFromArray:[FATool creditors]];
    }
    if (!self.halfView) {
        WEAKSELF(this);
        self.halfView = [[FSHalfView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64)];
        self.halfView.dataSource = self.list;
        [self.view addSubview:self.halfView];
        [_halfView setConfigCell:^(UITableView *bTB, NSIndexPath *bIP,UITableViewCell *bCell) {
            bCell.textLabel.text = [FATool noticeForType:this.list[bIP.row]];
        }];
        [_halfView setSelectCell:^(UITableView *bTB, NSIndexPath *bIP) {
            NSString *str = this.list[bIP.row];
            BOOL isArest = this.selButton.tag == TAG_BUTTON;
            [this.selButton setTitle:[FATool noticeForType:str] forState:UIControlStateNormal];
            
            if (isArest) {
                this.atype = str;
            }else{
                this.btype = str;
            }
            this.abtype = [[NSString alloc] initWithFormat:@"%@%@%@",this.atype,_sep_flag,this.btype];
        }];
    }else{
        self.halfView.dataSource = self.list;
        [self.halfView showHalfView:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
