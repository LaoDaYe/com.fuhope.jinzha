//
//  FSDBMobanController.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/4.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSDBMobanController.h"
#import "FSDBSupport.h"
#import "FSDBAddMobanController.h"
#import <MJRefresh.h>
#import "FATool.h"
#import "FSDBTool.h"
#import "FSAccountRecordController.h"
#import "FSAddFormController.h"
#import "FSFormModel.h"
#import "UIViewController+BackButtonHandler.h"
#import "FSBaseAPI.h"
#import <FSUIKit.h>
#import "FSMobanAPI.h"

@interface FSDBMobanController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,assign) NSInteger          page;
@property (nonatomic,strong) NSMutableArray     *list;
@property (nonatomic,strong) UITableView        *tableView;
@property (nonatomic,strong) NSDate             *date;

@end

@implementation FSDBMobanController{
    UITextField     *_textField;
    BOOL            _canPop;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Bookkeeping", nil);
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addMoban)];
    UIBarButtonItem *bbi2 = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Supplement", nil) style:UIBarButtonItemStylePlain target:self action:@selector(dateAction)];
    self.navigationItem.rightBarButtonItems = @[bbi,bbi2];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self mobanHandleDatas];
}

- (void)addMoban{
    FSAddFormController *add = [[FSAddFormController alloc] init];
    add.type = @([self.type integerValue]);
    [self.navigationController pushViewController:add animated:YES];
}

- (void)dateAction{
    [self.view endEditing:YES];
    WEAKSELF(this);
    FSAccountRecordController *saveViewController = [[FSAccountRecordController alloc] init];
    [this.navigationController pushViewController:saveViewController animated:YES];
    saveViewController.block = ^(FSBaseController *bVC, NSDate *date) {
        this.date = date;
        this.title = [[FSKit ymdhsByTimeInterval:[date timeIntervalSince1970]] substringToIndex:10];
        [bVC.navigationController popViewControllerAnimated:YES];
    };
}

- (void)mobanHandleDatas{
    self.vanView.status = FSLoadingStatusLoading;
    NSInteger unit = 10;
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT DISTINCT abtype FROM %@ order by cast(freq as INT) DESC limit %@,%@;",_tb_abform,@(self.page * unit),@(unit)];
    NSMutableArray *list = [FSDBSupport querySQL:sql class:FSFormModel.class tableName:_tb_abform];
    if (self.page) {
        if (list.count) {
            [self.list addObjectsFromArray:list];
        }
    }else{
        self.list = list;
    }
    __weak typeof(self)this = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [this.vanView dismiss];
        [this mobanDesignViews];
    });
}

- (void)mobanDesignViews{
    if (_tableView) {
        [_tableView reloadData];
        [self.tableView.mj_header endRefreshing];
        [self.tableView.mj_footer endRefreshing];
        return;
    }
    CGSize size = [UIScreen mainScreen].bounds.size;
    _textField = [[UITextField alloc] initWithFrame:CGRectMake(15, 20, size.width - 30, 40)];
    _textField.placeholder = NSLocalizedString(@"Enter the amount and start billing", nil);
    _textField.backgroundColor = [UIColor whiteColor];
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _textField.layer.cornerRadius = 3;
    _textField.keyboardType = UIKeyboardTypeDecimalPad;
    _textField.textAlignment = NSTextAlignmentCenter;
    
    if (self.list.count && self.page == 0) {
        [_textField becomeFirstResponder];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self->_canPop = YES;
        });
    }else{
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Tips", nil) message:NSLocalizedString(@"Click '+' to Add", nil) actionTitles:@[NSLocalizedString(@"Add", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            [self addMoban];
        }];
    }
    
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, 80)];
    headView.backgroundColor = RGBCOLOR(18, 152, 233, 1);
    [headView addSubview:_textField];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, size.width, size.height - 64) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableHeaderView = headView;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.tableFooterView = [UIView new];
    self.tableView.rowHeight = 54;
    [self.view addSubview:self.tableView];
    __weak typeof(self)this = self;
    _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        this.page = 0;
        [this mobanHandleDatas];
    }];
    _tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        this.page ++;
        [this mobanHandleDatas];
    }];
}

-(BOOL)navigationShouldPopOnBackButton{
    if (!_canPop) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
    }else{
        return YES;
    }
    return NO;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    FSFormModel *model = [self.list objectAtIndex:indexPath.row];
    cell.textLabel.text = [FSFormModel parseABType:model.abtype];
    return cell;
}

//- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (editingStyle == UITableViewCellEditingStyleDelete) {
//        FSFormModel *model = [self.list objectAtIndex:indexPath.row];
//        [FSBaseAPI deleteModelBusiness:model table:_tb_abform controller:self success:^{
//            [self mobanHandleDatas];
//        } fail:^(NSString *error) {
//            [FSUIKit showAlertWithMessage:error controller:self];
//        } cancel:^{
//            tableView.editing = NO;
//        }];
//    }
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    FSFormModel *model = [self.list objectAtIndex:indexPath.row];
    
    FSDBAddMobanController *add = [[FSDBAddMobanController alloc] init];
    add.model = model;
    add.type = self.type;
    if (_textField.text.length == 0) {
        add.editOrSelect = YES;
    }else{
        if (!_fs_isPureFloat(_textField.text)) {
            [FSToast show:NSLocalizedString(@"Please Input Money", nil)];
            return;
        }
        WEAKSELF(this);
        add.callback = ^(FSDBAddMobanController *bVC, NSString *bText) {
            [bVC.navigationController popViewControllerAnimated:YES];
            [this execAction:bText model:model];
        };
    }
    [self.navigationController pushViewController:add animated:YES];
}

- (void)execAction:(NSString *)bz model:(FSFormModel *)model{
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:bz message:[FSFormModel parseABType:model.abtype] actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        Tuple2 *t = [FSFormModel typesOfABType:model.abtype];
        NSString *atype = t._1;
        NSString *btype = t._2;
        if (!_fs_isValidateString(atype)) {
            return;
        }
        if (!_fs_isValidateString(btype)) {
            return;
        }
        if (!_fs_isValidateString(bz)) {
            return;
        }
        if (!_fs_isValidateString(self.account)) {
            return;
        }
        
        [FSDBTool handleDatas:@[atype,btype] account:self.account date:[self.date isKindOfClass:NSDate.class]?self.date:[NSDate date] je:self->_textField.text bz:bz controller:self type:self.type completion:^{
            [FSKit popToController:@"FSABOverviewController" navigationController:self.navigationController animated:YES];
        }];
    }];
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (decelerate) {
        [self.view endEditing:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
