//
//  FSAddFormController.h
//  myhome
//
//  Created by FudonFuchina on 2017/8/20.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSAddFormController : FSBaseController

@property (nonatomic,copy) NSString     *abtype;
@property (nonatomic,strong) NSNumber   *type;

@end
