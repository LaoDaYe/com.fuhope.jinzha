//
//  FSDBAddMobanController.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/6.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSDBAddMobanController.h"
#import "FATool.h"
#import "FSDBSupport.h"
#import <FSTuple.h>
#import "FSDBTool.h"
#import "FSFormModel.h"
#import <MJRefresh.h>
#import "FSTextViewController.h"
#import "FSAddFormController.h"
#import "FSBaseAPI.h"
#import <FSUIKit.h>

@interface FSDBAddMobanController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray     *list;
@property (nonatomic,strong) UITableView        *tableView;
@property (nonatomic,assign) NSInteger          page;

@end

@implementation FSDBAddMobanController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addMobanHandleDatas];
}

- (void)addMobanHandleDatas{
    NSInteger unit = 100;
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE abtype = '%@' and type = '%@' order by cast(freq as INTEGER) DESC limit %@,%@;",_tb_abform,_model.abtype,self.type,@(_page * unit),@(unit)];
    NSMutableArray *list = [FSDBSupport querySQL:sql class:FSFormModel.class tableName:_tb_abform];
    if (_page) {
        [self.list addObjectsFromArray:list];
    }else{
        self.list = list;
    }
    [self addMobanDesignViews];
}

- (void)addMobanDesignViews{
    if (_tableView) {
        [_tableView reloadData];
        [_tableView.mj_footer endRefreshing];
        [_tableView.mj_header endRefreshing];
        return;
    }
    self.title = NSLocalizedString(@"Edit template", nil);
    if (_editOrSelect) {
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addMoban)];
        self.navigationItem.rightBarButtonItem = bbi;
    }
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, HEIGHTFC - 64) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIView new];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.rowHeight = 50;
    [self.view addSubview:_tableView];
    __weak typeof(self)this = self;
    _tableView.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        this.page = 0;
        [this addMobanHandleDatas];
    }];
    this.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        this.page ++;
        [this addMobanHandleDatas];
    }];
}

- (void)addMoban{
    FSAddFormController *add = [[FSAddFormController alloc] init];
    add.abtype = _model.abtype;
    add.type = @([self.type integerValue]);
    [self.navigationController pushViewController:add animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:8];
    }
    FSFormModel *model = [self.list objectAtIndex:indexPath.row];
    cell.textLabel.text = model.bz;
    cell.detailTextLabel.text = model.freq;
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return _editOrSelect;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        FSFormModel *model = [self.list objectAtIndex:indexPath.row];
        [FSBaseAPI deleteModelBusiness:model table:_tb_abform controller:self success:^{
            [self addMobanHandleDatas];
        } fail:^(NSString *error) {
            [FSUIKit showAlertWithMessage:error controller:self];
        } cancel:^{
            tableView.editing = NO;
        }];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    FSFormModel *model = [self.list objectAtIndex:indexPath.row];
    
    if (_editOrSelect) {
        FSTextViewController *controller = [[FSTextViewController alloc] init];
        controller.text = model.bz;
        controller.title = NSLocalizedString(@"Edit note", nil);
        [self.navigationController pushViewController:controller animated:YES];
        controller.callback = ^(FSTextViewController *bVC, NSString *bText) {
            if (bText.length == 0) {
                [FSToast show:NSLocalizedString(@"Please Input Note", nil)];
                return;
            }
            [bVC.navigationController popViewControllerAnimated:YES];
            
            FSDBMaster *master = [FSDBMaster sharedInstance];
            NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET bz = '%@' WHERE aid = %@;",_tb_abform,bText,model.aid];
            NSString *error = [master updateSQL:sql];
            if (error) {
                [FSUIKit showAlertWithMessage:error controller:self];
                return;
            }
            [self addMobanHandleDatas];
        };
    }else{
        if (self.callback) {
            [self updateData:model];
            self.callback(self, model.bz);
        }
    }
}

- (void)updateData:(FSFormModel *)model{
    if (![model isKindOfClass:FSFormModel.class]) {
        return;
    }
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET freq = '%@' WHERE aid = %@;",_tb_abform,@([model.freq integerValue] + 1),model.aid];
    [master updateSQL:sql];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
