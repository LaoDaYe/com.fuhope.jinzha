//
//  FSFMListController.m
//  SQL
//
//  Created by fudon on 2016/8/24.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSAccountListController.h"
#import "FSDBSupport.h"
#import "MJRefresh.h"
#import "FSABModel.h"
#import "FSABListCell.h"
#import "FSABSearchController.h"
#import "FSABSearchTimeController.h"
#import "FATool.h"
#import <FSUIKit.h>
#import "FSABSearchResultView.h"
#import "FSDBTool.h"
#import "FSTrackKeys.h"

@interface FSAccountListController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView        *tableView;
@property (nonatomic,strong) NSMutableArray     *array;
@property (nonatomic,assign) NSInteger          page;

@end

@implementation FSAccountListController

- (void)viewDidLoad{
    [super viewDidLoad];
    [FSTrack event:_UMeng_Event_acc_li];
    [self listHandleDatas];
}

- (void)listHandleDatas{
    _fs_dispatch_global_main_queue_async(^{
        NSInteger unit = 30;
        NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by cast(time as REAL) DESC limit %@,%@;",self->_accountName,@(self.page * unit),@(unit)];
        NSMutableArray *allDatas = [FSDBSupport querySQL:sql class:FSABModel.class tableName:self->_accountName];
        for (FSABModel *model in allDatas) {
            [model processPropertiesWithType:nil canSeeTrack:NO search:nil isCompany:NO];
        }
        
        if (self.page) {
            [self.array addObjectsFromArray:allDatas];
        }else{
            self.array = allDatas;
        }
    }, ^{
        [self listDesignViews];
    });    
}

- (void)searchActionCustom{
    FSABSearchController *search = [[FSABSearchController alloc] init];
    [self.navigationController pushViewController:search animated:YES];
    __weak typeof(self)this = self;
    search.searchEvent = ^(FSABSearchController *vc, NSString *text) {
        if (text.length) {
            NSString *like = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (bz lIKE '%%%@%%' OR je LIKE '%%%@%%') order by cast(time as REAL) DESC limit 0,200;",this.accountName,text,text];
            this.array = [FSDBSupport querySQL:like class:FSABModel.class tableName:this.accountName];
            for (FSABModel *model in this.array) {
                [model processPropertiesWithType:nil canSeeTrack:NO search:text isCompany:NO];
            }
            FSABSearchResultView *view = (FSABSearchResultView *)vc.resultView;
            if (!view) {
                view = [[FSABSearchResultView alloc] initWithFrame:CGRectMake(0, 70, WIDTHFC, HEIGHTFC - 70)];
                vc.resultView = view;
            }
            view.list = this.array;
        }
    };
}

- (void)listDesignViews{
    if (!_tableView) {
        FSDBMaster *manager = [FSDBMaster sharedInstance];
        self.title = [[NSString alloc] initWithFormat:@"报表(%d条)",[manager countForTable:_accountName]];
        
        UIBarButtonItem *bbi = [FSViewManager bbiWithSystemType:UIBarButtonSystemItemSearch target:self action:@selector(searchActionCustom)];
        UIBarButtonItem *pdf = [FSViewManager bbiWithSystemType:UIBarButtonSystemItemAdd target:self action:@selector(pdfAction)];
        self.navigationItem.rightBarButtonItems = @[bbi,pdf];
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        [self.view addSubview:_tableView];
        WEAKSELF(this);
        _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            this.page = 0;
            [this listHandleDatas];
        }];
        _tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            this.page ++;
            [this listHandleDatas];
        }];
    }else{
        [_tableView.mj_footer endRefreshing];
        [_tableView.mj_header endRefreshing];
        [_tableView reloadData];
    }
}

- (void)pdfAction{
     NSString *pullout = NSLocalizedString(@"Export", nil);
     NSString *search = NSLocalizedString(@"Search", nil);
    NSNumber *type = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[search,pullout] styles:@[type,type] handler:^(UIAlertAction *action) {
        if ([action.title isEqualToString:pullout]) {
            [FSDBTool sendAccountList:self.accountName entity:self->_entity];
        }else if ([action.title isEqualToString:search]){
            FSABSearchTimeController *time = [[FSABSearchTimeController alloc] init];
            time.tableName = self.accountName;
            [self.navigationController pushViewController:time animated:YES];
        }
    }];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _array.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (FSABListCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSABListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[FSABListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.index = indexPath.section;
    
    FSABModel *entity = [_array objectAtIndex:indexPath.section];
    [cell flowConfigDataWithEntity:entity];
    return  cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSABModel *entity = [_array objectAtIndex:indexPath.section];
    return entity.cellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return section == 0?10:.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 3;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    FSABModel *entity = [_array objectAtIndex:indexPath.section];

    NSString *aSubject = [FATool hansForShort:entity.atype];
    NSString *bSubject = [FATool hansForShort:entity.btype];
    NSNumber *alertType = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[aSubject,bSubject] styles:@[alertType,alertType] handler:^(UIAlertAction *action) {
        BOOL isA = [action.title isEqualToString:aSubject];
        [FSDBTool pushToAccountUpdateController:self.navigationController entity:entity isA:isA account:self.accountName];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
