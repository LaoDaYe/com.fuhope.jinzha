//
//  FSAnnalDetailController.m
//  myhome
//
//  Created by FudonFuchina on 2018/1/14.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSAnnalDetailController.h"
#import "FSDBTool.h"
#import "FSAccountConfiger.h"
#import "FSAnnalDetailCell.h"
#import "FSShare.h"
#import "FSPublic.h"
#import "FSTrackKeys.h"

@interface FSAnnalDetailController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) UIView         *headView;
@property (nonatomic,strong) NSDictionary   *model;

@end

@implementation FSAnnalDetailController{
@private    NSArray      *_subjects;
@private    NSArray      *_heads;
@private    NSArray      *_hValues;
@private    NSInteger    _click;
}

- (void)shakeEndActionFromShakeBase{
    [FSPublic shareAction:self view:_tableView];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self annalHandleDatas];
    [FSTrack event:_UMeng_Event_annalDetail];
}

- (void)annalHandleDatas{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [FSDBTool scanAccount:self.accountName wantYear:self.year completion:^(NSDictionary *value) {
            if (!value) {
                if (self->_click == 1) {
                    self.year ++;
                }else if (self->_click == 2){
                    self.year --;
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    [FSToast show:@"无更多数据"];
                });
                return;
            }
            self.model = value;
            [self handleRest:value];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self annalDesignViews];
            });
        }];
    });
}

- (void)handleRest:(NSDictionary *)dic{
    if (!_subjects) {
        _subjects = @[[Tuple5 v1:_subject_YS v2:@"应收" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_XJ v2:@"现金" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_CH v2:@"存货" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_TZ v2:@"投资" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_GZ v2:@"固资" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_TX v2:@"摊销" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_FZ v2:@"负债" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_PS v2:@"预收" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_BJ v2:@"本金" v3:nil v4:nil v5:nil],
                      [Tuple5 v1:_subject_GB v2:@"股本" v3:nil v4:nil v5:nil],
                      ];
        _heads = @[@"收入",@"成本",@"利润",@"净利率",@"资债率",@"净资产",@"负债",@"总资产",@"净资收益率",@"资产周转率"];
    }
    UIColor *redColor = APPCOLOR;
    UIColor *greenColor = FS_GreenColor;
    CGFloat zc = 0;
    CGFloat fz = 0;
    CGFloat lastYearAssets = 0;
    CGFloat lastYearDebt = 0;
    for (int x = 0; x < _subjects.count; x ++) {
        Tuple5 *t = _subjects[x];
        NSString *p = [[NSString alloc] initWithFormat:@"%@%@",t._1,_ING_KEY];
        NSString *m = [[NSString alloc] initWithFormat:@"%@%@",t._1,_ED_KEY];
        CGFloat vp = [[dic objectForKey:p] doubleValue];
        CGFloat vm = [[dic objectForKey:m] doubleValue];
        CGFloat delta = vp - vm;
        t._3 = [[NSString alloc] initWithFormat:@"%@%.2f",delta>0?@"+":@"",delta];
        t._4 = delta > 0?greenColor:redColor;
        NSDictionary *r = [dic objectForKey:t._1];
        CGFloat rest = 0;
        if (r) {
            rest = [[dic objectForKey:t._1] doubleValue];
        }else{
            rest = delta;
        }
        t._5 = [[NSString alloc] initWithFormat:@"%.2f",rest];
        if (x < 6) {
            zc += rest;
            lastYearAssets += (rest - delta);
        }
        if (x == 6 || x == 7) {
            fz += rest;
            lastYearDebt += (rest - delta);
        }
    }
    CGFloat jzc = zc - fz;
    NSString *srp = [[NSString alloc] initWithFormat:@"%@%@",_subject_SR,_ING_KEY];
    NSString *srm = [[NSString alloc] initWithFormat:@"%@%@",_subject_SR,_ED_KEY];
    NSString *cbp = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ING_KEY];
    NSString *cbm = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ED_KEY];
    CGFloat sr = [[dic objectForKey:srp] doubleValue] - [[dic objectForKey:srm] doubleValue];
    CGFloat cb = [[dic objectForKey:cbp] doubleValue] - [[dic objectForKey:cbm] doubleValue];
    CGFloat profit = sr - cb;
    CGFloat zzl = fz / MAX(zc, 0.01);
    CGFloat jlv = profit / MAX(sr, 0.01);
    CGFloat lastYearJZC = lastYearAssets - lastYearDebt;
    CGFloat roe = profit * 2 / (lastYearJZC + jzc + 0.01);
    CGFloat zczzl = sr * 2 / (lastYearAssets + zc + 0.01);
    _hValues = @[
    [[NSString alloc] initWithFormat:@"%.2f",sr],
    [[NSString alloc] initWithFormat:@"%.2f",cb],
    [[NSString alloc] initWithFormat:@"%.2f",profit],
    [[NSString alloc] initWithFormat:@"%.2f%%",jlv * 100],
    [[NSString alloc] initWithFormat:@"%.2f%%",zzl * 100],
    [[NSString alloc] initWithFormat:@"%.2f",jzc],
    [[NSString alloc] initWithFormat:@"%.2f",fz],
    [[NSString alloc] initWithFormat:@"%.2f",zc],
    [[NSString alloc] initWithFormat:@"%.2f%%",roe * 100],
    [[NSString alloc] initWithFormat:@"%.2f%%",zczzl * 100],
                 ];
}

- (void)annalDesignViews{
    self.title = @(_year).stringValue;
    if (!_tableView) {
        UIBarButtonItem *front = [[UIBarButtonItem alloc] initWithTitle:@"前一年" style:UIBarButtonItemStylePlain target:self action:@selector(frontYear)];
        UIBarButtonItem *next = [[UIBarButtonItem alloc] initWithTitle:@"后一年" style:UIBarButtonItemStylePlain target:self action:@selector(backYear)];
        self.navigationItem.rightBarButtonItems = @[next,front];

        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 50;
        _tableView.showsVerticalScrollIndicator = NO;
        [self.view addSubview:_tableView];
        
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, _heads.count * 30 + 20)];
        _headView.backgroundColor = FS_GreenColor;
        _tableView.tableHeaderView = _headView;
        
        for (int x = 0; x < _heads.count; x ++) {
            UILabel *left = [[UILabel alloc] initWithFrame:CGRectMake(15, 10 + x * 30, WIDTHFC / 2, 30)];
            left.textColor = [UIColor whiteColor];
            left.text = _heads[x];
            [_headView addSubview:left];
            
            UILabel *right = [[UILabel alloc] initWithFrame:CGRectMake(WIDTHFC / 4, 10 + x * 30, WIDTHFC * .75 - 10, 30)];
            right.textColor = [UIColor whiteColor];
            right.textAlignment = NSTextAlignmentRight;
            right.tag = TAG_LABEL + x;
            [_headView addSubview:right];
        }
    }else{
        [_tableView reloadData];        
    }
    for (int x = 0; x < _hValues.count; x ++) {
        UILabel *label = [_headView viewWithTag:TAG_LABEL + x];
        label.text = _hValues[x];
    }
}

- (void)frontYear{
    self.year --;
    _click = 1;
    [self annalHandleDatas];
}

- (void)backYear{
    self.year ++;
    _click = 2;
    [self annalHandleDatas];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _subjects.count;
}

- (FSAnnalDetailCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSAnnalDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSAnnalDetailCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    Tuple5 *t = [_subjects objectAtIndex:indexPath.row];
    cell.textLabel.text = t._2;
    [cell configData:t._3 text2:t._5 color:t._4];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
