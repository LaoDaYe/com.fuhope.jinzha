//
//  FSDBFlowController.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/29.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSDBFlowController.h"
#import "FSDBSupport.h"
#import "FSDBFlowCell.h"
#import "FSABFlowDetailController.h"
#import "FSShare.h"
#import "FSPublic.h"
#import "FSDate.h"
#import "FSTrackKeys.h"

@interface FSDBFlowController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSDBFlowController{
    NSArray         *_list;
    UITableView     *_tableView;
    NSInteger       _year;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSDateComponents *c = [FSDate componentForDate:[NSDate date]];
    _year = c.year;
    [self flowHandleDatas];
}

- (void)flowHandleDatas{
    self.title = [[NSString alloc] initWithFormat:@"%@ - %@",@(_year - 1),@(_year)];
    
    NSTimeInterval time = [self theFirstSecondOfYear:_year - 1];
    if (time < _firstTime) {
        time = _firstTime;
    }
    
    _fs_dispatch_global_main_queue_async(^{
        self->_list = [FSDBSupport incomesAndcostsByMonth:self->_year table:self.tableName first:time];
    }, ^{
        [self flowDesignViews];
    });
}

- (void)flowDesignViews{
    if (!_tableView) {
         [FSTrack event:_UMeng_Event_acc_flow];
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Dates back", nil) style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
        self.navigationItem.rightBarButtonItem = bbi;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, HEIGHTFC - 64) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.rowHeight = 70;
        [self.view addSubview:_tableView];
    }else{
        [_tableView reloadData];
    }
}

- (void)shakeEndActionFromShakeBase{
    [FSPublic shareAction:self view:_tableView];
}

- (NSTimeInterval)theFirstSecondOfYear:(NSInteger)year{
    year = MAX(1, year);
    NSString *first = [[NSString alloc] initWithFormat:@"%@-01-01 00:00:00",@(year)];
    NSDate *date = [FSDate dateByString:first formatter:nil];
    NSTimeInterval time = [date timeIntervalSince1970];
    return time;
}

- (void)bbiAction{
    _year = _year - 2;
    NSInteger days = [FSDate daysForMonth:12 year:_year];
    NSString *max = [[NSString alloc] initWithFormat:@"%@-12-%@ 23:59:59",@(_year),@(days)];
    NSDate *date = [FSDate dateByString:max formatter:nil];
    NSTimeInterval time = [date timeIntervalSince1970];
    if (time < _firstTime) {
        [FSToast show:NSLocalizedString(@"No more data", nil)];
        return;
    }
    [self flowHandleDatas];
}

#pragma mark DELEGATE
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _list.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    Tuple2 *t = [_list objectAtIndex:section];
    NSArray *array = t._2;
    if (_fs_isValidateArray(array)) {
        return array.count;
    }
    return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    Tuple2 *t = [_list objectAtIndex:section];
    NSString *year = t._1;
    if (_fs_isValidateString(year)) {
        return year;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return .1;
}

- (FSDBFlowCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSDBFlowCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSDBFlowCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    Tuple2 *t2 = [_list objectAtIndex:indexPath.section];
    NSArray *array = t2._2;
    Tuple3 *t3 = [array objectAtIndex:indexPath.row];
    [cell configData:t3];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    Tuple2 *t2 = [_list objectAtIndex:indexPath.section];
    NSArray *array = t2._2;
    Tuple3 *t3 = [array objectAtIndex:indexPath.row];
    FSABFlowDetailController *d = [[FSABFlowDetailController alloc] init];
    d.t = t3;
    d.tableName = self.tableName;
    [self.navigationController pushViewController:d animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
