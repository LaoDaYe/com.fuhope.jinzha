//
//  FSAddAccountController.h
//  myhome
//
//  Created by FudonFuchina on 2017/5/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSAddAccountController : FSBaseController

@property (nonatomic,copy) NSString     *accountName;
@property (nonatomic,copy) NSString     *type;

@end
