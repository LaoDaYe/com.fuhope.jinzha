//
//  FSABSearchResultView.m
//  myhome
//
//  Created by FudonFuchina on 2018/6/24.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSABSearchResultView.h"
#import "FSABModel.h"
#import "FSABListCell.h"

@interface FSABSearchResultView ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSABSearchResultView{
    UITableView     *_tableView;
}

- (void)setList:(NSArray *)list{
    _list = nil;
    if ([list isKindOfClass:NSArray.class] && list.count) {
        _list = list;
    }
    
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height) style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
        [self addSubview:_tableView];
    }else{
        [_tableView reloadData];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _list.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (FSABListCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSABListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[FSABListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.index = indexPath.section;
    
    FSABModel *entity = [_list objectAtIndex:indexPath.section];
    [cell flowConfigDataWithEntity:entity];
    return  cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSABModel *entity = [_list objectAtIndex:indexPath.section];
    return entity.cellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return section == 0?10:.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
