//
//  FSAnnalDetailCell.m
//  myhome
//
//  Created by FudonFuchina on 2018/2/3.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSAnnalDetailCell.h"

@implementation FSAnnalDetailCell{
    UILabel     *_label1;
    UILabel     *_label2;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self adCellDesignViews];
    }
    return self;
}

- (void)adCellDesignViews{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    _label1 = [[UILabel alloc] initWithFrame:CGRectMake(width / 4, 10, width / 2 , 30)];
    _label1.font = [UIFont boldSystemFontOfSize:13];
    [self addSubview:_label1];
    
    _label2 = [[UILabel alloc] initWithFrame:CGRectMake(width / 2, 10, width/2 - 15, 30)];
    _label2.font = [UIFont systemFontOfSize:16];
    _label2.textAlignment = NSTextAlignmentRight;
    [self addSubview:_label2];
}

- (void)configData:(NSString *)text1 text2:(NSString *)text2 color:(UIColor *)color{
    _label1.text = text1;
    _label1.textColor = color;
    _label2.text = text2;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
