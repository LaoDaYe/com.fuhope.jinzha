//
//  FSABFlowDetailController.m
//  myhome
//
//  Created by FudonFuchina on 2017/9/12.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABFlowDetailController.h"
#import "FSDBSupport.h"
#import "FSABModel.h"
#import "FSABListCell.h"
#import "MJRefresh.h"
#import "FSAccountConfiger.h"
#import "FSABTrackController.h"
#import "FATool.h"
#import "FSDate.h"
#import "FSUIKit.h"
#import "FSABAPI.h"
#import "FSTrack.h"
#import "FSTrackKeys.h"
#import "FSDBTool.h"

@interface FSABFlowDetailController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray       *array;
@property (nonatomic,assign) NSInteger            page;
@property (nonatomic,assign) BOOL                 isEarning;

@end

@implementation FSABFlowDetailController{
    UITableView             *_tb;
    NSTimeInterval          _start;
    NSTimeInterval          _end;
    UIBarButtonItem         *_bbi;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [FSTrack event:_UMeng_Event_acc_flow_detail];
    
    _bbi = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
    self.navigationItem.rightBarButtonItem = _bbi;
    
    NSDate *date = _t._1;
    NSDateComponents *c = [FSDate componentForDate:date];
    NSNumber *year = @(c.year);
    NSNumber *month = @(c.month);
    self.title = [[NSString alloc] initWithFormat:@"流水详单（%@/%@）",[FSKit twoChar:c.month],year];
    NSString *start = [[NSString alloc] initWithFormat:@"%@-%@-01 00:00:00",year,month];
    NSDate *startDate = [FSDate dateByString:start formatter:nil];
    _start = [startDate timeIntervalSince1970];
    NSInteger days = [FSDate daysForMonth:c.month year:c.year];
    NSString *end = [[NSString alloc] initWithFormat:@"%@-%@-%@ 23:59:59",year,month,@(days)];
    NSDate *endDate = [FSDate dateByString:end formatter:nil];
    _end = [endDate timeIntervalSince1970];
    
    self.isEarning = NO;
}

- (void)setIsEarning:(BOOL)isEarning{
    _isEarning = isEarning;
    [_bbi setTitle:_isEarning?@"收入":@"成本"];
    [self flowDetailHandleDatas];
}

- (void)bbiAction{
    self.isEarning = !self.isEarning;
    self.page = 0;
    _tb.contentOffset = CGPointZero;
}

- (void)flowDetailHandleDatas{
    _fs_dispatch_global_main_queue_async(^{
        NSMutableArray *array = [FSABAPI abFlowWithTable:self->_tableName issSR:self->_isEarning page:self.page start:self->_start end:self->_end];
        if (self.page) {
            [self.array addObjectsFromArray:array];
        }else{
            self.array = array;
        }
    }, ^{
        [self flowDetailDesignViews];
    });
}

- (void)flowDetailDesignViews{
    if (!_tb) {
        _tb = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStyleGrouped];
        _tb.delegate = self;
        _tb.dataSource = self;
        _tb.estimatedSectionHeaderHeight = 0;
        _tb.estimatedSectionFooterHeight = 0;
        [self.view addSubview:_tb];
        WEAKSELF(this);
        _tb.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            this.page = 0;
            [this flowDetailHandleDatas];
        }];
        _tb.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            this.page ++;
            [this flowDetailHandleDatas];
        }];
    }else{
        [_tb.mj_header endRefreshing];
        [_tb.mj_footer endRefreshing];
        [_tb reloadData];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.array.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (FSABListCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSABListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSABListCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        __weak typeof(self)this = self;
        cell.trackCallback = ^(FSABModel *bModel, NSString *type) {
            FSABTrackController *track = [[FSABTrackController alloc] init];
            track.model = bModel;
            track.type = type;
            track.table = this.tableName;
            if (this.navigationController.navigationBarHidden) {
                this.navigationController.navigationBarHidden = NO;
            }
            [this.navigationController pushViewController:track animated:YES];
        };
    }
    cell.index = indexPath.section;
    
    FSABModel *entity = self.array[indexPath.section];
    [cell flowConfigDataWithEntity:entity];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSABModel *entity = self.array[indexPath.section];
    return entity.cellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return section == 0?10:.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    FSABModel *entity = [_array objectAtIndex:indexPath.section];
    NSString *aSubject = [FATool hansForShort:entity.atype];
    NSString *bSubject = [FATool hansForShort:entity.btype];
    NSNumber *alertType = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[aSubject,bSubject] styles:@[alertType,alertType] handler:^(UIAlertAction *action) {
        BOOL isA = [action.title isEqualToString:aSubject];
        [FSDBTool pushToAccountUpdateController:self.navigationController entity:entity isA:isA account:self.tableName];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
