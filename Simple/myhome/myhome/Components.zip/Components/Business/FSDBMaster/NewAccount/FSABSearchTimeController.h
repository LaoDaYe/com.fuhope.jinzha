//
//  FSABSearchTimeController.h
//  myhome
//
//  Created by FudonFuchina on 2017/9/13.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSABSearchTimeController : FSBaseController

@property (nonatomic,copy) NSString     *tableName;
@property (nonatomic,copy) NSString     *subject;

@end
