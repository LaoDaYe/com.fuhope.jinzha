//
//  FSFMAccountController.m
//  SQL
//
//  Created by fudon on 2016/8/24.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSAddAccountController.h"
#import "FATool.h"
#import "FSAccountConfiger.h"
#import "FSAccountRecordController.h"
#import "FSDBMaster.h"
#import "FSABTwominusController.h"
#import "FSDBTool.h"
#import <FSTuple.h>
#import "UIViewController+BackButtonHandler.h"
#import "FSDBJeView.h"
#import "FATool.h"
#import <FSUIKit.h>

@interface FSAddAccountController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSArray            *subjects;
@property (nonatomic,strong) NSMutableArray     *handleArray;
@property (nonatomic,strong) UISegmentedControl *control;
@property (nonatomic,strong) FSDBJeView         *jeView;

@property (nonatomic,strong) NSDate             *date;  // 补记的日期

@end

@implementation FSAddAccountController{
    BOOL    _canPop;
}

- (void)tapAction{
    [self.view endEditing:YES];
}

- (void)bbiAction:(UIBarButtonItem *)bbi{
    [self.view endEditing:YES];
    
    WEAKSELF(this);
    __weak UIBarButtonItem *weakBBI = bbi;
    FSAccountRecordController *saveViewController = [[FSAccountRecordController alloc] init];
    [this.navigationController pushViewController:saveViewController animated:YES];
    saveViewController.block = ^(FSBaseController *bVC, NSDate *date) {
        this.date = date;
        weakBBI.title = [[FSKit ymdhsByTimeInterval:[date timeIntervalSince1970]] substringToIndex:10];
        [bVC.navigationController popViewControllerAnimated:YES];
    };
}

- (void)viewDidLoad{
    [super viewDidLoad];
    _handleArray = [[NSMutableArray alloc] init];
    UIBarButtonItem *bbi = [FSViewManager bbiWithTitle:NSLocalizedString(@"Supplement", nil) target:self action:@selector(bbiAction:)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    _control = [[UISegmentedControl alloc] initWithItems:@[NSLocalizedString(@"Plus", nil),NSLocalizedString(@"Minus", nil)]];
    _control.selectedSegmentIndex = 0;
    _control.frame = CGRectMake(0, 4, 100, 36);
    self.navigationItem.titleView = _control;
    
    __weak typeof(self)this = self;
    _jeView = [[FSDBJeView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 100)];
    _jeView.tapEvent = ^(FSDBJeView *bView) {
        [this tapAction];
    };
    
    self.subjects = @[_subject_SR,_subject_CB,_subject_YS,_subject_XJ,_subject_CH,_subject_TZ,_subject_GZ,_subject_TX,_subject_FZ,_subject_PS,_subject_BJ,_subject_GB];
    self.baseTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height - 64) style:UITableViewStylePlain];
    self.baseTableView.delegate = self;
    self.baseTableView.dataSource = self;
    self.baseTableView.tableHeaderView = _jeView;
    self.baseTableView.tableFooterView = [UIView new];
    self.baseTableView.backgroundColor = [UIColor clearColor];
    self.baseTableView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.baseTableView];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.jeView.jeTF.textField becomeFirstResponder];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self->_canPop = YES;
        });
    });
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.subjects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.textLabel.text = [FATool hansForShort:self.subjects[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (!_fs_isPureFloat(self.jeView.jeTF.textField.text)) {
        [FSToast toast:NSLocalizedString(@"Please Input Money", nil)];
        return;
    }
    if (self.jeView.bzTF.textField.text.length < 1) {
        [FSToast toast:NSLocalizedString(@"Please Input Note", nil)];
        return;
    }
    
    NSString *option = self.subjects[indexPath.row];
    for (int x = 0; x < self.handleArray.count; x ++) {
        NSString *type = self.handleArray[x];
        if ([type containsString:option]) {
            [FSToast toast:[[NSString alloc] initWithFormat:@"%@已选择",[FATool hansForShort:option]]];
            return;
        }
    }
    
    NSString *flag = [[NSString alloc] initWithFormat:@"%@%@",option,_control.selectedSegmentIndex == 0?_ING_KEY:_ED_KEY];
    if (_handleArray.count < 2) {
        if (![_handleArray containsObject:flag]) {
            [_handleArray addObject:flag];
        }
        if (_control.selectedSegmentIndex == 0) {
            _control.selectedSegmentIndex = 1;
        }
    }
    if (_handleArray.count < 2) {
        NSString *txt = @"还需选择一个科目";
        [FSToast toast:txt tap:^{
            self.control.selectedSegmentIndex = 0;
        }];
    }
    
    if (self.handleArray.count == 2) {
        Tuple2 *t2 = [FSDBTool returnErrorStringIfOccurrError:_handleArray];
        if (![t2._1 boolValue]) {
            [FSUIKit showAlertWithMessage:t2._2 controller:self handler:^(UIAlertAction *action) {
                self.control.selectedSegmentIndex = 0;
                [self.handleArray removeAllObjects];
            }];
            return;
        }

        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Tips", nil) message:t2._2 actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            NSMutableArray *handleArray = [self.handleArray copy];
            [FSDBTool handleDatas:handleArray account:self->_accountName date:[self.date isKindOfClass:NSDate.class]?self.date:[NSDate date] je:self.jeView.jeTF.textField.text bz:self.jeView.bzTF.textField.text controller:self type:self.type completion:^{
                [FSKit popToController:@"FSABOverviewController" navigationController:self.navigationController animated:YES];
            }];
        } cancelTitle:NSLocalizedString(@"Cancel", nil) cancel:^(UIAlertAction *action) {
            self.control.selectedSegmentIndex = 0;
            [self.handleArray removeAllObjects];
        } completion:nil];
    }
}

- (BOOL)navigationShouldPopOnBackButton{
    if (_canPop) {
        return YES;
    }else{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];
        });
        return NO;
    }
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (decelerate) {
        [self.view endEditing:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
