//
//  FSABTodayFlowController.h
//  myhome
//
//  Created by FudonFuchina on 2017/11/9.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSABTodayFlowController : FSBaseController

@property (nonatomic,copy) NSString     *account;

@end
