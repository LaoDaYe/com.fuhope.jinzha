//
//  FSABNameModel.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/27.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABNameModel.h"

@implementation FSABNameModel

+ (NSArray<NSString *> *)tableFields{
    return @[@"time",@"name",@"tb",@"type",@"freq",@"flag"];
}

@end
