//
//  FSFMSelectController.m
//  SQL
//
//  Created by fudon on 2016/8/24.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSABDetailController.h"
#import "FATool.h"
#import "FSAccountConfiger.h"
#import "FSDBSupport.h"
#import "FSABListCell.h"
#import "FSTextViewController.h"
#import "FSABSearchTimeController.h"
#import "FSABTrackController.h"
#import <MJRefresh.h>
#import "FSMacro.h"
#import "FSPublic.h"
#import <FSUIKit.h>
#import "FSDBTool.h"

@interface FSABDetailController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UISegmentedControl     *control;
@property (nonatomic,strong) NSMutableArray         *dataSource;
@property (nonatomic,strong) UITableView            *tableView;
@property (nonatomic,assign) NSInteger              page;
@property (nonatomic,assign) BOOL                   isRest;
@property (nonatomic,assign) NSInteger              order;      // 2.从近到远  1.从远到近  0.不处理
@property (nonatomic,assign) NSInteger              howMuch;    // 2.从大到小  1.从小到大  0.不处理
@property (nonatomic,strong) UILabel                *label;

@end

@implementation FSABDetailController{
    UIBarButtonItem     *_bbi;
    BOOL                _changeTB;
    BOOL                _showToast;
}

- (void)shakeEndActionFromShakeBase{
    [FSPublic shareAction:self view:_tableView];
}

- (void)controlAction:(UISegmentedControl *)control{
    self.page = 0;
    [self.tableView setContentOffset:CGPointMake(0, 0)];
    if (control.selectedSegmentIndex) {
        self.isRest = NO;
    }
    [self showTitle];
    [self selectHandleDatas];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.isRest = YES;
    self.order = 2;
    [self preLoadView];
    [self selectHandleDatas];
}

- (void)preLoadView{
    _bbi = [[UIBarButtonItem alloc] initWithTitle:[FATool hansForShort:self.type] style:UIBarButtonItemStyleDone target:self action:@selector(bbiAction)];
    self.navigationItem.rightBarButtonItem = _bbi;
    
    _control = [[UISegmentedControl alloc] initWithItems:@[NSLocalizedString(@"Plus", nil),NSLocalizedString(@"Minus", nil)]];
    _control.selectedSegmentIndex = 0;
    _control.frame = CGRectMake(WIDTHFC / 2 - 50, 4, 100, 36);
    [_control addTarget:self action:@selector(controlAction:) forControlEvents:UIControlEventValueChanged];
    self.navigationItem.titleView = _control;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (!_showToast) {
        _showToast = YES;
        [self toast];
    }
}

- (void)toast{
    if ([_type isEqualToString:_subject_SR] || [_type isEqualToString:_subject_CB]) {
        static NSString *toast = @"上页为今年数据，本页为所有数据";
        CGFloat height = 50;
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, HEIGHTFC, WIDTHFC, height)];
        label.backgroundColor = FS_GreenColor;
        label.textColor = [UIColor whiteColor];
        label.text = toast;
        label.font = [UIFont boldSystemFontOfSize:15];
        label.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:label];
        [UIView animateWithDuration:.6 animations:^{
            label.top = HEIGHTFC - height;
        } completion:^(BOOL finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIView animateWithDuration:.3 animations:^{
                    label.top = HEIGHTFC;
                } completion:^(BOOL finished) {
                    [label removeFromSuperview];
                }];
            });
        }];
    }
}

- (void)selectHandleDatas{
    _fs_dispatch_global_main_queue_async(^{
        [self selectHandleDatasAsync];
    }, ^{
        [self selectDesignViews];
    });
}

- (void)selectHandleDatasAsync{
    __block NSString *suffix = nil;
    if ([NSThread isMainThread]) {
        suffix = _control.selectedSegmentIndex?_ED_KEY:_ING_KEY;
    }else{
        dispatch_sync(dispatch_get_main_queue(), ^{
            suffix = self->_control.selectedSegmentIndex?_ED_KEY:_ING_KEY;
        });
    }
    if (suffix == nil) {
        return;
    }
    NSString *condition = [[NSString alloc] initWithFormat:@"%@%@",self.type,suffix];    
    NSString *sql = nil;
    NSInteger unit = 20;
    if (_isRest) {
        if (self.order) {
            sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE ((atype = '%@' AND cast(arest as REAL) > 0) OR (btype = '%@' AND cast(brest as REAL) > 0)) order by cast(time as REAL) %@ limit %@,%@;",_accountName,condition,condition,_order == 1?@"ASC":@"DESC",@(self.page * unit),@(unit)];
        }
        if (self.howMuch) {
            sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE ((atype = '%@' AND cast(arest as REAL) > 0) OR (btype = '%@' AND cast(brest as REAL) > 0)) order by cast(je as REAL) %@ limit %@,%@;",_accountName,condition,condition,_howMuch == 1?@"ASC":@"DESC",@(self.page * unit),@(unit)];
        }
    }else{
        if (self.order) {
            sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@') order by cast(time as REAL) %@ limit %@,%@;",_accountName,condition,condition,_order == 1?@"ASC":@"DESC",@(self.page * unit),@(unit)];
        }
        if (self.howMuch) {
            sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@') order by cast(je as REAL) %@ limit %@,%@;",_accountName,condition,condition,_howMuch == 1?@"ASC":@"DESC",@(self.page * unit),@(unit)];
        }
    }
    
    if (!sql) {
        sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@') order by cast(time as REAL) %@ limit %@,%@;",_accountName,condition,condition,_order == 1?@"ASC":@"DESC",@(self.page * unit),@(unit)];
    }

    NSMutableArray *bArray = [FSDBSupport querySQL:sql class:FSABModel.class tableName:_accountName];
    for (FSABModel *model in bArray) {
        [model processPropertiesWithType:condition search:nil isCompany:NO];
    }
    
    if (self.page) {
        [self.dataSource addObjectsFromArray:bArray];
    }else{
        self.dataSource = bArray;
    }
}

- (UILabel *)label{
    if (!_label) {
        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, 26)];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.font = [UIFont systemFontOfSize:14];
        _label.text = NSLocalizedString(@"Remaining > zero", nil);
        _label.textColor = [UIColor whiteColor];
        _label.backgroundColor = THISCOLOR;
        [self.view addSubview:_label];
    }
    return _label;
}

- (void)bbiAction{
    NSString *changed = nil;
    if (self.isRest) {
        changed = NSLocalizedString(@"All data", nil);
    }else{
        changed = NSLocalizedString(@"Remaining > zero", nil);
    }
    NSString *sort = NSLocalizedString(@"Time sort", nil);
    NSString *je = NSLocalizedString(@"Money sort", nil);
    NSString *search = NSLocalizedString(@"Search", nil);
    NSNumber *type = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[changed,sort,je,search] styles:@[type,type,type,type] handler:^(UIAlertAction *action) {
        if ([action.title isEqualToString:changed]) {
            self.isRest = !self.isRest;
            self.page = 0;
            [self.tableView setContentOffset:CGPointMake(0, 0)];
            [self selectHandleDatas];
            [self showTitle];
        }else if ([action.title isEqualToString:sort]){
            self.howMuch = 0;
            if (self.order == 2) {
                self.order = 1;
            }else{
                self.order = 2;
            }
            self.page = 0;
            [self.tableView setContentOffset:CGPointMake(0, 0)];
            [self selectHandleDatas];
            [self showTitle];
        }else if ([action.title isEqualToString:je]){
            self.order = 0;
            if (self.howMuch == 2) {
                self.howMuch = 1;
            }else{
                self.howMuch = 2;
            }
            self.page = 0;
            [self.tableView setContentOffset:CGPointMake(0, 0)];
            [self selectHandleDatas];
            [self showTitle];
        }else if ([action.title isEqualToString:search]){
            FSABSearchTimeController *time = [[FSABSearchTimeController alloc] init];
            time.tableName = self.accountName;
            if (self.type.length > 2) {
                time.subject = [self.type substringToIndex:2];
            }else{
                time.subject = self.type;
            }
            [self.navigationController pushViewController:time animated:YES];
        }
    }];
}

- (void)showTitle{
    NSString *shortS = [[NSString alloc] initWithFormat:@"%@减少",[FATool hansForShort:_type isCompany:NO]];
    NSString *rest = NSLocalizedString(@"Remaining > zero", nil);
    NSString *all = _control.selectedSegmentIndex?shortS:NSLocalizedString(@"All data", nil);
    NSString *front = NSLocalizedString(@"Time DESC", nil);
    NSString *back = NSLocalizedString(@"Time ASC", nil);
    NSString *jeFront = NSLocalizedString(@"Money ASC", nil);
    NSString *jeBack = NSLocalizedString(@"Money DESC", nil);

    NSMutableString *string = [[NSMutableString alloc] init];
    if (self.isRest) {
        [string appendString:rest];
    }else{
        [string appendString:all];
    }
    if (self.order) {
        if (self.order == 2) {
            [string appendFormat:@" && %@",front];
        }else{
            [string appendFormat:@" && %@",back];
        }
    }
    if (self.howMuch) {
        if (self.howMuch == 2) {
            [string appendFormat:@" && %@",jeFront];
        }else{
            [string appendFormat:@" && %@",jeBack];
        }
    }
    
    self.label.text = string;
    if (!_changeTB) {
        _changeTB = YES;
        self.tableView.top = 90;
        self.tableView.height = self.view.bounds.size.height - 90;
    }
}

- (void)selectDesignViews{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height - 64) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 0;
        [self.view addSubview:_tableView];
        WEAKSELF(this);
        _tableView.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            this.page = 0;
            [this selectHandleDatas];
        }];
        this.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            this.page ++;
            [this selectHandleDatas];
        }];
    }else{
        [self.tableView.mj_footer endRefreshing];
        [self.tableView.mj_header endRefreshing];
        [self.tableView reloadData];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (FSABListCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSABListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSABListCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        WEAKSELF(this);
        cell.trackCallback = ^(FSABModel *bModel, NSString *type) {
            FSABTrackController *track = [[FSABTrackController alloc] init];
            track.model = bModel;
            track.type = type;
            track.table = this.accountName;
            if (this.navigationController.navigationBarHidden) {
                this.navigationController.navigationBarHidden = NO;
            }
            [this.navigationController pushViewController:track animated:YES];
        };
    }
    cell.index = indexPath.section;
    
    FSABModel *entity = _dataSource[indexPath.section];
    [cell flowConfigDataWithEntity:entity];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSABModel *entity = _dataSource[indexPath.section];
    return entity.cellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return section == 0?10:.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self deleteDatas:tableView forRowAtIndexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    FSABModel *entity = _dataSource[indexPath.section];
    NSString *suffix = _control.selectedSegmentIndex?_ED_KEY:_ING_KEY;
    NSString *type = [[NSString alloc] initWithFormat:@"%@%@",self.type,suffix];
    BOOL isA = [type isEqualToString:entity.atype];
    [FSDBTool pushToAccountUpdateController:self.navigationController entity:entity isA:isA account:self.accountName];
}

- (void)deleteDatas:(UITableView *)tableView forRowAtIndexPath:(NSIndexPath *)indexPath{
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:@"确定删除？" message:@"删除后可去'报表'中查找恢复" actionTitles:@[@"删除"] styles:@[@(UIAlertActionStyleDestructive)] handler:^(UIAlertAction *action) {
        FSABModel *entity = self->_dataSource[indexPath.section];
        NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET deflag = '1' WHERE aid = %@;",self->_accountName,entity.aid];
        FSDBMaster *master = [FSDBMaster sharedInstance];
        
        NSString *error = [master updateSQL:sql];
        if (!error) {
            [FSToast show:@"删除成功"];
            [[NSNotificationCenter defaultCenter] postNotificationName:_Notifi_refreshAccount object:nil];

            NSMutableArray *array = [[NSMutableArray alloc] initWithArray:self.dataSource];
            [array removeObjectAtIndex:indexPath.section];
            self.dataSource = array;
            
            NSIndexPath *newIP = [NSIndexPath indexPathForRow:0 inSection:indexPath.section];
            [tableView deleteSections:[NSIndexSet indexSetWithIndex:newIP.section] withRowAnimation:UITableViewRowAnimationMiddle];
        }else{
            [FSUIKit showAlertWithMessage:error controller:self];
        }
    } cancelTitle:NSLocalizedString(@"Cancel", nil) cancel:^(UIAlertAction *action) {
        tableView.editing = NO;
    }  completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
