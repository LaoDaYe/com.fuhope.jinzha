//
//  FSABTodayFlowController.m
//  myhome
//
//  Created by FudonFuchina on 2017/11/9.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABTodayFlowController.h"
#import "FSDate.h"
#import "FSAccountConfiger.h"
#import "FSABModel.h"
#import "FSDBSupport.h"

@interface FSABTodayFlowController ()

@end

@implementation FSABTodayFlowController{
    NSMutableArray  *_list;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self tfHandleDatas];
}

- (void)tfHandleDatas{
    NSDate *today = [NSDate date];
    [FSDBSupport dayFlowOfAccount:self.account date:today completion:^(CGFloat sr, CGFloat cb) {
        
    }];
    
    
//    if (_list) {
//        [_list addObject:array];
//    }else{
//        _list = array;
//    }
//    [self tfDesignViews];
}

- (void)tfDesignViews{
    self.title = NSLocalizedString(@"Today flow", nil);
    
    NSArray *titles = @[@"收入",@"成本",@"利润"];
    NSArray *values = @[@"1033.00",@"221.98",@"853.22"];
    __weak typeof(self)this = self;
    for (int x = 0; x < titles.count; x ++) {
        FSTapCell *cell = [FSViewManager tapCellWithText:titles[x] textColor:nil font:[UIFont systemFontOfSize:16] detailText:values[x] detailColor:nil detailFont:[UIFont systemFontOfSize:14] block:^(FSTapCell *bCell) {
            [this cellAction:bCell];
        }];
        cell.top = 10 + 55 * x;
        if (x == 2) {
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        cell.backgroundColor = [UIColor whiteColor];
        cell.height = 54;
        cell.tag = TAG_CELL + x;
        [self.scrollView addSubview:cell];
    }
}

- (void)cellAction:(FSTapCell *)cell{
    if (cell.tag == (TAG_CELL + 2)) {
        return;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
