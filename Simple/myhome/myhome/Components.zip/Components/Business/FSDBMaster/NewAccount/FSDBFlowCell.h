//
//  FSDBFlowCell.h
//  myhome
//
//  Created by FudonFuchina on 2017/8/30.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FSTuple.h>

@interface FSDBFlowCell : UITableViewCell

- (void)configData:(Tuple3 *)t;

@end
