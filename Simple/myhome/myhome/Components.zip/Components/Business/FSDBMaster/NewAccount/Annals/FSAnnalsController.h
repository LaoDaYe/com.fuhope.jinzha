//
//  FSAnnalsController.h
//  myhome
//
//  Created by FudonFuchina on 2018/1/14.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSAnnalsController : FSBaseController

@property (nonatomic,copy) NSString *tableName;

@property (nonatomic,assign) NSTimeInterval firstTime;

@end
