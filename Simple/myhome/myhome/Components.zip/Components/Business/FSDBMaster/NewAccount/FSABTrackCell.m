//
//  FSABTrackCell.m
//  myhome
//
//  Created by fudon on 2017/5/24.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABTrackCell.h"
#import "FSMacro.h"
#import <FSDate.h>
#import <FSCalculator.h>

@implementation FSABTrackCell{
    UILabel *_timeLabel;
    UILabel *_jeLabel;
    UILabel *_bzLabel;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _timeLabel = [FSViewManager labelWithFrame:CGRectMake(15, 5, WIDTHFC / 2, 30) text:nil textColor:FS_TextColor_Normal backColor:nil font:FONTFC(14) textAlignment:NSTextAlignmentLeft];
        [self addSubview:_timeLabel];
        
        _jeLabel = [FSViewManager labelWithFrame:CGRectMake(WIDTHFC / 2 + 15, 5, WIDTHFC / 2 - 30, 30) text:nil textColor:FS_TextColor_Dark backColor:nil font:FONTBOLD(18) textAlignment:NSTextAlignmentRight];
        [self addSubview:_jeLabel];
        
        _bzLabel = [FSViewManager labelWithFrame:CGRectMake(15, 35, WIDTHFC - 30, 30) text:nil textColor:FS_TextColor_Normal backColor:nil font:FONTFC(14) textAlignment:NSTextAlignmentLeft];
        _bzLabel.numberOfLines = 0;
        [self addSubview:_bzLabel];
    }
    return self;
}

- (void)setModel:(FSABTrackModel *)model{
    _model = model;
    
    NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:[model.time doubleValue]];
    _timeLabel.text = [FSDate stringWithDate:date formatter:@"yyyy-MM-dd HH:mm:ss"];
    
    _jeLabel.text = [[NSString alloc] initWithFormat:@"-%.2f",[model.je doubleValue]];
    _bzLabel.text = model.bz;
    
    CGFloat height = [FSCalculator textHeight:model.bz font:FONTFC(14) labelWidth:WIDTHFC - 20];
    height = MAX(height, 30);
    _bzLabel.height = height;
    if (self.hCallback) {
        self.hCallback(height + 40, _index);
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
