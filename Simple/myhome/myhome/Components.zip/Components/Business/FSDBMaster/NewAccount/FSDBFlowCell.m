//
//  FSDBFlowCell.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/30.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSDBFlowCell.h"
#import "FSKitDuty.h"
#import <FSDate.h>

@implementation FSDBFlowCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self flowCellDesignViews];
    }
    return self;
}

- (void)flowCellDesignViews{
    CGSize size = [UIScreen mainScreen].bounds.size;
    CGFloat width = (size.width - 30) / 2;
    
    UIColor *green = [UIColor colorWithRed:64/255.0 green:171/255.0 blue:62/255.0 alpha:1.0];
    for (int x = 0; x < 4; x ++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15 + (x % 2) * width, 10 + (x / 2) * 25, width, 25)];
        label.font = x?[UIFont systemFontOfSize:14]:[UIFont boldSystemFontOfSize:16];
        [self addSubview:label];
        if (x == 1 || x == 2) {
            label.textColor = green;
        }
        if (x % 2 == 1) {
            label.textAlignment = NSTextAlignmentRight;
            if (x == 3) {
                label.textColor = [UIColor redColor];
            }
        }
        label.tag = 123 + x;
    }
}

- (void)configData:(Tuple3 *)t{
    CGFloat sr = [t._2 doubleValue];
    CGFloat cb = [t._3 doubleValue];
    CGFloat profit = sr - cb;
    NSDate *date = t._1;
    NSString *time = nil;
    if ([date isKindOfClass:NSDate.class]) {
        NSDateComponents *c = [FSDate componentForDate:date];
        time = [[NSString alloc] initWithFormat:@"%@月",@(c.month)];
    }
    UILabel *timeLabel = [self viewWithTag:123];
    UILabel *srLabel = [self viewWithTag:124];
    UILabel *pLabel = [self viewWithTag:125];
    UILabel *cbLabel = [self viewWithTag:126];
    
    timeLabel.text = time;
    srLabel.text =  [[NSString alloc] initWithFormat:@"%.2f",sr];
    cbLabel.text =  [[NSString alloc] initWithFormat:@"%.2f",cb];
    pLabel.text = [[NSString alloc] initWithFormat:@"%.2f",profit];
    if (profit > 0.0) {
        UIColor *green = [UIColor colorWithRed:64/255.0 green:171/255.0 blue:62/255.0 alpha:1.0];
        pLabel.textColor = green;
    }else{
        pLabel.textColor = [UIColor redColor];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
