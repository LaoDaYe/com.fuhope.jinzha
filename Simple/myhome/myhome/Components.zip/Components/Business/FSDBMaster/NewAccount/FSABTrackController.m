//
//  FSABTrackController.m
//  myhome
//
//  Created by FudonFuchina on 2017/5/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABTrackController.h"
#import "FSDBSupport.h"
#import "FSABTrackModel.h"
#import "FSABTrackCell.h"
#import "FATool.h"
#import <MJRefresh/MJRefresh.h>
#import "FSDBTool.h"
#import "FSAlertView.h"

@interface FSABTrackController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray         *datas;
@property (nonatomic,strong) UITableView            *tableView;
@property (nonatomic,strong) UIView                 *headView;

@property (nonatomic,assign) NSInteger              page;
@property (nonatomic,assign) BOOL                   first;
@property (nonatomic,strong) NSMutableDictionary    *heights;
@property (nonatomic,assign) CGFloat                sum;

@end

@implementation FSABTrackController{
    UIBarButtonItem *_bbi;
    NSString        *_checkMessage;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    _heights = [NSMutableDictionary new];
    self.vanView.status = FSLoadingStatusLoading;
    [self checkDataRight:NO];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self trackHandleDatas];
}

- (void)trackHandleDatas{
    if (!self.title) {
        self.title = [FATool hansForShort:[_type substringToIndex:2]];
    }
    NSString *param = [_type isEqualToString:_model.atype]?@"a":@"b";
    
    NSInteger unit = 50;
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE link = '%@' AND type = '%@' AND accname = '%@' order by cast(time as REAL) DESC limit %@,%@;",_tb_abTrack,_model.time,param,self.table,@(self.page * unit),@(unit)];
    NSMutableArray *array = [FSDBSupport querySQL:sql class:FSABTrackModel.class tableName:_tb_abTrack];
    if (self.page) {
        [self.datas addObjectsFromArray:array];
    }else{
        self.datas = array;
    }
    if (!_first) {
        [self.vanView dismiss];
    }else{
        _first = YES;
    }
    [self trackDesignViews];
}

- (void)checkAction{
    [self checkDataRight:YES];
}

- (void)checkDataRight:(BOOL)show{
    CGFloat delta = 0;
    if (!_checkMessage) {
        NSInteger unit = 300;
        NSInteger page = 0;
        NSString *param = [_type isEqualToString:_model.atype]?@"a":@"b";
        NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE link = '%@' AND type = '%@' AND accname = '%@' limit %@,%@;",_tb_abTrack,_model.time,param,self.table,@(unit * page),@(unit)];
        FSDBMaster *master = [FSDBMaster sharedInstance];
        NSArray *list = [master querySQL:sql tableName:_tb_abTrack];
        NSInteger times = list.count;
        CGFloat sum = 0;
        while (_fs_isValidateArray(list)) {
            for (NSDictionary *dic in list) {
                CGFloat je = [dic[@"je"] doubleValue];
                sum += je;
            }
            page ++;
            sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE link = '%@' AND type = '%@' AND accname = '%@' limit %@,%@;",_tb_abTrack,_model.aid,param,self.table,@(unit * page),@(unit)];
            list = [master querySQL:sql tableName:_tb_abTrack];
            times += list.count;
        }
        CGFloat rest = [[_type isEqualToString:_model.atype]?_model.arest:_model.brest doubleValue];
        CGFloat all = [_model.je doubleValue];
        delta = all - sum - rest;
        _checkMessage = [[NSString alloc] initWithFormat:@"总共：%.2f元,\n已减：%.2f元,\n剩余：%.2f元,\n次数：%@次\n差错：%.2f元",all,sum,rest,@(times),delta];
    }
    
    if (show) {
        [FSAlertView showString:_checkMessage callback:nil];
    }else{
        BOOL hasError = fabs(delta) > 0.1;
        if (hasError) {
            if (!_bbi) {
                _bbi = [[UIBarButtonItem alloc] initWithTitle:@"检测" style:UIBarButtonItemStylePlain target:self action:@selector(checkAction)];
                self.navigationItem.rightBarButtonItem = _bbi;
            }
        }
    }
}

- (void)trackDesignViews{
    if (!_tableView) {
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, 80)];
        _headView.backgroundColor = FS_GreenColor;
        NSArray *values = @[[FSKit ymdhsByTimeIntervalString:_model.time],[[NSString alloc] initWithFormat:@"%.2f",[_model.je doubleValue]],NSLocalizedString(@"Remaining", nil),[[NSString alloc] initWithFormat:@"%.2f",[[_type isEqualToString:_model.atype]?_model.arest:_model.brest doubleValue]]];
        CGFloat width = (WIDTHFC - 30) / 2;
        for (int x = 0; x < values.count; x ++) {
            UILabel *label = [FSViewManager labelWithFrame:CGRectMake(15 + (x % 2) * width, 10 + (x / 2) * 30, width, 30) text:values[x] textColor:[UIColor whiteColor] backColor:nil font:(x == 1)?FONTBOLD(20):FONTFC(14) textAlignment:(x % 2 == 0)?NSTextAlignmentLeft:NSTextAlignmentRight];
            label.tag = TAG_LABEL + x;
            [_headView addSubview:label];
        }
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.tableFooterView = [UIView new];
        _tableView.tableHeaderView = _headView;
        [self.view addSubview:_tableView];
        __weak typeof(self)this = self;
        _tableView.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            this.page = 0;
            [this trackHandleDatas];
        }];
        this.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            this.page ++;
            [this trackHandleDatas];
        }];
    }else{
        [_tableView reloadData];
        [_tableView.mj_header endRefreshing];
        [_tableView.mj_footer endRefreshing];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _datas.count;
}

- (FSABTrackCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSABTrackCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSABTrackCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        __weak typeof(self)this = self;
        cell.hCallback = ^(CGFloat h, NSInteger index) {
            [this.heights setObject:@(h) forKey:@(index).stringValue];
        };
    }
    NSInteger row = indexPath.row;
    cell.index = row;
    FSABTrackModel *model = _datas[row];
    cell.model = model;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [[self.heights objectForKey:@(indexPath.row).stringValue] doubleValue];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
