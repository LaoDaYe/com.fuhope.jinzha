//
//  FSAnnalDetailCell.h
//  myhome
//
//  Created by FudonFuchina on 2018/2/3.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSAnnalDetailCell : UITableViewCell

- (void)configData:(NSString *)text1 text2:(NSString *)text2 color:(UIColor *)color;

@end
