//
//  FSAnnalsController.m
//  myhome
//
//  Created by FudonFuchina on 2018/1/14.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSAnnalsController.h"
#import "FSDBMaster.h"
#import "FSAnnalDetailController.h"
#import "FSDBTool.h"
#import "FSAnnalCell.h"
#import "FSAccountConfiger.h"
#import "FSDBFlowController.h"
#import "FSAPP.h"
#import <FSDate.h>

@interface FSAnnalsController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) NSArray        *years;
@property (nonatomic,strong) NSArray        *ts;

@end

@implementation FSAnnalsController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self annalConfigDatas];
    [self annalHandleDatas];
}

- (void)annalConfigDatas{
    self.title = NSLocalizedString(@"Annals", nil);
    _years = [[NSMutableArray alloc] init];
    _ts = [[NSMutableArray alloc] init];
}

- (void)annalHandleDatas{
    __weak typeof(self)this = self;
    [self showWaitView:YES];
    [self asyncHandleDatas:^(NSArray *years, NSArray *ts) {
        this.years = years;
        this.ts = ts;
        [this showWaitView:NO];
        [this annalDesignViews];
    }];
}

- (void)asyncHandleDatas:(void(^)(NSArray *years,NSArray *ts))callback{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by time ASC limit 0,1;",self.tableName];
        NSString *maxSql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by time DESC limit 0,1;",self.tableName];
        FSDBMaster *master = [FSDBMaster sharedInstance];
        NSArray *list = [master querySQL:sql tableName:self.tableName];
        NSArray *maxList = [master querySQL:maxSql tableName:self.tableName];
        NSDictionary *maxDic = maxList.firstObject;
        NSInteger maxTime = [maxDic[@"time"] integerValue];
        NSString *_value_key = @"value";
        NSMutableArray *mYears = nil;
        NSMutableArray *mTS = nil;
        if (_fs_isValidateArray(list)) {
            NSDictionary *dic = list.firstObject;
            NSString *time = [dic objectForKey:@"time"];
            NSTimeInterval t = [time doubleValue];
            NSDate *date = [[NSDate alloc] initWithTimeIntervalSince1970:t];
            NSDateComponents *c = [FSDate componentForDate:date];
            NSDateComponents *n = [FSDate componentForDate:[NSDate date]];
            NSInteger zone = MIN((n.year - c.year), 100);
            NSString *_year = @"year";
            NSString *_lr = @"lr";
            mYears = [[NSMutableArray alloc] init];
            mTS = [[NSMutableArray alloc] init];
            NSString *key = [[NSString alloc] initWithFormat:@"%@time",self.tableName];
            NSInteger lastTime = [[FSAPP objectForKey:key] integerValue];
            BOOL useCache = (lastTime == maxTime);
            [FSAPP setObject:@(maxTime).stringValue forKey:key];
            for (int x = 0; x <= zone; x ++) {
                NSInteger year = n.year - zone + x;
                NSArray<NSDictionary *> *datas = [FSDBTool yearsOfSubjectByTable:self.tableName year:year useCacheIfExist:useCache];
                if (datas) {
                    [mYears insertObject:datas atIndex:0];
                    CGFloat sum_sr = 0;
                    CGFloat sum_cb = 0;
                    for (NSDictionary *d in datas) {
                        NSDictionary *v = [d objectForKey:_value_key];
                        CGFloat sr = [[v objectForKey:_subject_SR] doubleValue];
                        CGFloat cb = [[v objectForKey:_subject_CB] doubleValue];
                        sum_sr += sr;
                        sum_cb += cb;
                    }
                    NSString *sr = [[NSString alloc] initWithFormat:@"%.2f",sum_sr];
                    NSString *cb = [[NSString alloc] initWithFormat:@"%.2f",sum_cb];
                    NSString *lr = [[NSString alloc] initWithFormat:@"%.2f",sum_sr - sum_cb];
                    NSDictionary *need = @{_year:@(year).stringValue,_subject_SR:sr,_subject_CB:cb,_lr:lr};
                    [mTS insertObject:need atIndex:0];
                }
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (callback) {
                callback(mYears,mTS);
            }
        });
    });
}

- (void)annalDesignViews{
    if (!_tableView) {
        UIBarButtonItem *flow = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Flow", nil) style:UIBarButtonItemStylePlain target:self action:@selector(flowAction)];
        self.navigationItem.rightBarButtonItem = flow;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = 140;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.estimatedSectionHeaderHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-64-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
    }else{
        [_tableView reloadData];
    }
}

- (void)flowAction{
    FSDBFlowController *flow = [[FSDBFlowController alloc] init];
    flow.tableName = self.tableName;
    flow.firstTime = _firstTime;
    [self.navigationController pushViewController:flow animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _years.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (FSAnnalCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSAnnalCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSAnnalCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSInteger section = indexPath.section;
    if (_ts.count > section) {
        NSDictionary *dic = _ts[section];
        [cell configData:dic];
    }
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSDictionary *t = [_ts objectAtIndex:section];
    NSString *year = [t objectForKey:@"year"];
    if (_fs_isValidateString(year)) {
        return year;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return .1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *t = [_ts objectAtIndex:indexPath.section];
    NSInteger year = [[t objectForKey:@"year"] integerValue];
    FSAnnalDetailController *ad = [[FSAnnalDetailController alloc] init];
    ad.accountName = self.tableName;
    ad.year = year;
    [self.navigationController pushViewController:ad animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
