//
//  FSABSearchResultView.h
//  myhome
//
//  Created by FudonFuchina on 2018/6/24.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSABSearchResultView : UIView

@property (nonatomic,strong) NSArray    *list;

@end
