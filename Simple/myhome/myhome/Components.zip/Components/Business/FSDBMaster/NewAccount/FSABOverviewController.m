//
//  FSFinancesManagerController.m
//  SQL
//
//  Created by fudon on 2016/8/23.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSABOverviewController.h"
#import "FSFMExpectController.h"
#import "FSShare.h"
#import "FATool.h"
#import "FSAddAccountController.h"
#import "FSAccountListController.h"
#import "FSSQLEntity.h"
#import "FSABDetailController.h"
#import "UIViewController+BackButtonHandler.h"
#import "FSDBTool.h"
#import "FSDBMobanController.h"
#import "FSAPP.h"
#import "UITableViewCell+ShowDelete.h"
#import "FSAnnalsController.h"
#import <MJRefresh.h>
#import "FSPublic.h"
#import <FSDate.h>
#import "FSTitleContentView.h"
#import <FSUIKit.h>
#import "FSTrackKeys.h"

static NSString *_cell_notice = @"Overview_cell_notice";

@interface FSABOverviewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSArray        *array;
@property (nonatomic,strong) NSArray        *values;
@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) UIView         *headView;
@property (nonatomic,assign) BOOL           haveUpdated;
@property (nonatomic,assign) BOOL           needRefresh;
@property (nonatomic,strong) FSSQLEntity    *entity;
@property (nonatomic,assign) BOOL           needNew;

@end

@implementation FSABOverviewController{
    FSTitleContentView              *_lastLabel;
    NSTimeInterval                  _theEarliestTime;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_Notifi_refreshAccount object:nil];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (_needRefresh) {
        _needRefresh = NO;
        [self fmHandleDatas];
    }
}

- (void)viewDidLoad{
    [super viewDidLoad];
    _needRefresh = YES;
    _fs_dispatch_global_main_queue_async(^{
        [self getTheFirstTime];
    }, ^{
        [self fmDesignViews];
        [self refreshData:nil];
    });    
}

- (void)shakeEndActionFromShakeBase{
    [FSPublic shareAction:self view:_tableView];
}

-(BOOL)navigationShouldPopOnBackButton{
    if (self.haveUpdated) {
        [self.navigationController popToRootViewControllerAnimated:NO];
        [[NSNotificationCenter defaultCenter] postNotificationName:_Notifi_sendSqlite3 object:nil];
        return NO;
    }
    return YES;
}

- (void)fmHandleDatas{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *countKey = [FSDBTool accountChangeKey:self.accountName type:_type_count];
        if (!self.needNew) {
            NSInteger countTime = [_fs_userDefaults_objectForKey(countKey) integerValue];
            
            NSString *key = [FSDBTool accountChangeKey:self.accountName type:_type_account];
            NSInteger accTime = [_fs_userDefaults_objectForKey(key) integerValue];
            if (countTime > accTime) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self refreshData:nil];
                });
                return;
            }
        }else{
            self.needNew = NO;
        }
        
        CGFloat timedelta = _fs_timeIntevalSince1970();
        static CGFloat yearSeconds = 365.2422 * 24 * 3600;
        FSSQLEntity *entity = [FSDBTool fasterEntityFromDB:self->_accountName start:_fs_timeIntevalSince1970() - yearSeconds];
        [entity cacheTable:self->_accountName];
        _fs_userDefaults_setObjectForKey(@(_fs_integerTimeIntevalSince1970()).stringValue, countKey);
        dispatch_async(dispatch_get_main_queue(), ^{
            [self refreshData:entity];
            CGFloat delta = _fs_timeIntevalSince1970() - timedelta;
            if (delta > 5) {
                [FSTrack event:_UMeng_Event_acc_alldata];
            }
            [self.tableView.mj_header endRefreshing];
        });
    });
}

- (void)refreshData:(FSSQLEntity *)entity{
    if ([entity isKindOfClass:FSSQLEntity.class]) {
        self.entity = entity;
    }else{
        self.entity = [FSSQLEntity entity:_accountName];
    }
    if ([self.entity.ph integerValue] > 1) {
        [FSToast show:@"试算不平衡"];
    }
    if (self.tableView) {
        CGFloat ys = [self.entity.ys doubleValue];
        CGFloat xj = [self.entity.xj doubleValue];
        CGFloat ch = [self.entity.ch doubleValue];
        CGFloat tz = [self.entity.tz doubleValue];
        CGFloat tx = [self.entity.tx doubleValue];
        CGFloat gz = [self.entity.gz doubleValue];
        CGFloat fz = [self.entity.fz doubleValue];
        CGFloat ps = [self.entity.ps doubleValue];
        CGFloat sr = [self.entity.ts doubleValue];
        CGFloat cb = [self.entity.tc doubleValue];
        CGFloat bj = [self.entity.bj doubleValue];
        CGFloat gb = [self.entity.gb doubleValue];

        NSString *forTS = [[NSString alloc] initWithFormat:@"%.2f",sr];
        NSString *forTC = [[NSString alloc] initWithFormat:@"%.2f",cb];
        NSString *forYS = [[NSString alloc] initWithFormat:@"%.2f",ys];
        NSString *forXJ = [[NSString alloc] initWithFormat:@"%.2f",xj];
        NSString *forCH = [[NSString alloc] initWithFormat:@"%.2f",ch];
        NSString *forTZ = [[NSString alloc] initWithFormat:@"%.2f",tz];
        NSString *forGZ = [[NSString alloc] initWithFormat:@"%.2f",gz];
        NSString *forTX = [[NSString alloc] initWithFormat:@"%.2f",tx];
        NSString *forFZ = [[NSString alloc] initWithFormat:@"%.2f",fz];
        NSString *forPS = [[NSString alloc] initWithFormat:@"%.2f",ps];
        NSString *forBJ = [[NSString alloc] initWithFormat:@"%.2f",bj];
        NSString *forGB = [[NSString alloc] initWithFormat:@"%.2f",gb];

        self.values = @[forTS,forTC,forXJ,forYS,forCH,forTZ,forGZ,forTX,forFZ,forPS,forBJ,forGB];
        [self.tableView reloadData];
        
        CGFloat assets = ys + xj + ch + tz + gz + tx;
        CGFloat debts = fz + ps;
        CGFloat jzc = assets - debts;
        CGFloat jsr = sr - cb;
        CGFloat zzl = debts / (assets + 0.001);
        CGFloat zzl_noCash = (debts - xj) / MAX(0.001,(assets - xj));
        CGFloat jlv = jsr / (sr + 0.001);
        
        NSString *asset = [[NSString alloc] initWithFormat:@"%.2f",assets];
        NSString *debt = [[NSString alloc] initWithFormat:@"%.2f",debts];
        NSString *jzcStr = [[NSString alloc] initWithFormat:@"%.2f",jzc];
        NSString *jsrStr = [[NSString alloc] initWithFormat:@"%.2f",jsr];
        NSString *zzlStr = [[NSString alloc] initWithFormat:@"%.2f%@",zzl * 100,@"%"];
        NSString *zzlStr_noCash = [[NSString alloc] initWithFormat:@"%.2f%@",zzl_noCash * 100,@"%"];
        NSString *jlvStr = [[NSString alloc] initWithFormat:@"%.2f%@",jlv * 100,@"%"];
        
        NSDate *now = [NSDate date];
        NSDateComponents *c = [FSDate componentForDate:now];
        NSInteger secondFirst = [FSDate theFirstSecondOfYear:c.year];
        NSInteger secondNow = [now timeIntervalSince1970];
        CGFloat rate = (secondNow - secondFirst) / (365.2422 * 24 * 3600);
        CGFloat yR = jsr / (jzc + 0.01) * 100;
        NSString *jzsStr = [[NSString alloc] initWithFormat:@"%.2f%% | %.2f%%",yR,yR / rate];
        
        BOOL needYellowColor = zzl_noCash > 0.5?YES:NO;
        NSArray *heads = @[asset,debt,jzcStr,jsrStr,jzsStr,zzlStr,zzlStr_noCash,jlvStr];
        for (int x = 0; x < heads.count; x ++) {
            FSTitleContentView *v = [self.headView viewWithTag:TAG_LABEL + x];
            v.contentLabel.text = heads[x];
            if (x == 5) {
                v.contentLabel.textColor = needYellowColor?[UIColor yellowColor]:[UIColor whiteColor];
            }
            if (x == 6) {
                v.contentLabel.textColor = needYellowColor?[UIColor yellowColor]:[UIColor whiteColor];
            }
        }
        NSString *text = [FSAPP messageForTable:self.accountName];
        _lastLabel.contentLabel.text = text?:NSLocalizedString(@"Nothing", nil);
    }else{
        [self fmDesignViews];
    }
}

- (NSInteger)getTheFirstTime{
    if (_theEarliestTime > 0) {
        return _theEarliestTime;
    }
    _theEarliestTime = _fs_timeIntevalSince1970();
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by cast(time as REAL) ASC limit 0,1",_accountName];
    FSDBMaster *m = [FSDBMaster sharedInstance];
    NSArray *theEarliest = [m querySQL:sql tableName:_accountName];
    if (theEarliest.count) {
        NSDictionary *model = [theEarliest firstObject];
        _theEarliestTime = [model[@"time"] doubleValue];
    }
    return _theEarliestTime;
}

- (void)actions{
    FSAnnalsController *annals = [[FSAnnalsController alloc] init];
    annals.tableName = self.accountName;
    annals.firstTime = _theEarliestTime;
    [self.navigationController pushViewController:annals animated:YES];
}

- (void)notificationAction{
    _needRefresh = YES;
    _haveUpdated = YES;
}

- (void)fmDesignViews{
    if (self.tableView) {
        return;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notificationAction) name:_Notifi_refreshAccount object:nil];
    
    UIBarButtonItem *flow = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Annals", nil) style:UIBarButtonItemStylePlain target:self action:@selector(actions)];
    UIBarButtonItem *bbi = [FSViewManager bbiWithSystemType:UIBarButtonSystemItemBookmarks target:self action:@selector(bbiAction)];
    self.navigationItem.rightBarButtonItems = @[bbi,flow];
    
    CGFloat uHeight = 30;
    CGFloat margin = 10;
    _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 9 * uHeight + margin * 2)];
    _headView.backgroundColor = FS_GreenColor;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headAction)];
    [_headView addGestureRecognizer:tap];
    
    NSArray *titles = @[_subject_ZC,_subject_FZ,_subject_QY,_hanzi_LR,_hanzi_JZS,_hanzi_ZZL,_hanzi_ZZL_NOCASH,_hanzi_JLV];
    for (int x = 0; x < titles.count + 1; x ++) {
        BOOL last = (x == titles.count);
        FSTitleContentView *v = [[FSTitleContentView alloc] initWithFrame:CGRectMake(15, margin + uHeight * x, WIDTHFC - 30, uHeight)];
        v.label.text = last?NSLocalizedString(@"Recently", nil):[FATool hansForShort:titles[x]];
        v.label.textColor = [UIColor whiteColor];
        v.tag = TAG_LABEL + x;
        v.contentLabel.textColor = [UIColor whiteColor];
        [_headView addSubview:v];
        
        if (last) {
            _lastLabel = v;
            v.contentLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        }
    }
    
    _array = @[_subject_SR,_subject_CB,_subject_XJ,_subject_YS,_subject_CH,_subject_TZ,_subject_GZ,_subject_TX,_subject_FZ,_subject_PS,_subject_BJ,_subject_GB];
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height - 108 - (FS_iPhone_X?34:0)) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = 50;
    _tableView.tableHeaderView = _headView;
    _tableView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_tableView];
    WEAKSELF(this);
    _tableView.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        this.needNew = YES;
        [this fmHandleDatas];
    }];
    
    for (int x = 0; x < 2; x ++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(x * self.view.width / 2, self.view.height - 44 - (FS_iPhone_X * 34), self.view.width / 2, 44);
        [button setTitle:x?NSLocalizedString(@"By form", nil):NSLocalizedString(@"Record", nil) forState:UIControlStateNormal];
        button.backgroundColor = FSAPPCOLOR;
        button.tag = x;
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(addAcountAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        if (x) {
            UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 12, 1, 20)];
            line.backgroundColor = [UIColor whiteColor];
            [button addSubview:line];
        }
    }
    
//    NSString *need = [FSKit userDefaultsDataWithKey:_cell_notice];
//    NSInteger times = [need integerValue];
//    if (times < 3) {
//        // 提示动画
//        NSIndexPath *ip = [NSIndexPath indexPathForRow:0 inSection:0];
//        UITableViewCell *cell = [_tableView cellForRowAtIndexPath:ip];
//        if (cell) {
//            [cell showNotice:YES textIfShow:NSLocalizedString(@"Earning", nil) andNotice:NSLocalizedString(@"Notice", nil)];
//            [FSKit userDefaultsKeepData:@(++times).stringValue withKey:_cell_notice];
//        }
//    }
}

- (void)headAction{
    if (self.values.count < 8) {
        return;
    }    
    FSFMExpectController *expect = [[FSFMExpectController alloc] init];
    expect.accountName = self.accountName;
    expect.theEarliestTime = _theEarliestTime;
    [self.navigationController pushViewController:expect animated:YES];
}

- (void)bbiAction{
    FSAccountListController *listController = [[FSAccountListController alloc] init];
    listController.accountName = self.accountName;
    listController.entity = self.entity;
    [self.navigationController pushViewController:listController animated:YES];
}

- (void)addAcountAction:(UIButton *)button{
    if (button.tag) {
        FSDBMobanController *moban = [[FSDBMobanController alloc] init];
        moban.type = @"1";
        moban.account = self.accountName;
        [self.navigationController pushViewController:moban animated:YES];
        [FSTrack event:_UMeng_Event_acc_mb];
    }else{
        FSAddAccountController *controller = [[FSAddAccountController alloc] init];
        controller.accountName = self.accountName;
        controller.type = @"1";
        [self.navigationController pushViewController:controller animated:YES];
        [FSTrack event:_UMeng_Event_acc_do];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.font = [UIFont systemFontOfSize:16];
    }
    
    NSInteger row = indexPath.row;
    cell.textLabel.text = [FATool hansForShort:_array[row]];
    if (_values.count > row) {
        cell.detailTextLabel.text = _values[row];
    }
    
    if (row == 2){
        cell.detailTextLabel.textColor = FS_GreenColor;
    }else if (row == 3 || row == 8){
        cell.detailTextLabel.textColor = [UIColor redColor];
    }else {
        cell.detailTextLabel.textColor = FS_TextColor_Normal;
    }
    
    if (row == 9 || row == 11) {
        cell.textLabel.textColor = FS_TextColor_Light;
    }else{
        cell.textLabel.textColor = [UIColor blackColor];
    }
    return cell;
}

- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewRowAction *done = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:NSLocalizedString(@"Notice", nil) handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
        [self showNotice:indexPath.row];
        tableView.editing = NO;
    }];
    done.backgroundColor = FS_GreenColor;
    return @[done];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) {
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        [cell showNotice:NO textIfShow:nil andNotice:nil];
    }
    NSString *type = _array[indexPath.row];
    [self pushToDetail:type];
}

- (void)pushToDetail:(NSString *)type{
    FSABDetailController *selectController = [[FSABDetailController alloc] init];
    selectController.type = type;
    selectController.accountName = self.accountName;
    [self.navigationController pushViewController:selectController animated:YES];
}

- (void)showNotice:(NSInteger)row{
    [FSTrack event:_UMeng_Event_seeAccNotice];
    Tuple2 *t = [[Tuple2 alloc] init];
    switch (row) {
        case 0:{
            t._1 = NSLocalizedString(@"Earning", nil);
            t._2 = NSLocalizedString(@"Earning notice", nil);
        }break;
        case 1:{
            t._1 = NSLocalizedString(@"Cost", nil);
            t._2 = NSLocalizedString(@"Cost notice", nil);
        }break;
        case 2:{
            t._1 = NSLocalizedString(@"Accounts receivable", nil);
            t._2 = NSLocalizedString(@"Receivable notice", nil);
        }break;
        case 3:{
            t._1 = NSLocalizedString(@"Cash", nil);
            t._2 = NSLocalizedString(@"Cash notice", nil);
        }break;
        case 4:{
            t._1 = NSLocalizedString(@"Inventory", nil);
            t._2 = NSLocalizedString(@"Inventory notice", nil);
        }break;
        case 5:{
            t._1 = NSLocalizedString(@"Investment", nil);
            t._2 = NSLocalizedString(@"Investment notice", nil);
        }break;
        case 6:{
            t._1 = NSLocalizedString(@"Fixed asset", nil);
            t._2 = NSLocalizedString(@"Fixed asset notice", nil);
        }break;
        case 7:{
            t._1 = NSLocalizedString(@"Amortizable intangibles", nil);
            t._2 = NSLocalizedString(@"Amortizable intangibles notice", nil);
        }break;
        case 8:{
            t._1 = NSLocalizedString(@"Liabilities", nil);
            t._2 = NSLocalizedString(@"Liabilities notice", nil);
        }break;
        case 9:{
            t._1 = NSLocalizedString(@"Deferred revenue", nil);
            t._2 = NSLocalizedString(@"Deferred revenue notice", nil);
        }break;
        case 10:{
            t._1 = NSLocalizedString(@"Owner's equity", nil);
            t._2 = NSLocalizedString(@"Owner's equity notice", nil);
        }break;
        case 11:{
            t._1 = NSLocalizedString(@"Capital stock", nil);
            t._2 = NSLocalizedString(@"Capital stock notice", nil);
        }break;
        default:
            break;
    }
    if (t._1 && t._2) {
        [FSUIKit showAlertWithTitle:t._1 message:t._2 ok:@"OK" controller:self handler:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
