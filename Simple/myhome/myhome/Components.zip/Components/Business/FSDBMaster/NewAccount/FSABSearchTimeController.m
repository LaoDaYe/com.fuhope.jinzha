//
//  FSABSearchTimeController.m
//  myhome
//
//  Created by FudonFuchina on 2017/9/13.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABSearchTimeController.h"
#import <MJRefresh.h>
#import "FSABListCell.h"
#import "FSDBSupport.h"
#import "FSDatePickerView.h"
#import "FSAccountConfiger.h"
#import <FSDate.h>

@interface FSABSearchTimeController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UIBarButtonItem    *bbi;
@property (nonatomic,strong) NSMutableArray     *array;
@property (nonatomic,assign) NSInteger          page;
@property (nonatomic,assign) NSTimeInterval     start;
@property (nonatomic,assign) NSTimeInterval     end;

@end

@implementation FSABSearchTimeController{
    UITableView     *_tb;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Search Data", nil);
    [self searchDesignViews];
}

- (void)searchHandleDatas{
    NSString *condition = @"";
    if (_fs_isValidateString(_subject)) {
        NSString *ingKey = [[NSString alloc] initWithFormat:@"%@%@",_subject,_ING_KEY];
        NSString *edKey = [[NSString alloc] initWithFormat:@"%@%@",_subject,_ED_KEY];
        condition = [[NSString alloc] initWithFormat:@" (atype = '%@' or atype = '%@' or btype = '%@' or btype = '%@') and",ingKey,edKey,ingKey,edKey];
    }
    
    NSInteger unit = 10;
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE%@ cast(time as real) BETWEEN %@ AND %@ order by cast(time as real) DESC limit %@,%@;",_tableName,condition,@(_start),@(_end),@(self.page * unit),@(unit)];
    NSMutableArray *array = [FSDBSupport querySQL:sql class:FSABModel.class tableName:_tableName];
    for (FSABModel *model in array) {
        [model processPropertiesWithType:nil canSeeTrack:NO search:nil isCompany:NO];
    }
    
    if (self.page) {
        [self.array addObjectsFromArray:array];
    }else{
        self.array = array;
    }
    [self searchDesignViews];
}

- (void)btnClick:(UIButton *)button{
    FSDatePickerView *p = [[FSDatePickerView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64)];
    [self.view addSubview:p];
    __weak typeof(self)this = self;
    p.block = ^(NSDate *bDate) {
        NSDateComponents *c = [FSDate componentForDate:bDate];
        if (button.tag) {
            NSString *dateString = [[NSString alloc] initWithFormat:@"%@-%@-%@ 23:59:59",@(c.year),[FSKit twoChar:c.month],[FSKit twoChar:c.day]];
            NSDate *end = [FSDate dateByString:dateString formatter:nil];
            this.end = [end timeIntervalSince1970];
        }else{
            NSString *dateString = [[NSString alloc] initWithFormat:@"%@-%@-%@ 00:00:00",@(c.year),[FSKit twoChar:c.month],[FSKit twoChar:c.day]];
            NSDate *start = [FSDate dateByString:dateString formatter:nil];
            this.start = [start timeIntervalSince1970];
        }
        NSString *str = [FSDate stringWithDate:bDate formatter:@"yyyy-MM-dd"];
        [button setTitle:str forState:UIControlStateNormal];
        if (this.start > 10 && this.end > 10) {
            this.bbi.enabled = YES;
        }
    };
}

- (void)bbiAction{
    [self searchHandleDatas];
}

- (void)searchDesignViews{
    if (!_tb) {
        _bbi = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Search", nil) style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
        self.navigationItem.rightBarButtonItem = _bbi;
        _bbi.enabled = NO;
        
        UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, 50)];
        headView.backgroundColor = THISCOLOR;
        headView.userInteractionEnabled = YES;
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(WIDTHFC / 2 - 15, 10, 30, 30)];
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont systemFontOfSize:13];
        label.text = NSLocalizedString(@"To", nil);
        [headView addSubview:label];
        for (int x = 0; x < 2; x ++) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
            button.frame = CGRectMake(x * WIDTHFC / 2, 3, WIDTHFC / 2, 44);
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [button setTitle:x?NSLocalizedString(@"End time", nil):NSLocalizedString(@"Start time", nil) forState:UIControlStateNormal];
            button.tag = x;
            [button addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [headView addSubview:button];
        }
        
        _tb = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStyleGrouped];
        _tb.delegate = self;
        _tb.dataSource = self;
        _tb.estimatedSectionHeaderHeight = 0;
        _tb.estimatedSectionFooterHeight = 0;
        _tb.tableHeaderView = headView;
        [self.view addSubview:_tb];
        WEAKSELF(this);
        _tb.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            this.page = 0;
            [this searchHandleDatas];
        }];
        _tb.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            this.page ++;
            [this searchHandleDatas];
        }];
    }else{
        [_tb reloadData];
        [_tb.mj_header endRefreshing];
        [_tb.mj_footer endRefreshing];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.array.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (FSABListCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSABListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSABListCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    cell.index = indexPath.section;
    
    FSABModel *entity = self.array[indexPath.section];
    [cell flowConfigDataWithEntity:entity];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSABModel *entity = self.array[indexPath.section];
    return entity.cellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return .1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
