//
//  FSABSubjectModel.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/29.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABSubjectModel.h"

@implementation FSABSubjectModel

@end
