//
//  FSABCompanyOverviewController.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/28.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABCompanyOverviewController.h"
#import "FSFMExpectController.h"
#import "FSShare.h"
#import "FATool.h"
#import "FSAddAccountController.h"
#import "FSAccountListController.h"
#import "FSSQLEntity.h"
#import "FSABDetailController.h"
#import "UIViewController+BackButtonHandler.h"
#import "FSDBTool.h"
#import "FSABSubjectController.h"
#import <FSUIKit.h>

@interface FSABCompanyOverviewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSArray        *array;
@property (nonatomic,strong) NSArray        *values;
@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) UIView         *headView;
@property (nonatomic,assign) NSInteger      checkValue;
@property (nonatomic,assign) BOOL           haveUpdated;
@property (nonatomic,strong) FSSQLEntity    *entity;

#if DEBUG
@property (nonatomic,strong) UILabel        *timeLabel;
#endif

@end

@implementation FSABCompanyOverviewController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self fmHandleDatas];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self fmDesignViews];
}

-(BOOL)navigationShouldPopOnBackButton
{
    if (self.haveUpdated) {
        [self.navigationController popToRootViewControllerAnimated:NO];
        [[NSNotificationCenter defaultCenter] postNotificationName:_Notifi_sendSqlite3 object:nil];
        return NO;
    }
    return YES;
}

- (void)fmHandleDatas{
    WEAKSELF(this);
    FSSQLEntity *sql = [FSDBTool fasterEntityFromDB:_accountName start:0];
    self.entity = sql;
    
#if DEBUG
//    _timeLabel.hidden = NO;
//    _timeLabel.text = [[NSString alloc] initWithFormat:@"耗时%f秒",delta];
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        _timeLabel.hidden = YES;
//    });
#endif
    
    if (this.tableView) {
        CGFloat ys = [sql.ys doubleValue];CGFloat xj = [sql.xj doubleValue];CGFloat ch = [sql.ch doubleValue];
        CGFloat tz = [sql.tz doubleValue];CGFloat tx = [sql.tx doubleValue];CGFloat fz = [sql.fz doubleValue];
        CGFloat sr = [sql.sr doubleValue];CGFloat cb = [sql.cb doubleValue];CGFloat bj = [sql.bj doubleValue];
        
        NSInteger value = (NSInteger)(ys * 2 + xj * 3 + ch * 4 + tz * 5 + tx * 6 + fz * 7 + sr * 8 + cb * 9 + bj * 10);
        if (self.checkValue && !_haveUpdated) {
            _haveUpdated = self.checkValue != value;
        }
        self.checkValue = value;
        
        this.values = @[sql.sr,sql.cb,sql.ys,sql.xj,sql.ch,sql.tz,sql.tx,sql.fz,sql.bj];
        [this.tableView reloadData];
        
        CGFloat allMoney = ys + xj + ch + tz + tx;
        CGFloat jzc = allMoney - fz;
        CGFloat jsr = sr - cb;
        CGFloat zzl = 0;
        if (allMoney >= 0.001) {
            zzl = fz / allMoney;
        }
        CGFloat jlv = 0;
        if (sr >= 0.001) {
            jlv = jsr / sr;
        }
        NSArray *heads = @[[[NSString alloc] initWithFormat:@"%.2f",allMoney],sql.fz,[[NSString alloc] initWithFormat:@"%.2f",jzc],[[NSString alloc] initWithFormat:@"%.2f%@",zzl * 100,@"%"],[[NSString alloc] initWithFormat:@"%.2f",jsr],[[NSString alloc] initWithFormat:@"%.2f%@",jlv * 100,@"%"],sql.ph];
        for (int x = 0; x < 7; x ++) {
            UILabel *label = [this.headView viewWithTag:TAG_LABEL + x];
            label.text = heads[x];
        }
    }else{
        [this fmDesignViews];
    }
}

- (void)shareAction{
    [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Share screenshot to Wechat?", nil) message:NSLocalizedString(@"Screenshot picture", nil) actionTitles:@[NSLocalizedString(@"Send", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        UIImage *image = [FSUIKit captureScrollView:self->_tableView];
        if ([image isKindOfClass:UIImage.class]) {
            [FSShare wxImageShareActionWithImage:image controller:self result:^(NSString *bResult) {
                [FSToast show:bResult];
            }];
        }
    }];
}

- (void)fmDesignViews
{
    UIBarButtonItem *share = [FSViewManager bbiWithSystemType:UIBarButtonSystemItemAction target:self action:@selector(shareAction)];
    UIBarButtonItem *bbi = [FSViewManager bbiWithSystemType:UIBarButtonSystemItemBookmarks target:self action:@selector(bbiAction)];
    self.navigationItem.rightBarButtonItems = @[bbi,share];
    
    _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 230)];
    _headView.backgroundColor = FS_GreenColor;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headAction)];
    [_headView addGestureRecognizer:tap];
    
    NSArray *titles = @[_hanzi_ZZL,_hanzi_TTR,_hanzi_JLV];
    for (int x = 0; x < titles.count; x ++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 10 + 30 * x, 80, 30)];
        label.text = [FATool hansForShort:titles[x]];
        label.textColor = [UIColor whiteColor];
        [_headView addSubview:label];
        
        UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.view.bounds.size.width / 2, 10 + 30 * x, self.view.bounds.size.width / 2 - 15, 30)];
        valueLabel.textAlignment = NSTextAlignmentRight;
        valueLabel.tag = TAG_LABEL + x;
        valueLabel.textColor = [UIColor whiteColor];
        [_headView addSubview:valueLabel];
    }
    _headView.height = titles.count * 30 + 20;
#if DEBUG
    _timeLabel = [FSViewManager labelWithFrame:CGRectMake(WIDTHFC / 4, _headView.height / 2 - 15, WIDTHFC / 2, 30) text:nil textColor:[UIColor whiteColor] backColor:nil font:FONTFC(16) textAlignment:NSTextAlignmentCenter];
    _timeLabel.hidden = YES;
    [_headView addSubview:_timeLabel];
#endif
    
    _array = @[_subject_SR,_subject_CB,_hanzi_LR,_subject_ZC,_subject_FZ,_subject_QY];
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height - 108) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableHeaderView = _headView;
    _tableView.tableFooterView = [UIView new];
    _tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_tableView];
    
    UIButton *addButton = [FSViewManager buttonWithFrame:CGRectMake(0, self.view.height - 44, WIDTHFC, 44) title:@"记一笔" titleColor:nil backColor:FSAPPCOLOR fontInt:14 tag:0 target:self selector:@selector(addAcountAction)];
    [self.view addSubview:addButton];
}

- (void)headAction{
//    if (self.values.count < 8) {
//        return;
//    }
//    UILabel *moneyLabel = [_headView viewWithTag:TAGLABEL + 2];
//    UILabel *jsrLabel = [_headView viewWithTag:TAGLABEL + 4];
//    
//    FSFMExpectController *expect = [[FSFMExpectController alloc] init];
//    expect.accountName = self.accountName;
//    expect.jsr = [jsrLabel.text doubleValue];
//    expect.jzc = [moneyLabel.text doubleValue];
//    expect.debt = [self.values[7] doubleValue];
//    expect.cash = [self.values[3] doubleValue];
//    expect.cb = [self.values[1] doubleValue];
//    expect.ys = [self.values[2] doubleValue];
//    expect.tz = [self.values[5] doubleValue];
//    expect.tx = [self.values[6] doubleValue];
//    expect.ch = [self.values[4] doubleValue];
//    [self.navigationController pushViewController:expect animated:YES];
}

- (void)bbiAction
{
    FSAccountListController *listController = [[FSAccountListController alloc] init];
    listController.accountName = self.accountName;
    listController.entity = self.entity;
    [self.navigationController pushViewController:listController animated:YES];
}

- (void)addAcountAction
{
    FSAddAccountController *controller = [[FSAddAccountController alloc] init];
    controller.accountName = self.accountName;
    [self.navigationController pushViewController:controller animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"accountCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.textLabel.text = [FATool hansForShort:_array[indexPath.row]];
    if (_values.count > indexPath.row) {
        cell.detailTextLabel.text = _values[indexPath.row];
    }
    
    if (indexPath.row == 3){
        cell.detailTextLabel.textColor = FS_GreenColor;
    }else if (indexPath.row == 2 || indexPath.row == 7){
        cell.detailTextLabel.textColor = [UIColor redColor];
    }else {
        cell.detailTextLabel.textColor = FS_TextColor_Normal;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    FSABSubjectType type = FSABSubjectTypeProfitStatement;
    NSInteger row = indexPath.row;
    NSString *title = nil;
    if (row < 3) {
        title = @"利润表";
    }else{
        title = [FATool hansForShort:_array[row]];
        type = row;
    }
    
    FSABSubjectController *subject = [[FSABSubjectController alloc] init];
    subject.title = title;

//    selectController.accountName = self.accountName;
    [self.navigationController pushViewController:subject animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
