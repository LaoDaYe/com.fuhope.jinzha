//
//  FSABAddSubjectController.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/29.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABAddSubjectController.h"
#import "FSViewManager.h"
#import "FSMacro.h"

@interface FSABAddSubjectController ()

@end

@implementation FSABAddSubjectController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSubjectDesignViews];
}

- (void)addSubjectDesignViews{
    self.title = @"增加科目";
    
    NSArray *titles = @[@"科目名称",@"贷款期数",@"年利率"];
    NSArray *placeholders = @[@"请填写",@"月数，如10年填120",@"如5%，填5"];
    for (int x = 0; x < titles.count; x ++) {
        UILabel *label = [FSViewManager labelWithFrame:CGRectMake(0,80 + 50 * x, 70, 40) text:titles[x] textColor:nil backColor:nil font:FONTFC(15) textAlignment:NSTextAlignmentRight];
        [self.view addSubview:label];
        
        UITextField *textField = [FSViewManager textFieldWithFrame:CGRectMake(label.right + 10, label.top, WIDTHFC - 30 - label.width, label.height) placeholder:placeholders[x] textColor:nil backColor:RGBCOLOR(240, 240, 240, 1)];
        textField.tag = TAG_TEXTFIELD + x;
        if (x == 1) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
        }else{
            textField.keyboardType = UIKeyboardTypeDecimalPad;
        }
        [self.view addSubview:textField];
    }
    
    UIButton *button = [FSViewManager buttonWithFrame:CGRectMake(20, 240, WIDTHFC - 40, 40) title:NSLocalizedString(@"Add", nil) titleColor:[UIColor whiteColor] backColor:FSAPPCOLOR fontInt:0 tag:0 target:self selector:@selector(addSubject)];
    [self.view addSubview:button];
}

- (void)addSubject{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
