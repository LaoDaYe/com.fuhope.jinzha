//
//  FSABAddSubjectController.h
//  myhome
//
//  Created by FudonFuchina on 2017/7/29.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSABAddSubjectController : FSBaseController

@end
