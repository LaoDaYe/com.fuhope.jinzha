//
//  FSABSubjectController.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/29.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSABSubjectController.h"
#import "FSABAddSubjectController.h"

@interface FSABSubjectController ()

@end

@implementation FSABSubjectController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self subjectHandleDatas];
}

- (void)subjectHandleDatas
{
    [self subjectDesignViews];
}

- (void)subjectDesignViews
{
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:@"科目" style:UIBarButtonItemStylePlain target:self action:@selector(addSubjectAction)];
    self.navigationItem.rightBarButtonItem = bbi;
}

- (void)addSubjectAction
{
    FSABAddSubjectController *addSubject = [[FSABAddSubjectController alloc] init];
    [self.navigationController pushViewController:addSubject animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
