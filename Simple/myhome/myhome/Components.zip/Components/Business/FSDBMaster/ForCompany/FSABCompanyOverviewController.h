//
//  FSABCompanyOverviewController.h
//  myhome
//
//  Created by FudonFuchina on 2017/7/28.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSABCompanyOverviewController : FSBaseController

@property (nonatomic,copy) NSString     *accountName;

@end
