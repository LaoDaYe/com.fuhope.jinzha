//
//  FSCCHeadView.h
//  NL
//
//  Created by fudon on 16/8/4.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSCCHeadView : UIView

@property (nonatomic,strong) NSDate     *date;

@end
