//
//  FSCCMainView.m
//  NL
//
//  Created by fudon on 16/8/4.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSCCMainView.h"
#import "FSCCDayView.h"

#define TAG_DayView     612

@interface FSCCMainView ()

@property (nonatomic,strong) NSArray        *dayViews;
@property (nonatomic,assign) CGFloat        width;

@end

@implementation FSCCMainView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self mainViewDesignViews];
    }
    return self;
}

- (void)mainViewDesignViews{
    UIView *weekView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,self.bounds.size.width, 30)];
    weekView.backgroundColor = CCGreenColor;
    [self addSubview:weekView];
    
    NSArray *titles = @[@"日",@"一",@"二",@"三",@"四",@"五",@"六"];
    _width = (self.bounds.size.width - 20) / 7;
    for (int x = 0; x < titles.count; x ++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10 + _width * x, 0, _width, 30)];
        [weekView addSubview:label];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:15];
        label.textColor = [UIColor whiteColor];
        label.text = titles[x];
    }
    
    NSTimeInterval time = [[NSDate date] timeIntervalSince1970];
    NSArray *array = @[@"Kohinoor Telugu",@"Gurmukhi MN",@"Cochin",@"Farah",@"Courier",@"Hoefler Text",@"Hiragino Mincho ProN",@"Bodoni Ornaments",@"Party LET",@"Noteworthy",@"Chalkduster",@"Mishafi",@"Optima",@"Bodoni 72",@"Baskerville",@"Arial Hebrew",@"Georgia",@"Palatino",@"Courier New",@"Oriya Sangam MN",@"Didot",@"Bodoni 72 Smallcaps"];
    NSInteger number = (NSInteger)time % array.count;
    UIFont *font = nil;
    if (array.count > number) {
        font = [UIFont fontWithName:array[number] size:25];
    }else{
        font = [UIFont systemFontOfSize:25];
    }
    
    __weak FSCCMainView *this = self;
    for (int x = 0; x < 31; x ++) {
        FSCCDayView *dayView = [[FSCCDayView alloc] initWithFrame:CGRectMake(0, 0, _width, _width * 1.25)];
        dayView.tag = TAG_DayView + x;
        dayView.font = font;
        dayView.block = ^ (FSCCDayView  *bView){
            [this reDesignViews:bView];
            if (this.block) {
                this.block(bView);
            }
        };
        [self addSubview:dayView];
    }
}

- (void)reDesignViews:(FSCCDayView *)bView
{
    for (int x = 0; x < 31; x ++) {
        FSCCDayView *dayView = [self viewWithTag:TAG_DayView + x];
        if (dayView == bView) {
            if (dayView.status != FSCCDayViewStatusToday) {
                dayView.status = FSCCDayViewStatusSelected;
            }
        }else{
            if (dayView.status != FSCCDayViewStatusToday) {
                dayView.status = FSCCDayViewStatusDefault;
            }
        }
    }
}

- (void)setFirstDay:(NSDate *)firstDay
{
    if (!firstDay) {
        return;
    }
    
    if (_firstDay != firstDay) {
        _firstDay = firstDay;
        
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekday fromDate:firstDay];
        
        NSString *dateString = [[NSString alloc] initWithFormat:@"%@-%@-%@ 00:00:00",@(components.year),@(components.month),[self dayStringForDay:1]];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSDate *first = [formatter dateFromString:dateString];
        
        NSCalendar *calendarNew = [NSCalendar currentCalendar];
        NSDateComponents *componentsNew = [calendarNew components:NSCalendarUnitWeekday fromDate:first];
        NSInteger weekDay = componentsNew.weekday;
        [self countFrame:weekDay days:[self howManyDaysInThisMonth:first] first:first];
    }
}

- (void)countFrame:(NSInteger)weekday days:(NSInteger)days first:(NSDate *)first
{
    CGFloat height = _width * 1.25;
    NSInteger offset = weekday - 1;
    for (int x = 0; x < 31; x ++) {
        FSCCDayView *dayView = [self viewWithTag:TAG_DayView + x];
        dayView.hidden = !(x < days);
        
        CGFloat xPoint = 10 + ((x + offset) % 7) * _width;
        CGFloat yPoint = 30 + ((x + offset) / 7) * height;
        dayView.frame = CGRectMake(xPoint, yPoint, dayView.bounds.size.width, dayView.bounds.size.height);
        
        NSDate *date = [[NSDate alloc] initWithTimeInterval:3600 * 24 * x sinceDate:first];
        dayView.date = date;
    }
}

- (NSString *)dayStringForDay:(NSInteger)day
{
    if (day < 10) {
        return [[NSString alloc] initWithFormat:@"0%@",@(day)];
    }else{
        return @(day).stringValue;
    }
}

- (NSInteger)howManyDaysInThisMonth:(NSDate *)date
{
    if (!date) {
        return 0;
    }
    NSCalendar *calendarNew = [NSCalendar currentCalendar];
    NSDateComponents *componentsNew = [calendarNew components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekday fromDate:date];
    NSInteger year = componentsNew.year;
    NSInteger imonth = componentsNew.month;
    if((imonth == 1)||(imonth == 3)||(imonth == 5)||(imonth == 7)||(imonth == 8)||(imonth == 10)||(imonth == 12))
        return 31;
    if((imonth == 4)||(imonth == 6)||(imonth == 9)||(imonth == 11))
        return 30;
    if ([self bissextile:year]) {
        return 29;
    }else{
        return 28;
    }
}

- (BOOL)bissextile:(NSInteger)year
{
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
        return YES;
    }else {
        return NO;
    }
    return NO;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
