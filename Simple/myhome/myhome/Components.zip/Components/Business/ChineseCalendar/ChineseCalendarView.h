//
//  ChineseCalendarView.h
//  NL
//
//  Created by fudon on 16/8/4.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSBaseView.h"

@interface ChineseCalendarView : FSBaseView

@property (nonatomic,assign) NSInteger     thisYearDelta;
@property (nonatomic,strong) NSDate         *date;

@end
