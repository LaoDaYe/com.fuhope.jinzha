//
//  FSCCDayView.m
//  NL
//
//  Created by fudon on 16/8/4.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSCCDayView.h"
#import "FSLunarCalendar.h"
#import <FSKit.h>
#import <FSDate.h>

@implementation FSCCDayView
{
    UILabel     *_upLabel;
    UILabel     *_downLabel;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self dayViewDesignViews];
    }
    return self;
}

- (void)dayViewDesignViews
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [self addGestureRecognizer:tap];
    
    CGFloat height = self.bounds.size.width * 1.25;
    _upLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, height * .05, self.bounds.size.width, height * .7)];
    _upLabel.textAlignment = NSTextAlignmentCenter;
    _upLabel.adjustsFontSizeToFitWidth = YES;
    [self addSubview:_upLabel];
    
    _downLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, height * .7, self.bounds.size.width, height * .25)];
    _downLabel.textAlignment = NSTextAlignmentCenter;
    _downLabel.font = [UIFont systemFontOfSize:12];
    [self addSubview:_downLabel];
}

- (void)tapAction
{
    if (_block) {
        _block(self);
    }
}

- (void)setDate:(NSDate *)date
{
    if (!date) {
        return;
    }
    if (_date != date) {
        _date = date;
        
        NSDateComponents *components = [FSDate componentForDate:date];
        _upLabel.text = @(components.day).stringValue;
        
        
        FSLunarCalendar *lunar = [date chineseCalendarDate];
        if (lunar.SolarTermTitle.length) {
            _downLabel.text = lunar.SolarTermTitle;
        }else{
            _downLabel.text = lunar.DayLunar;
        }
        
        if ([self isToday:date]) {
            self.status = FSCCDayViewStatusToday;
        }else{
            self.status = FSCCDayViewStatusDefault;
        }
    }
}

- (void)setStatus:(FSCCDayViewStatus)status
{
    _status = status;
    
    if (status == FSCCDayViewStatusDefault) {
        self.backgroundColor = [UIColor clearColor];
        _upLabel.textColor = [UIColor blackColor];
        _downLabel.textColor = [UIColor blackColor];
    }else if (status == FSCCDayViewStatusSelected){
        self.backgroundColor = [UIColor orangeColor];
        _upLabel.textColor = [UIColor whiteColor];
        _downLabel.textColor = [UIColor whiteColor];
    }else if (status == FSCCDayViewStatusToday){
        self.backgroundColor = CCGreenColor;
        _upLabel.textColor = [UIColor whiteColor];
        _downLabel.textColor = [UIColor whiteColor];
    }
}

- (BOOL)isToday:(NSDate *)date
{
    NSDate *today = [NSDate date];
    NSDateComponents *componentT = [FSDate componentForDate:today];
    NSDateComponents *componentD = [FSDate componentForDate:date];
    return ((componentT.year == componentD.year) && (componentT.month == componentD.month) && (componentT.day == componentD.day));
}

- (void)setFont:(UIFont *)font
{
    if (_font != font) {
        _font = font;
        _upLabel.font = [UIFont fontWithName:_font.fontName size:25];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
