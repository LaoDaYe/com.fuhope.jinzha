//
//  ChineseCalendarView.m
//  NL
//
//  Created by fudon on 16/8/4.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "ChineseCalendarView.h"
#import "FSCCHeadView.h"
#import "FSCCMainView.h"
#import <FSDate.h>

@interface ChineseCalendarView ()

@property (nonatomic,strong) FSCCHeadView *headView;
@property (nonatomic,strong) FSCCMainView *mainView;

@end

@implementation ChineseCalendarView{
    UIScrollView    *_scrollView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self ccDesignViews];
    }
    return self;
}

- (void)ccDesignViews{
    self.backgroundColor = [UIColor whiteColor];
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    [self addSubview:_scrollView];
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.contentSize = CGSizeMake(self.bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    
    _headView = [[FSCCHeadView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 90)];
    _headView.date = [NSDate date];
    [_scrollView addSubview:_headView];
    
    _mainView = [[FSCCMainView alloc] initWithFrame:CGRectMake(0, 90, self.bounds.size.width, self.bounds.size.height - 110)];
    _mainView.firstDay = [NSDate date];
    [_scrollView addSubview:_mainView];
    __weak ChineseCalendarView *this = self;
    _mainView.block = ^ (FSCCDayView *bView){
        this.headView.date = bView.date;
    };
}

- (void)setDate:(NSDate *)date{
    if (_date != date) {
        _date = date;
        
        self.headView.date = date;
        self.mainView.firstDay = date;
    }
}

- (void)setThisYearDelta:(NSInteger)thisYearDelta{
    _thisYearDelta = thisYearDelta;
    
    NSDate *now = [NSDate date];
    NSDateComponents *components = [FSDate componentForDate:now];
    [components setMonth:([components month] + thisYearDelta)];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *newDate = [calendar dateFromComponents:components];
    self.headView.date = newDate;
    self.mainView.firstDay = newDate;
}
 
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
