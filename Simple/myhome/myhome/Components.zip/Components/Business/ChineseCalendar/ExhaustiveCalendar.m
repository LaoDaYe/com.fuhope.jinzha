//
//  ExhaustiveCalendar.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/8/7.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "ExhaustiveCalendar.h"
#import "FSLunarCalendar.h"
#import <FSKit.h>

@implementation ExhaustiveCalendar

+ (NSString *)lunarMonthWithDate:(NSDate *)date
{
    if (!date) {
        return @"";
    }
    NSDictionary *dic = @{@"1990":@[
                                  @[@19000106,@"丙子"],//不包含6(小寒)
                                  @[@19000204,@"丁丑"],//不包含4（立春）
                                  @[@19000306,@"戊寅"],//不包含6（惊蛰）
                                  @[@19000405,@"己卯"],//不包含5（清明）
                                  @[@19000506,@"庚辰"],//不包含6（立夏）
                                  @[@19000606,@"辛巳"],//不包含6（芒种）
                                  @[@19000707,@"壬午"],//不包含7（小暑）
                                  @[@19000808,@"癸未"],//不包含8（立秋）
                                  @[@19000908,@"甲申"],//不包含8（中秋）
                                  @[@19001009,@"乙酉"],//不包含9（寒露）
                                  @[@19001108,@"丙戌"],//不包含8（立冬）
                                  @[@19001207,@"丁亥"],//不包含7（大雪）
                                  ],
                          
                          @"1991":@[
                                  @[@19010106,@"戊子"],//不包含6（小寒）
                                  @[@19010204,@"己丑"],//不包含4（立春）
                                  @[@19010306,@"庚寅"],//不包含6（惊蛰）
                                  @[@19010405,@"辛卯"],//不包含5（清明）
                                  @[@19010506,@"壬辰"],//不包含6（立夏）
                                  @[@19010606,@"癸巳"],//不包含6（芒种）
                                  @[@19010708,@"甲午"],//不包含8（小暑）
                                  @[@19010808,@"乙未"],//不包含8（立秋）
                                  @[@19010908,@"丙申"],//不包含8（白露）
                                  @[@19011009,@"丁酉"],//不包含9（寒露）
                                  @[@19011108,@"戊戌"],//不包含8（立冬）
                                  @[@19011208,@"己亥"],//不包含8（大雪）
                                  ],
                          
                          @"2016":@[
                                  @[@20160106,@"戊子"],//不包含6（小寒）
                                  @[@20160204,@"己丑"],//不包含4（立春）
                                  @[@20160305,@"庚寅"],//不包含5（惊蛰）
                                  @[@20160404,@"辛卯"],//不包含4（清明）
                                  @[@20160505,@"壬辰"],//不包含5（立夏）
                                  @[@20160605,@"癸巳"],//不包含5（芒种）
                                  @[@20160707,@"甲午"],//不包含7（小暑）
                                  @[@20160807,@"乙未"],//不包含7（立秋）
                                  @[@20160907,@"丙申"],//不包含7（白露）
                                  @[@20161008,@"丁酉"],//不包含8（寒露）
                                  @[@20161107,@"戊戌"],//不包含7（立冬）
                                  @[@20161207,@"己亥"],//不包含7（大雪）
                                  @[@20161232,@"庚子"],//不包含32（大雪）
                                  ],
                          
                          };
    
    NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay  fromDate:date];
    NSInteger ymd = [[[NSString alloc] initWithFormat:@"%@%@%@",@(components.year),[FSKit twoChar:components.month],[FSKit twoChar:components.day]] integerValue];
    NSString *key = @(components.year).stringValue;
    NSArray *array = [dic objectForKey:key];
    if (!array) {
        FSLunarCalendar *lunar = [date chineseCalendarDate];
        return [[NSString alloc] initWithFormat:@"%@%@",lunar.MonthHeavenlyStem,lunar.MonthEarthlyBranch];
    }
    
    for (int x = 0; x < array.count; x ++) {
        NSArray *subArray = [array objectAtIndex:x];
        NSInteger value = [subArray[0] integerValue];
        if (ymd < value) {
            return subArray[1];
        }
    }
    FSLunarCalendar *lunar = [date chineseCalendarDate];
    return [[NSString alloc] initWithFormat:@"%@%@",lunar.MonthHeavenlyStem,lunar.MonthEarthlyBranch];
}

@end
