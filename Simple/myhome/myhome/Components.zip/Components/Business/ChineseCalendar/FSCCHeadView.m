//
//  FSCCHeadView.m
//  NL
//
//  Created by fudon on 16/8/4.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSCCHeadView.h"
#import "FSLunarCalendar.h"
#import "ExhaustiveCalendar.h"

@interface FSCCHeadView ()

@property (nonatomic,strong) UILabel    *solarLabel;

@end

@implementation FSCCHeadView

- (void)setDate:(NSDate *)date
{
    if (!date) {
        return;
    }
    if (_date != date) {
        _date = date;
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy年MM月dd日"];
        NSString *currentDateStr = [formatter stringFromDate:date];
        if (!currentDateStr) {
            currentDateStr = @"";
        }
        
        NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekOfYear | NSCalendarUnitWeekday | NSCalendarUnitWeekOfMonth | NSCalendarUnitWeekOfYear fromDate:date];
        
        FSLunarCalendar *lunar = [date chineseCalendarDate];
        NSArray *titles = @[[[NSString alloc] initWithFormat:@"公历：%@ %@",currentDateStr,[self weekStringForWeekday:components.weekday]],
                            [[NSString alloc] initWithFormat:@"国历：%@年 %@%@",lunar.ZodiacLunar,lunar.MonthLunar,lunar.DayLunar],
                            [[NSString alloc] initWithFormat:@"干支：%@%@年 %@月 %@%@日",lunar.YearHeavenlyStem,lunar.YearEarthlyBranch,[ExhaustiveCalendar lunarMonthWithDate:date],lunar.DayHeavenlyStem,lunar.DayEarthlyBranch]
                            ];
        for (int x = 0; x < 3; x ++) {
            UILabel *label = [self viewWithTag:100 + x];
            label.text = titles[x];
        }
        
        if (!_solarLabel) {
            _solarLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.bounds.size.width - 100, self.bounds.size.height / 2 - 25, 80, 50)];
            _solarLabel.textColor = [UIColor colorWithRed:100 / 255.0 green:170 / 255.0 blue:70 / 255.0 alpha:1];
            _solarLabel.textAlignment = NSTextAlignmentRight;
            [self addSubview:_solarLabel];
        }
        _solarLabel.text = lunar.SolarTermTitle;
    }
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        for (int x = 0; x < 3; x ++) {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 4.5 + 27 * x, self.bounds.size.width - 90, 27)];
            [self addSubview:label];
            label.tag = 100 + x;
            label.font = [UIFont systemFontOfSize:15];
        }
    }
    return self;
}

- (NSString *)weekStringForWeekday:(NSInteger)weekDay
{
    NSArray *array = @[@"日",@"一",@"二",@"三",@"四",@"五",@"六"];
    return [[NSString alloc] initWithFormat:@"星期%@",array[(weekDay - 1) % array.count]];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
