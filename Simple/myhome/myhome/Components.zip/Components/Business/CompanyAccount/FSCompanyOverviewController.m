//
//  FSCompanyOverviewController.m
//  Expand
//
//  Created by Fudongdong on 2017/12/20.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSCompanyOverviewController.h"
#import "FSDBCompanyAddController.h"
#import "FSCompanySupport.h"
#import "FSCompanyListController.h"
#import "FSCompanySubjectValueController.h"
#import "FSAssetDebtModel.h"
#import "FSCompanyPublic.h"
#import "FSAPP.h"
#import <FSRuntime.h>
#import "FSMacro.h"

@interface FSCompanyOverviewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSCompanyOverviewController{
    UITableView             *_tableView;
    NSArray                 *_values;
    NSArray                 *_subjects;
    UIView                  *_headView;
    FSAssetDebtModel        *_adEntity;
    FSIncomeStatementModel  *_isEntity;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self companyOverviewHandleDatas];
}

- (void)companyOverviewHandleDatas{
    Tuple2 *t = [FSCompanySupport assetDebtModel:self.accountName];
    _adEntity = t._1;
    _isEntity = t._2;
    _subjects = @[[Tuple2 v1:@(FSCompanyAccountTypeSR) v2:@"今年收入"],
                  [Tuple2 v1:@(FSCompanyAccountTypeCB) v2:@"今年成本"],
                  [Tuple2 v1:@(FSCompanyAccountTypeLZ) v2:@"流动资产"],
                  [Tuple2 v1:@(FSCompanyAccountTypeNZ) v2:@"非流动资产"],
                  [Tuple2 v1:@(FSCompanyAccountTypeLD) v2:@"流动负债"],
                  [Tuple2 v1:@(FSCompanyAccountTypeND) v2:@"非流动负债"],
                  [Tuple2 v1:@(FSCompanyAccountTypeQY) v2:@"所有者权益"],
                  ];
    [self companyOverviewDesignViews];
}

- (void)companyOverviewDesignViews{
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemBookmarks target:self action:@selector(bbiClick)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64 - 44) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = 45;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.tableHeaderView = [self headerView];
    _tableView.tableFooterView = [UIView new];
    _tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_tableView];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(0, HEIGHTFC - 44, WIDTHFC, 44);
    [button setTitle:@"记一笔" forState:UIControlStateNormal];
    button.backgroundColor = FSAPPCOLOR;
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(addClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    [self refreshHeader];
}

- (UIView *)headerView{
    if (!_headView) {
        CGFloat uh = 30;
        CGFloat margin = 10;
        NSArray *titles = @[@"总资产",@"负债",@"净资产",@"利润",@"资债率",@"净利率",@"最新"];
        NSInteger count = titles.count;
        _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, count * uh + 2 * margin)];
        _headView.backgroundColor = FS_GreenColor;
        for (int x = 0; x < count; x ++) {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 10 + x * uh, 100, uh)];
            label.text = titles[x];
            label.textColor = [UIColor whiteColor];
            [_headView addSubview:label];
            
            UILabel *content = [[UILabel alloc] initWithFrame:CGRectMake(15, label.top, WIDTHFC - 30, uh)];
            content.textColor = [UIColor whiteColor];
            content.tag = x + TAG_LABEL;
            content.textAlignment = NSTextAlignmentRight;
            [_headView addSubview:content];
            if (x == (count - 1)) {
                NSString *text = [FSAPP messageForTable:self.accountName];
                content.text = text?:@"暂无";
                content.lineBreakMode = NSLineBreakByTruncatingMiddle;
            }
        }
    }
    return _headView;
}

- (void)refreshHeader{
    // 1.流动资产
    NSArray *aas = [FSCompanyPublic currentAssets];
    CGFloat aa = [self sumSubjects:aas fromObjc:_adEntity];
    NSString *flowAssets = [[NSString alloc] initWithFormat:@"%.2f",aa];
    _adEntity.aa = flowAssets;
    
    // 2.非流动资产
    NSArray *abs = [FSCompanyPublic nonCurrentAssets];
    CGFloat ab = [self sumSubjects:abs fromObjc:_adEntity];
    NSString *absString = [[NSString alloc] initWithFormat:@"%.2f",ab];
    _adEntity.bb = absString;
    
    // 资产总计
    CGFloat zc = ab + aa;
    NSString *acStr = [[NSString alloc] initWithFormat:@"%.2f",zc];
    _adEntity.zc = acStr;
    
    // 3.流动负债
    NSArray *currentLiabilities = [FSCompanyPublic currentLiabilities];
    CGFloat cl = [self sumSubjects:currentLiabilities fromObjc:_adEntity];
    NSString *clStr = [[NSString alloc] initWithFormat:@"%.2f",cl];
    _adEntity.cc = clStr;
    
    // 4.非流动负债
    NSArray *nonCurrentLiabilities = [FSCompanyPublic nonCurrentLiabilities];
    CGFloat ncl = [self sumSubjects:nonCurrentLiabilities fromObjc:_adEntity];
    NSString *nclStr = [[NSString alloc] initWithFormat:@"%.2f",ncl];
    _adEntity.dd = nclStr;

    // 负债合计
    CGFloat fz = cl + ncl;
    NSString *fzStr = [[NSString alloc] initWithFormat:@"%.2f",fz];
    _adEntity.fz = fzStr;
    
    // 5.所有者权益
    NSArray *ownersEquity = [FSCompanyPublic ownersEquity];
    CGFloat oe = [self sumSubjects:ownersEquity fromObjc:_adEntity];
    NSString *oeStr = [[NSString alloc] initWithFormat:@"%.2f",oe];
    _adEntity.oo = oeStr;
    
    // 6.收入项
    NSArray *revenues = [FSCompanyPublic revenues];
    CGFloat re = [self sumSubjects:revenues fromObjc:_isEntity];
    NSString *reStr = [[NSString alloc] initWithFormat:@"%.2f",re];
    _isEntity.sr = reStr;
    
    // 7.成本项
    NSArray *costs = [FSCompanyPublic costs];
    CGFloat cs = [self sumSubjects:costs fromObjc:_isEntity];
    NSString *csStr = [[NSString alloc] initWithFormat:@"%.2f",cs];
    _isEntity.cb = csStr;
    
    _values = @[reStr,csStr,flowAssets,absString,clStr,nclStr,oeStr];
    [_tableView reloadData];
    
    CGFloat jlr = re - cs;
    NSString *jzc = [[NSString alloc] initWithFormat:@"%.2f",zc - fz];
    NSString *lr = [[NSString alloc] initWithFormat:@"%.2f",jlr];
    NSString *zzl = [[NSString alloc] initWithFormat:@"%.2f%%",100 * fz / MAX(zc, 0.01)];
    NSString *jll = [[NSString alloc] initWithFormat:@"%.2f%%",100 * jlr / MAX(re, 0.01)];

    NSArray *results = @[acStr,fzStr,jzc,lr,zzl,jll];
    for (int x = 0; x < results.count; x ++) {
        UILabel *label = [_headView viewWithTag:TAG_LABEL + x];
        label.text = results[x];
    }
}

- (CGFloat)sumSubjects:(NSArray *)subjects fromObjc:(id)object{
    CGFloat sum = 0;
    for (Tuple2 *t in subjects) {
        NSString *value = [FSRuntime valueForGetSelectorWithPropertyName:t._1 object:object];
        sum += [value doubleValue];
    }
    return sum;
}

- (void)addClick{
    FSDBCompanyAddController *add = [[FSDBCompanyAddController alloc] init];
    add.accountName = self.accountName;
    [self.navigationController pushViewController:add animated:YES];
}

- (void)bbiClick{
    FSCompanyListController *listController = [[FSCompanyListController alloc] init];
    listController.accountName = self.accountName;
    [self.navigationController pushViewController:listController animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _subjects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    Tuple2 *t = _subjects[indexPath.row];
    cell.textLabel.text = t._2;
    cell.detailTextLabel.text = _values[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSArray *array = [FSCompanySupport subjectsAtIndex:indexPath.row];
    FSCompanySubjectValueController *csv = [[FSCompanySubjectValueController alloc] init];
    Tuple2 *t = _subjects[indexPath.row];
    csv.title = t._2;
    csv.adEntity = _adEntity;
    csv.isEntity = _isEntity;
    csv.type = [t._1 integerValue];
    csv.subjects = array;
    [self.navigationController pushViewController:csv animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
