//
//  FSDBCompanyAddController.m
//  Expand
//
//  Created by Fudongdong on 2017/12/20.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSDBCompanyAddController.h"
#import "FSCompanyPublic.h"
#import "FSCompanyAddDataController.h"
#import "FSDBJeView.h"
#import "FSCompanySupport.h"
#import "FSAccountRecordController.h"
#import "FSHalfView.h"
#import <FSUIKit.h>
#import "FSMacro.h"
#import "UIViewExt.h"

@interface FSDBCompanyAddController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) FSDBJeView     *jeView;
@property (nonatomic,strong) Tuple3         *aSubject;
@property (nonatomic,strong) Tuple3         *bSubject;
@property (nonatomic,strong) NSDate         *date;
@property (nonatomic,strong) FSHalfView     *halfView;
@property (nonatomic,strong) NSArray        *list;
@property (nonatomic,strong) UILabel        *label;

@end

@implementation FSDBCompanyAddController{
    NSArray         *_subjects;
    UITableView     *_tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"科目";
    _subjects = @[@"收入",@"成本",@"流动资产",@"非流动资产",@"流动负债",@"非流动负债",@"所有者权益"];
    [self companyAddDesignViews];
}

- (void)bjClick:(UIBarButtonItem *)bbi{
    [self.view endEditing:YES];
    WEAKSELF(this);
    __weak UIBarButtonItem *weakBBI = bbi;
    FSAccountRecordController *saveViewController = [[FSAccountRecordController alloc] init];
    [this.navigationController pushViewController:saveViewController animated:YES];
    saveViewController.block = ^(FSBaseController *bVC, NSDate *date) {
        this.date = date;
        weakBBI.title = [[FSKit ymdhsByTimeInterval:[date timeIntervalSince1970]] substringToIndex:10];
        [bVC.navigationController popViewControllerAnimated:YES];
    };
}

- (UILabel *)label{
    if (!_label) {
        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, 24, WIDTHFC, 40)];
        _label.backgroundColor = FS_GreenColor;
        _label.font = [UIFont systemFontOfSize:14];
        _label.textColor = [UIColor whiteColor];
        _label.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:_label];
        
        [UIView animateWithDuration:.3 animations:^{
            self->_label.top = 64;
            self->_tableView.top = 104;
        } completion:^(BOOL finished) {
            self->_tableView.height = HEIGHTFC - 104;
        }];
    }
    return _label;
}

- (void)companyAddDesignViews{
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:@"日期" style:UIBarButtonItemStylePlain target:self action:@selector(bjClick:)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    _jeView = [[FSDBJeView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, 100)];
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = 45;
    _tableView.tableHeaderView = _jeView;
    _tableView.tableFooterView = [UIView new];
    _tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_tableView];
    
    [_jeView.jeTF becomeFirstResponder];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _subjects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.textLabel.text = _subjects[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *je = self.jeView.jeTF.textField.text;
    if (!_fs_isPureFloat(je)) {
        [FSToast show:@"请输入正确的金额"];
        [self.jeView.jeTF becomeFirstResponder];
        return;
    }
    CGFloat cash = [je doubleValue];
    if (cash < 0.01) {
        [FSToast show:@"金额不能小于1分"];
        [self.jeView.jeTF becomeFirstResponder];
        return;
    }
    NSString *bz = [FSKit stringDeleteNewLineAndWhiteSpace:self.jeView.bzTF.textField.text];
    if (!_fs_isValidateString(bz)) {
        [FSToast show:@"请输入正确的备注"];
        [self.jeView.bzTF becomeFirstResponder];
        return;
    }
    [self showHalfView:indexPath.row];
//    [self pushToDetailSubject:indexPath.row];
}

- (void)showHalfView:(NSInteger)index{
    [self.view endEditing:YES];
    self.list = [FSCompanySupport subjectsAtIndex:index];
    if (!self.halfView) {
        WEAKSELF(this);
        self.halfView = [[FSHalfView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64)];
        self.halfView.dataSource = self.list;
        [self.view addSubview:self.halfView];
        [_halfView setConfigCell:^(UITableView *bTB, NSIndexPath *bIP,UITableViewCell *bCell) {
            Tuple2 *t = [this.list objectAtIndex:bIP.row];
            bCell.textLabel.text = t._2;
        }];
        [_halfView setSelectCell:^(UITableView *bTB, NSIndexPath *bIP) {
            static NSString *add = @"增加";
            static NSString *minus = @"减少";
            NSNumber *type = @(UIAlertActionStyleDefault);
            [FSUIKit alert:UIAlertControllerStyleActionSheet controller:this title:nil message:nil actionTitles:@[add,minus] styles:@[type,type] handler:^(UIAlertAction *action) {
                Tuple2 *t = [this.list objectAtIndex:bIP.row];
                BOOL isAdd = [action.title isEqualToString:add];
                if (this.aSubject) {
                    this.bSubject = [Tuple3 v1:t._1 v2:t._2 v3:@(isAdd)];
                }else{
                    this.aSubject = [Tuple3 v1:t._1 v2:t._2 v3:@(isAdd)];
                    this.label.text = @"还需选择一个科目";
                }
                if (this.aSubject && this.bSubject) {
                    [this handleAddAData];
                }
            }];
        }];
    }else{
        self.halfView.dataSource = self.list;
        [self.halfView showHalfView:YES];
        [self.view bringSubviewToFront:self.halfView];
    }
}

- (void)handleAddAData{
    NSArray *subjects = @[self.aSubject,self.bSubject];
    NSString *message = [FSCompanySupport messageForSubjects:subjects];
    self.label.text = message;
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:message message:nil actionTitles:@[@"确定"] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        NSDate *date = [self.date isKindOfClass:NSDate.class]?self.date:[NSDate date];
        [FSCompanySupport handleDatas:subjects account:self.accountName date:date je:self.jeView.jeTF.textField.text bz:self.jeView.bzTF.textField.text controller:self completion:^{
            [FSKit popToController:@"FSCompanyOverviewController" navigationController:self.navigationController animated:YES];
        }];
    } cancelTitle:@"取消" cancel:^(UIAlertAction *action) {
        self.aSubject = nil;
        self.bSubject = nil;
        self.label.text = @"重新选择2个科目";
    } completion:nil];
}

// 跳转使用
- (void)pushToDetailSubject:(NSInteger)index{
    NSArray *array = [FSCompanySupport subjectsAtIndex:index];
    FSCompanyAddDataController *companyAddData = [[FSCompanyAddDataController alloc] init];
    companyAddData.accountName = self.accountName;
    companyAddData.subjects = array;
    [self.navigationController pushViewController:companyAddData animated:YES];
    __weak typeof(self)this = self;
    companyAddData.selectType = ^(FSCompanyAddDataController *c, Tuple2 *t, BOOL isAdd) {
        [c.navigationController popViewControllerAnimated:YES];
        if (this.aSubject) {
            this.bSubject = [Tuple3 v1:t._1 v2:t._2 v3:@(isAdd)];
        }else{
            this.aSubject = [Tuple3 v1:t._1 v2:t._2 v3:@(isAdd)];
        }
        if (this.aSubject && this.bSubject) {
            [this handleAddAData];
        }
    };
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (decelerate) {
        [self.view endEditing:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
