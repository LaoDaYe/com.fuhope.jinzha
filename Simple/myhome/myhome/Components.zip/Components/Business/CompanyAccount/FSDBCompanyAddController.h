//
//  FSDBCompanyAddController.h
//  Expand
//
//  Created by Fudongdong on 2017/12/20.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSBaseController.h"

@interface FSDBCompanyAddController : FSBaseController

@property (nonatomic,copy) NSString     *accountName;

@end
