//
//  FSCompanyAddDataController.m
//  Expand
//
//  Created by Fudongdong on 2017/12/20.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSCompanyAddDataController.h"
#import <FuSoft.h>
#import <FSKit.h>
#import "FSCompanyPublic.h"
#import "FSDBMaster.h"
#import <FSUIKit.h>

@interface FSCompanyAddDataController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSCompanyAddDataController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self companyAddDataDesignViews];
}

- (void)companyAddDataDesignViews{
    self.title = @"记一笔";
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = 50;
    tableView.tableFooterView = [UIView new];
    tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _subjects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    Tuple2 *t = [_subjects objectAtIndex:indexPath.row];
    cell.textLabel.text = t._2;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *add = @"增加";
    NSString *minus = @"减少";
    NSNumber *type = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[add,minus] styles:@[type,type] handler:^(UIAlertAction *action) {
        Tuple2 *t = [self->_subjects objectAtIndex:indexPath.row];
        BOOL isAdd = [action.title isEqualToString:add];
        if (self.selectType) {
            self.selectType(self, t, isAdd);
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
