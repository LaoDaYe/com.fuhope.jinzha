//
//  FSAssetDebtModel.m
//  myhome
//
//  Created by FudonFuchina on 2017/12/20.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSAssetDebtModel.h"
#import "FSKitDuty.h"

@implementation FSAssetDebtModel

- (instancetype)init{
    self = [super init];
    if (self) {
        [FSKitDuty letModelEveryPropertyDefaultValue:@"0.00" object:self];
    }
    return self;
}

@end
