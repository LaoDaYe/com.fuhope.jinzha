//
//  FSIncomeStatementModel.m
//  Expand
//
//  Created by Fuhope on 2017/12/20.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSIncomeStatementModel.h"
#import "FSKitDuty.h"

@implementation FSIncomeStatementModel

- (instancetype)init{
    self = [super init];
    if (self) {
        [FSKitDuty letModelEveryPropertyDefaultValue:@"0.00" object:self];
    }
    return self;
}

@end
