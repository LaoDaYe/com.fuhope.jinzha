//
//  FSCompanySubjectValueController.m
//  myhome
//
//  Created by Fudongdong on 2017/12/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSCompanySubjectValueController.h"
#import <FSTuple.h>
#import <FSRuntime.h>
#import "FSMacro.h"

@interface FSCompanySubjectValueController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSCompanySubjectValueController{
    UITableView     *_tableView;
    NSArray         *_dataSource;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self subjectValueHandleDatas];
}

- (void)subjectValueHandleDatas{
    id object = nil;
    if (self.type == FSCompanyAccountTypeSR || self.type == FSCompanyAccountTypeCB) {
        object = _isEntity;
    }else{
        object = _adEntity;
    }
    NSMutableArray *vs = [[NSMutableArray alloc] initWithCapacity:self.subjects.count];
    for (Tuple2 *t in self.subjects) {
        NSString *value = [FSRuntime valueForGetSelectorWithPropertyName:t._1 object:object];
        NSString *need = [[NSString alloc] initWithFormat:@"%.2f",[value doubleValue]];
        Tuple2 *nt = [Tuple2 v1:t._2 v2:need];
        [vs addObject:nt];
    }
    _dataSource = [vs copy];
    [self subjectValueDesignViews];
}

- (void)subjectValueDesignViews{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 45;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.textLabel.font = [UIFont systemFontOfSize:13];
        cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:13];
        cell.detailTextLabel.textColor = FS_GreenColor;
    }
    Tuple2 *t = _dataSource[indexPath.row];
    cell.textLabel.text = t._1;
    cell.detailTextLabel.text = t._2;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//    NSArray *array = [FSCompanySupport subjectsAtIndex:indexPath.row];
//    FSCompanySubjectValueController *csv = [[FSCompanySubjectValueController alloc] init];
//    csv.subjects = array;
//    [self.navigationController pushViewController:csv animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
