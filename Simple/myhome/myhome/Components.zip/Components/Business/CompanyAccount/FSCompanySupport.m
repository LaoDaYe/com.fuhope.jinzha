//
//  FSCompanySupport.m
//  myhome
//
//  Created by FudonFuchina on 2017/12/20.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSCompanySupport.h"
#import "FSDBMaster.h"
#import "FSKit.h"
#import "FSCompanyPublic.h"
#import "FSABModel.h"
#import "FSTuple.h"
#import "FSABTrackModel.h"
#import "FSABTwominusController.h"
#import "FSABOneminusController.h"
#import "FSDBTool.h"
#import "FSAPP.h"
#import "FSAccountConfiger.h"
#import "FSRuntime.h"
#import "FSUIKit.h"
#import "FSTrack.h"
#import "FSTrackKeys.h"

@implementation FSCompanySupport

+ (Tuple2 *)assetDebtModel:(NSString *)account{
    if (!_fs_isValidateString(account)) {
        return nil;
    }
    FSAssetDebtModel *entity = [[FSAssetDebtModel alloc] init];
    FSIncomeStatementModel *isEntity = [[FSIncomeStatementModel alloc] init];
    
    FSDBMaster *master = [FSDBMaster sharedInstance];
    CGFloat debtor = 0;
    CGFloat creditor = 0;
    
    NSInteger page = 0;
    NSInteger unit = 500;
    NSString *sql = [self fastSql:unit page:page tableName:account];
    NSArray *list = [master querySQL:sql tableName:account];
    while ([list isKindOfClass:NSArray.class] && list.count) {
        for (NSDictionary *model in list) {
            CGFloat je = [model[@"je"] doubleValue];
            NSString *atype = model[@"atype"];
            NSString *btype = model[@"btype"];
            [self handleModel:entity type:atype je:je];
            [self handleModel:entity type:btype je:je];
            [self handleModel:isEntity type:atype je:je];
            [self handleModel:isEntity type:btype je:je];
            
            NSString *aSubject = [atype substringToIndex:2];
            NSString *bSubject = [btype substringToIndex:2];
            BOOL isACOfA = [FSCompanyPublic isAssetOrCostSubject:aSubject];
            BOOL isACOfB = [FSCompanyPublic isAssetOrCostSubject:bSubject];
            BOOL isPlusA = [atype hasSuffix:_ING_KEY];
            BOOL isPlusB = [btype hasSuffix:_ING_KEY];
            if (isACOfA) {
                if (isPlusA) {
                    debtor += je;
                }else{
                    creditor += je;
                }
            }else{
                if (isPlusA) {
                    creditor += je;
                }else{
                    debtor += je;
                }
            }
            
            if (isACOfB) {
                if (isPlusB) {
                    debtor += je;
                }else{
                    creditor += je;
                }
            }else{
                if (isPlusB) {
                    creditor += je;
                }else{
                    debtor += je;
                }
            }
        }
        page ++;
        sql = [self fastSql:unit page:page tableName:account];
        list = [master querySQL:sql tableName:account];
    }
    entity.ph = [[NSString alloc] initWithFormat:@"%.2f",debtor - creditor];
    return [Tuple2 v1:entity v2:isEntity];
}

+ (void)handleModel:(id)entity type:(NSString *)p je:(CGFloat)je{
    BOOL isPlus = [p hasSuffix:_ING_KEY];
    NSString *type = [p substringToIndex:2];
    SEL setterSelector = [FSRuntime setterSELWithAttibuteName:type];
    if ([entity respondsToSelector:setterSelector]) {
        CGFloat value = [[FSRuntime valueForGetSelectorWithPropertyName:type object:entity] doubleValue];
        if (isPlus) {
            value += je;
        }else{
            value = value - je;
        }
        [entity performSelector:setterSelector onThread:[NSThread currentThread] withObject:[[NSString alloc] initWithFormat:@"%.6f",value] waitUntilDone:YES];
    }
}

+ (NSString *)fastSql:(NSInteger)unit page:(NSInteger)page tableName:(NSString *)tableName{
    return [[NSString alloc] initWithFormat:@"SELECT * FROM %@ limit %@,%@;",tableName,@(page * unit),@(unit)];
}

+ (NSArray<Tuple2 *> *)subjectsAtIndex:(NSInteger)index{
    NSArray *array = nil;
    switch (index) {
        case 2:{
            array = [FSCompanyPublic currentAssets];
        }break;
        case 3:{
            array = [FSCompanyPublic nonCurrentAssets];
        }break;
        case 4:{
            array = [FSCompanyPublic currentLiabilities];
        }break;
        case 5:{
            array = [FSCompanyPublic nonCurrentLiabilities];
        }break;
        case 6:{
            array = [FSCompanyPublic ownersEquity];
        }break;
        case 0:{
            array = [FSCompanyPublic revenues];
        }break;
        case 1:{
            array = [FSCompanyPublic costs];
        }break;
        default:
            break;
    }
    return array;
}

+ (NSString *)messageForSubjects:(NSArray<Tuple3 *> *)subjects{
    Tuple3 *t1 = subjects.firstObject;
    Tuple3 *t2 = subjects.lastObject;
    BOOL aFX = [t1._3 boolValue];
    BOOL bFX = [t2._3 boolValue];
    NSString *p = @"增加";
    NSString *m = @"减少";
    NSString *message = [[NSString alloc] initWithFormat:@"%@ %@,%@ %@",t1._2,aFX?p:m,t2._2,bFX?p:m];
    return message;
}

/*
    同类：资产和成本
    同类：负债、权益、收入
 */
+ (BOOL)checkSubjectsBalance:(NSString *)atype aFX:(BOOL)aFX b:(NSString *)btype bFX:(BOOL)bFX{
    BOOL isAssetOrCostSubjectA = [FSCompanyPublic isAssetOrCostSubject:atype];
    BOOL isAssetOrCostSubjectB = [FSCompanyPublic isAssetOrCostSubject:btype];
    if (isAssetOrCostSubjectA) {
        if (isAssetOrCostSubjectB) {
            return aFX != bFX;
        }else{
            return aFX == bFX;
        }
    }else{
        if (isAssetOrCostSubjectB) {
            return aFX == bFX;
        }else{
            return aFX != bFX;
        }
    }
    return YES;
}

+ (Tuple2 *)returnErrorStringIfOccurrError:(Tuple3 *)aSubject b:(Tuple3 *)bSubject{
    if (aSubject == nil || bSubject == nil) {
        return nil;
    }
    NSString *atype = aSubject._1;
    NSString *btype = bSubject._1;
    if ([atype isEqualToString:btype]) {
        return [Tuple2 v1:@(NO) v2:NSLocalizedString(@"It has to be two different subjects", nil)];
    }
    BOOL aIsAdd = [aSubject._3 boolValue];
    BOOL bIsAdd = [bSubject._3 boolValue];
    BOOL balance = [self checkSubjectsBalance:atype aFX:aIsAdd b:btype bFX:bIsAdd];
    NSString *show = [self messageForSubjects:@[aSubject,bSubject]];
    NSMutableString *message = [[NSMutableString alloc] initWithString:show];
    if (!balance) {
        [message insertString:@"[" atIndex:0];
        [message appendFormat:@"] %@",NSLocalizedString(@"Can't execute", nil)];
    }else{
        [message appendString:@"?"];
    }
    return [Tuple2 v1:@(balance) v2:message];
}

+ (void)handleDatas:(NSArray<Tuple3 *> *)handleArray account:(NSString *)account date:(NSDate *)date je:(NSString *)je bz:(NSString *)bz controller:(UIViewController *)controller completion:(void(^)(void))completion{
    if (handleArray.count != 2) {
        return;
    }
    Tuple3 *aSubject = handleArray.firstObject;
    Tuple3 *bSubject = handleArray.lastObject;
    Tuple2 *t2 = [self returnErrorStringIfOccurrError:aSubject b:bSubject];
    if (![t2._1 boolValue]) {
        [FSUIKit showAlertWithMessage:t2._2 controller:controller];
        return;
    }
    if (!_fs_isValidateString(account)) {
        return;
    }
    if (!_fs_isPureFloat(je)) {
        return;
    }
    if (!_fs_isValidateString(bz)) {
        return;
    }
    if (![date isKindOfClass:NSDate.class]) {
        return;
    }
    NSString *atype = aSubject._1;
    NSString *btype = bSubject._1;
    BOOL aIsAdd = [aSubject._3 boolValue];
    BOOL bIsAdd = [bSubject._3 boolValue];
    NSString *message = [self messageForSubjects:handleArray];
    BOOL onlyAdds = aIsAdd && bIsAdd;
    if (onlyAdds) {
        NSInteger time = (NSInteger)[date timeIntervalSince1970];
        [self addEntities:time account:account handleArray:handleArray je:je bz:bz controller:controller completion:completion];
    }else{
        NSString *firstMinus = nil;
        NSString *secondMinus = nil;
        if (!aIsAdd) {
            firstMinus = atype;
        }
        if (!bIsAdd) {
            if (firstMinus) {
                secondMinus = btype;
            }else{
                firstMinus = btype;
            }
        }
        
        if (firstMinus && secondMinus) {    // 两项都是减
            FSABTwominusController *twoMinusController = [[FSABTwominusController alloc] init];
            twoMinusController.types = @[firstMinus,secondMinus];
            twoMinusController.accountName = account;
            twoMinusController.je = je;
            twoMinusController.bz = bz;
            twoMinusController.isCompany = YES;
            [controller.navigationController pushViewController:twoMinusController animated:YES];
            twoMinusController.completion = ^ (FSABTwominusController *bController,NSArray *bEdArray,NSArray *bTracks){
                [self updateEntities:bEdArray tracks:bTracks date:date account:account handleArray:handleArray je:je bz:bz controller:controller completion:completion];
            };
        }else{      // 一项是减
            FSABOneminusController *selectController = [[FSABOneminusController alloc] init];
            selectController.type = firstMinus;
            selectController.accountName = account;
            selectController.je = je;
            selectController.bz = bz;
            selectController.isCompany = YES;
            selectController.message = message;
            [controller.navigationController pushViewController:selectController animated:YES];
            selectController.selectBlock = ^ (FSABOneminusController *bController,NSArray<FSABModel *> *bEdArray,NSArray *bTracks){
                [self updateEntities:bEdArray tracks:bTracks date:date account:account handleArray:handleArray je:je bz:bz controller:controller completion:completion];
            };
        }
    }
}

+ (void)updateEntities:(NSArray *)array tracks:(NSArray *)tracks date:(NSDate *)date account:(NSString *)account handleArray:(NSArray<Tuple3 *> *)handleArray je:(NSString *)je bz:(NSString *)bz controller:(UIViewController *)controller completion:(void(^)(void))completion{
    if (handleArray.count != 2) {
        return;
    }
    Tuple3 *aSubject = handleArray.firstObject;
    Tuple3 *bSubject = handleArray.lastObject;
    Tuple2 *t2 = [self returnErrorStringIfOccurrError:aSubject b:bSubject];
    if (![t2._1 boolValue]) {
        [FSUIKit showAlertWithMessage:t2._2 controller:controller];
        return;
    }
    if (!_fs_isValidateString(account)) {
        return;
    }
    if (!_fs_isPureFloat(je)) {
        return;
    }
    if (!_fs_isValidateString(bz)) {
        return;
    }
    if ((!_fs_isValidateArray(array)) || (!_fs_isValidateArray(tracks))) {
        array = nil;
        tracks = nil;
    }
    
    NSString *error = [self handleEDArray:array account:account];
    if (error) {
        [FSUIKit showAlertWithMessage:error controller:controller];
        return;
    }
    NSString *trackError = [self handleTracks:tracks];
    if (trackError) {
        [FSUIKit showAlertWithMessage:trackError controller:controller];
        return;
    }
    
    NSInteger time = (NSInteger)[date timeIntervalSince1970];
    [self addEntities:time account:account handleArray:handleArray je:je bz:bz controller:controller completion:completion];
}

+ (NSString *)handleEDArray:(NSArray<FSABModel *> *)array account:(NSString *)account{
    if (![array isKindOfClass:NSArray.class]) {
        return nil;
    }
    FSDBMaster *master = [FSDBMaster sharedInstance];
    for (int x = 0; x < array.count; x ++) {
        FSABModel *model = array[x];
        NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET arest = '%@',brest = '%@' WHERE aid = %@;",account,model.arest,model.brest,model.aid];
        NSString *error = [master updateSQL:sql];
        if (error) {
            return error;
        }
    }
    return nil;
}

+ (NSString *)handleTracks:(NSArray<FSABTrackModel *> *)tracks{
    if (![tracks isKindOfClass:NSArray.class]) {
        return nil;
    }
    FSDBMaster *master = [FSDBMaster sharedInstance];
    for (int x = 0; x < tracks.count; x ++) {
        FSABTrackModel *model = [tracks objectAtIndex:x];
        NSString *error = [master insert_fields_values:@{
                                                         @"time":model.time,
                                                         @"link":model.link,
                                                         @"type":model.type,
                                                         @"je":model.je,
                                                         @"bz":model.bz,
                                                         @"accname":model.accname
                                                         } table:_tb_abTrack];
        if (error) {
            return error;
        }
    }
    return nil;
}

+ (void)addEntities:(NSTimeInterval)time account:(NSString *)account handleArray:(NSArray<Tuple3 *> *)handleArray je:(NSString *)je bz:(NSString *)bz controller:(UIViewController *)controller completion:(void(^)(void))completion{
    if (!_fs_isValidateString(account)) {
        return;
    }
    if (handleArray.count != 2) {
        return;
    }
    Tuple3 *aSubject = handleArray.firstObject;
    Tuple3 *bSubject = handleArray.lastObject;
    Tuple2 *t2 = [self returnErrorStringIfOccurrError:aSubject b:bSubject];
    if (![t2._1 boolValue]) {
        [FSUIKit showAlertWithMessage:t2._2 controller:controller];
        return;
    }
    NSString *atype = aSubject._1;
    NSString *btype = bSubject._1;
    BOOL aIsAdd = [aSubject._3 boolValue];
    BOOL bIsAdd = [bSubject._3 boolValue];
    if (!_fs_isValidateString(atype)) {
        return;
    }
    if (!_fs_isValidateString(btype)) {
        return;
    }
    if (!_fs_isPureFloat(je)) {
        return;
    }
    if (!_fs_isValidateString(bz)) {
        return;
    }
    
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *existSQL = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE time = '%@';",account,@(time).stringValue];
    NSArray *bArray = [master querySQL:existSQL tableName:account];
    if (bArray.count) {
        [self addEntities:time + 1 account:account handleArray:handleArray je:je bz:bz controller:controller completion:completion];
        return;
    }
    NSString *typeA = [[NSString alloc] initWithFormat:@"%@%@",atype,aIsAdd?_ING_KEY:_ED_KEY];
    NSString *typeB = [[NSString alloc] initWithFormat:@"%@%@",btype,bIsAdd?_ING_KEY:_ED_KEY];    
    NSString *error = [master insert_fields_values:@{
                                                     @"time":@(time).stringValue,
                                                     @"ctime":@(_fs_integerTimeIntevalSince1970()).stringValue,
                                                     @"je":je,
                                                     @"atype":typeA,
                                                     @"btype":typeB,
                                                     @"bz":bz,
                                                     @"arest":aIsAdd?je:@"0.00",
                                                     @"brest":bIsAdd?je:@"0.00"
                                                     } table:account];
    if (error) {
        [FSUIKit showAlertWithMessage:[[NSString alloc] initWithFormat:@"记账存入失败，敬请反馈:(%@)",error] controller:controller];
        return;
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:_Notifi_refreshAccount object:nil];
    [FSTrack event:_UMeng_Event_acc_su];
    
    NSString *changedTime = @(_fs_integerTimeIntevalSince1970()).stringValue;
    _fs_userDefaults_setObjectForKey(changedTime, [FSDBTool accountChangeKey:account type:_type_account]);
    
    NSString *kJE = [[NSString alloc] initWithFormat:@"%.6f",[je doubleValue]];
    NSString *message = [[NSString alloc] initWithFormat:@"%@ : %@",bz,kJE];
    [FSAPP addMessage:message table:account];
    if (completion) {
        completion();
    }
}

@end
