//
//  FSABPackView.m
//  Expand
//
//  Created by Fudongdong on 2017/8/1.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSABPackView.h"
#import "FSMacro.h"

@interface FSABPackView ()

@property (nonatomic,strong) UILabel    *upLabel;
@property (nonatomic,strong) UILabel    *atLabel;
@property (nonatomic,strong) UILabel    *btLabel;

@end

@implementation FSABPackView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _maxWidth = [UIScreen mainScreen].bounds.size.width * 5;
        [self packDesignViews];
    }
    return self;
}

- (void)packDesignViews{
    self.layer.cornerRadius = 3;
    self.backgroundColor = THISCOLOR;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [self addGestureRecognizer:tap];
}

- (void)setUpText:(NSString *)up aText:(NSString *)a bText:(NSString *)b{
    up = [up isKindOfClass:NSString.class]?up:[up description];
    a = [a isKindOfClass:NSString.class]?a:[a description];
    b = [b isKindOfClass:NSString.class]?b:[b description];
    [self setUpText:up];
    [self setAText:a];
    [self setBText:b];
    [self fitSelfSize];
}

- (void)setUpText:(NSString *)up{
    self.upLabel.text = up;
    [self.upLabel sizeToFit];
    CGFloat upWidth = MIN(_upLabel.frame.size.width, _maxWidth);
    _upLabel.frame = CGRectMake(5, 5, upWidth, (self.frame.size.height - 10) / 3);
    [self fitSelfSize];
}

- (void)setAText:(NSString *)a{
    self.atLabel.text = a;
    [self.atLabel sizeToFit];
    CGFloat doWidth = MIN(_atLabel.frame.size.width, _maxWidth);
    _atLabel.frame = CGRectMake(5, 5 + (self.frame.size.height - 10) / 3, doWidth, (self.frame.size.height - 10) / 3);
    [self fitSelfSize];
}

- (void)setBText:(NSString *)b{
    self.btLabel.text = b;
    [self.btLabel sizeToFit];
    CGFloat doWidth = MIN(_btLabel.frame.size.width, _maxWidth);
    _btLabel.frame = CGRectMake(5, 5 + 2 * (self.frame.size.height - 10) / 3, doWidth, (self.frame.size.height - 10) / 3);
    [self fitSelfSize];
}

- (void)fitSelfSize{
    CGFloat upWidth = _upLabel.frame.size.width;
    CGFloat aWidth = _atLabel.frame.size.width;
    CGFloat bWidth = _btLabel.frame.size.width;
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, MAX(MAX(upWidth, aWidth), bWidth) + 10, self.frame.size.height);
}

- (void)tapAction{
    self.upLabel.alpha = 0;
    self.atLabel.alpha = 0;
    self.btLabel.alpha = 0;
    [UIView animateWithDuration:.3 animations:^{
        self.upLabel.alpha = 1;
        self.atLabel.alpha = 1;
        self.btLabel.alpha = 1;
    }];
    
    if (self.tapCallback) {
        self.tapCallback(self);
    }
}

- (UILabel *)upLabel{
    if (!_upLabel) {
        _upLabel = [self labelCreat];
        _upLabel.frame = CGRectMake(5, 5, self.frame.size.width - 20, (self.frame.size.height - 10) / 3);
        [self addSubview:_upLabel];
    }
    return _upLabel;
}

- (UILabel *)atLabel{
    if (!_atLabel) {
        _atLabel = [self labelCreat];
        _atLabel.frame = CGRectMake(5, 5 + (self.frame.size.height - 10) / 3, self.frame.size.width - 20, (self.frame.size.height - 10) / 3);
        _atLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        [self addSubview:_atLabel];
    }
    return _atLabel;
}

- (UILabel *)btLabel{
    if (!_btLabel) {
        _btLabel = [self labelCreat];
        _btLabel.frame = CGRectMake(5, 5 + (self.frame.size.height - 10) / 3, self.frame.size.width - 20, (self.frame.size.height - 10) / 3);
        _btLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        [self addSubview:_btLabel];
    }
    return _btLabel;
}

- (UILabel *)labelCreat{
    UILabel *label = [[UILabel alloc] init];
    label.font = [UIFont systemFontOfSize:10];
    label.textColor = [UIColor whiteColor];
    return label;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
