//
//  FSSeaController.h
//  Expand
//
//  Created by Fudongdong on 2017/8/8.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSBaseController.h"

@interface FSSeaController : FSBaseController

@end
