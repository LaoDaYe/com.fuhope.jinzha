//
//  FSSeaController.m
//  Expand
//
//  Created by Fudongdong on 2017/8/8.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSSeaController.h"
#import "FSShare.h"
#import <FSUIKit.h>
#import "FSToast.h"
#import "FSTrackKeys.h"

@interface FSSeaController ()<UIScrollViewDelegate>

@property (nonatomic,strong) UISegmentedControl     *control;
@property (nonatomic,strong) UIScrollView           *cScrollView;

@end

@implementation FSSeaController{
    UIBarButtonItem     *_bbi;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self seaDesignViews];
}

- (void)toWechat{
    NSString *toWechat = NSLocalizedString(@"Send to Wechat", nil);
    NSString *toAlbum = NSLocalizedString(@"Save to album", nil);
    [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Save picture", nil) message:nil actionTitles:@[toWechat,toAlbum] styles:@[@(UIAlertActionStyleDefault),@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        UIImage *image = nil;
        NSArray *pays = [self paysImages];
        if (self->_control.selectedSegmentIndex < pays.count) {
            image = [UIImage imageNamed:pays[self->_control.selectedSegmentIndex]];
        }
        if (![image isKindOfClass:UIImage.class]) {
            [FSToast show:NSLocalizedString(@"Get picture fail", nil)];
            return;
        }
        if ([action.title isEqualToString:toWechat]) {
            [FSShare wxImageShareActionWithImage:image controller:self result:^(NSString *bResult) {
                [FSToast show:bResult];
            }];
        }else if ([action.title isEqualToString:toAlbum]){
            UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
        }
    }];
}

- (void)seaDesignViews{
    _bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(toWechat)];
    self.navigationItem.rightBarButtonItem = _bbi;
    
    _control = [[UISegmentedControl alloc] initWithItems:@[NSLocalizedString(@"Wechat", nil),NSLocalizedString(@"Alipay", nil)]];
    _control.selectedSegmentIndex = 0;
    [_control addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
    self.navigationItem.titleView = _control;
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    _cScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, size.width, size.height - 64)];
    _cScrollView.contentSize = CGSizeMake(_cScrollView.frame.size.width * 2, _cScrollView.frame.size.height);
    _cScrollView.pagingEnabled = YES;
    _cScrollView.delegate = self;
    [self.view addSubview:_cScrollView];
    
    NSArray *pays = [self paysImages];
    for (int x = 0; x < 2; x ++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        UIImage *image = [UIImage imageNamed:pays[x]];
        if ([image isKindOfClass:UIImage.class]) {
            CGFloat height =  (size.width - 30) * (image.size.height / MAX(1, image.size.width));
            imageView.image = image;
            imageView.frame = CGRectMake(size.width * x + 15, x?20:70, size.width - 30, height);
        }
        imageView.tag = x;
        [_cScrollView addSubview:imageView];
        imageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapClick:)];
        [imageView addGestureRecognizer:tap];
    }
}

- (void)tapClick:(UITapGestureRecognizer *)tap{
    UIImageView *view = (UIImageView *)tap.view;
    [self imageTapAction:view.tag view:view];
}

- (void)imageTapAction:(NSInteger)x view:(UIImageView *)view{
    if (x == 0) {
        [self toWechat];
    }else{
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Save", nil) message:@"将会保存到相册" actionTitles:@[NSLocalizedString(@"Save", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            if ([view.image isKindOfClass:UIImage.class]) {
                UIImageWriteToSavedPhotosAlbum(view.image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
            }
        }];
    }
}

- (NSArray *)paysImages{
    static NSArray *pays = nil;
    if (!pays) {
        pays = @[@"wechat_pay",@"alipay_pay"];
    }
    return pays;
}

- (void)segmentAction:(UISegmentedControl *)control{
    CGSize size = [UIScreen mainScreen].bounds.size;
    _cScrollView.contentOffset = CGPointMake(control.selectedSegmentIndex * size.width, 0);
    _bbi.enabled = control.selectedSegmentIndex == 0;
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *) error contextInfo:(void *)contextInfo{
    if (error) {
        [FSToast show:error.localizedDescription];
    }else{
        [FSToast show:@"已保存到相册"];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [FSTrack event:_UMeng_Event_m_scan];
    
    CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    _control.selectedSegmentIndex = page;
    _bbi.enabled = page == 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
