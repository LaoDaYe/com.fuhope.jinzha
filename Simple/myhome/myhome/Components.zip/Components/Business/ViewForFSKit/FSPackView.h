//
//  FSPackView.h
//  Expand
//
//  Created by Fudongdong on 2017/8/1.
//  Copyright © 2017年 china. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSPackView : UIView

// 等距分布【推荐】
@property (nonatomic,strong) NSArray    *list;

// 均衡式对称分布
@property (nonatomic,strong) NSArray    *views;


@end
