//
//  FSPackView.m
//  Expand
//
//  Created by Fudongdong on 2017/8/1.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSPackView.h"

@interface FSPackView ()

@property (nonatomic,strong) UIScrollView   *scrollView;

@end

@implementation FSPackView

- (void)setViews:(NSArray *)list{
    _views = list;
    if (!([list isKindOfClass:NSArray.class] && list.count))return;
    
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat vMargin = 10;                           // 上下相对self的边距
    CGFloat hMargin = 10;                           // 左右相对self的边距
    CGFloat hSpace = 5;                            // view之间水平的间距
    CGFloat vSpace = 10;                            // view之间垂直的距离
    CGFloat offsetY = vMargin;                      // 偏移量
    CGFloat widthSum = 0;
    int index = 0;
    NSMutableArray *lines = [[NSMutableArray alloc] init];
    for (UIView *view in list) {
        UIView *frontView = nil;
        if (lines.count) {
            frontView = [lines lastObject];
        }
        CGFloat frontRight = frontView.frame.origin.x + frontView.frame.size.width;
        if ((frontRight + hSpace + view.frame.size.width + hMargin) > width) {    // 超出右边界,view得隔行
            offsetY = frontView?((frontView.frame.origin.y + frontView.frame.size.height) + vSpace):vMargin;
            view.frame = CGRectMake(hMargin, offsetY, view.frame.size.width, view.frame.size.height);
            // 重新布局
            if (lines.count) {
                [self relayoutViews:lines sum:widthSum hMargin:hMargin];
                [lines removeAllObjects];
            }
            [lines addObject:view];
            widthSum = view.frame.size.width;
        }else{
            view.frame = CGRectMake(frontRight + hSpace, offsetY, view.frame.size.width, view.frame.size.height);
            [lines addObject:view];
            widthSum += view.frame.size.width;
            
            if (index == (list.count - 1)) {
                [self relayoutViews:lines sum:widthSum hMargin:hMargin];
            }
        }
        index ++;
        [self addSubview:view];
    }
    
    UIView *lastView = [lines lastObject];
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, lastView.frame.origin.y + lastView.frame.size.height + vMargin);
    
    [lines removeAllObjects];
    lines = nil;
}

- (void)relayoutViews:(NSArray <UIView *> *)lines sum:(CGFloat)widthSum hMargin:(CGFloat)hMargin{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat newSpace = (width - widthSum - 2 * hMargin) / (lines.count -1);
    UIView *firstView = nil;
    for (UIView *lView in lines) {
        lView.frame = CGRectMake(firstView?(firstView.frame.origin.x + firstView.frame.size.width + newSpace):hMargin, lView.frame.origin.y, lView.frame.size.width, lView.frame.size.height);
        firstView = lView;
    }
}

- (void)setList:(NSArray *)list{
    _list = list;
    if (!([list isKindOfClass:NSArray.class] && list.count))return;
    
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat vMargin = 10;                           // 上下相对self的边距
    CGFloat hMargin = 15;                           // 左右相对self的边距
    CGFloat hSpace = 5;                             // view之间水平的间距
    CGFloat vSpace = 5;                             // view之间垂直的距离
    CGFloat offsetY = vMargin;                      // 偏移量
    UIView *frontView = nil;
    CGFloat right = 0;
    for (UIView *view in list) {
        CGFloat frontRight = frontView.frame.origin.x + frontView.frame.size.width;
        if (frontRight + hSpace < width) {
            view.frame = CGRectMake(frontView?(frontRight + hSpace):hMargin, offsetY, view.frame.size.width, view.frame.size.height);
        }else{  // 超出右边界,view得隔行
            offsetY = frontView?((frontView.frame.origin.y + frontView.frame.size.height) + vSpace):vMargin;
            view.frame = CGRectMake(hMargin, offsetY, view.frame.size.width, view.frame.size.height);
        }
        frontView = view;
        right = MAX(right, view.frame.origin.x + view.frame.size.width);
        
        [self.scrollView addSubview:view];
    }
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, frontView.frame.origin.y + frontView.frame.size.height + vMargin);
    self.scrollView.frame = self.bounds;
    self.scrollView.contentSize = CGSizeMake(MAX(right + 10, self.scrollView.frame.size.width + 10), self.scrollView.frame.size.height);
}

- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        _scrollView.showsHorizontalScrollIndicator = NO;
        [self addSubview:_scrollView];
    }
    return _scrollView;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
