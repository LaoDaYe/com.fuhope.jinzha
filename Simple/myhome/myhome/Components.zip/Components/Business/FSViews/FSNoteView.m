//
//  FSNoteView.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSNoteView.h"
#import "FSLabel.h"
#import "FSShare.h"
#import "FSMacro.h"
#import <YYLabel.h>

@implementation FSNoteView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self noteDesignViews];
    }
    return self;
}

- (void)noteDesignViews{
    self.backgroundColor = [UIColor whiteColor];
    CGSize size = self.bounds.size;
    
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, 64)];
    topView.backgroundColor = [UIColor whiteColor];
    [self addSubview:topView];
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 64, size.width, .5)];
    line.backgroundColor = [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1];
    [self addSubview:line];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(size.width / 3, 20, size.width / 3, 44)];
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont systemFontOfSize:18];
    label.text = @"说明";
    [topView addSubview:label];
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, size.width, size.height - 64)];
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.delegate = self;
    [self addSubview:scrollView];
    
    static NSString *message = nil;
    static YYTextLayout *textLayout = nil;
    if (!message) {
        message = [[NSString alloc] initWithFormat:@"尊敬的用户：\n\t感谢阅读本软件的说明，你了解后会对使用有帮助。\n\n 一，数据安全：\n\t1.存储：你的所有数据都保存在本手机中，如果删除了本软件，数据也将随之删除；你可以将数据导出保存在其他地方，也可以重新导入本App继续使用，如苹果系统功能AirDrop可以将文件导入本软件。\n\n\t2.加密：在第一次打开本软件时，首先是一个设置“核心密码”的页面，设置后会对你的重要数据进行加密，包括密码、日记内容、生日姓名、通讯录姓名与手机号、待办内容等，其他数据（含账本）因为计算的需要没有加密。\n\n\t3.建议：为了尽量保护数据安全与使用方便，建议您设置足够复杂的密码，注意防止密码泄露：\n- 核心密码：唯一不能忘的密码，可更改\n- 手势密码：可根据核心密码重置\n\n\n 二，使用帮助：\n\t1.导出：目前支持的导出方式有微信、系统邮件及AirDrop。\n\n\t2.存储：如果您使用邮件把文件导出，建议发送到QQ邮箱，QQ邮箱内可把文件存入微云。\n\n\t3.其他：定位中使用导航时，建议下载百度地图和高德地图等。 \n\n\n三，问题反馈：\n\t任何疑惑或问题，欢迎邮件到%@。\n\n【2018年5月6日】",_feedback_Email];
        
        textLayout = [self layoutWithString:message size:CGSizeMake(WIDTHFC - 30, CGFLOAT_MAX) font:[UIFont systemFontOfSize:14] color:[UIColor blackColor] maxLines:0 insets:UIEdgeInsetsZero];
    }
    
    YYLabel *showLabel = [[YYLabel alloc] initWithFrame:CGRectMake(15, 15, size.width - 30, textLayout.textBoundingSize.height)];
    showLabel.displaysAsynchronously = YES;
    showLabel.textLayout = textLayout;
    [scrollView addSubview:showLabel];
    scrollView.contentSize = CGSizeMake(size.width, MAX(size.height, showLabel.bounds.size.height + 40));
}

- (YYTextLayout *)layoutWithString:(NSString *)string size:(CGSize)size font:(UIFont *)font color:(UIColor *)color maxLines:(NSInteger)rows insets:(UIEdgeInsets)insets{
    if (![string isKindOfClass:NSString.class]) {
        string = @"";
    }
    if (![font isKindOfClass:UIFont.class]) {
        return nil;
    }
    if (![color isKindOfClass:UIColor.class]) {
        return nil;
    }
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithString:string attributes:@{NSForegroundColorAttributeName:color,NSFontAttributeName:font}];
    YYTextContainer *container = [YYTextContainer containerWithSize:size insets:insets];
    container.truncationType = YYTextTruncationTypeEnd;
    container.maximumNumberOfRows = rows;
    YYTextLayout *layout = [YYTextLayout layoutWithContainer:container text:attr];
    return layout;
}

- (void)closeAction:(UIButton *)btn{
    if (btn.tag) {
//        NSString *url = [NSString stringWithString: @"mailto:foo@example.com?cc=bar@example.com&subject=Greetings%20from%20Cupertino!&body=Wish%20you%20were%20here!"];
        NSString *subject = [[NSString alloc] initWithFormat:@"%@App %@",[FSKit appName],NSLocalizedString(@"Feedback", nil)];
        NSString *url = [[NSString alloc] initWithFormat:@"mailto:%@?subject=%@",_feedback_Email,[FSKit urlEncodedString:subject]];
        NSURL *URL = [NSURL URLWithString:url];
        UIApplication *app = [UIApplication sharedApplication];
        if ([app canOpenURL:URL]) {
            [app openURL:URL];
        }
    }else{
        if (self.close) {
            self.close(self);
        }
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (decelerate) {
        if (self.keyboardExit) {
            self.keyboardExit();
        }
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
