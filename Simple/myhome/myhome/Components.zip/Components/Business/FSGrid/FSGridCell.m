//
//  FSGridCell.m
//  FSGrid
//
//  Created by fudon on 2017/1/10.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSGridCell.h"

@implementation FSGridCell
{
    UILabel     *_label;
    UIImageView *_imageView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self gridDesignViews];
    }
    return self;
}

- (void)gridDesignViews
{
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.bounds.size.width / 2 - 30, self.bounds.size.width / 2 - 30, 60, 60)];
    [self addSubview:_imageView];
    
    _label = [[UILabel alloc] initWithFrame:CGRectMake(0, self.bounds.size.height - 25, self.bounds.size.width, 25)];
    _label.textAlignment = NSTextAlignmentCenter;
    _label.font = [UIFont systemFontOfSize:13];
    [self addSubview:_label];
}


- (void)setDic:(NSDictionary *)dic
{
    if ([dic isKindOfClass:NSDictionary.class] && dic.count) {
        _dic = dic;
        
        _label.text = [dic objectForKey:@"text"];
        _imageView.image = [UIImage imageNamed:dic[@"image"]];
    }
}

@end
