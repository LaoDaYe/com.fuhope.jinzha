//
//  FSGridController.m
//  FSGrid
//
//  Created by fudon on 2017/1/10.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSGridController.h"
#import "FSGridCell.h"

@interface FSGridController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong) UICollectionView   *collectionView;

@end

static NSString *_cellID = @"FSGirdCell";

@implementation FSGridController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self gridDesignViews];
}

- (void)gridDesignViews
{
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    CGFloat width = ([UIScreen mainScreen].bounds.size.width - 11.5) / 4;
    CGFloat height = width + 25;
    CGFloat contentHeight = (self.dataSource.count / 4 + 1) * height;
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.itemSize = CGSizeMake(width,height);
    layout.minimumInteritemSpacing = .5;
    layout.minimumLineSpacing = .5;
    
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(5, 64, self.view.bounds.size.width - 10, self.view.bounds.size.height - 64) collectionViewLayout:layout];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.contentSize = CGSizeMake(self.view.bounds.size.width - 10, MAX(self.view.bounds.size.height, contentHeight));
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    _collectionView.alwaysBounceVertical = YES;
    [_collectionView registerClass:FSGridCell.class forCellWithReuseIdentifier:_cellID];
    [self.view addSubview:_collectionView];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (FSGridCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    FSGridCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:_cellID forIndexPath:indexPath];
    NSDictionary *dic = self.dataSource[indexPath.row];
    cell.dic = dic;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = self.dataSource[indexPath.row];
    NSString *name = [dic objectForKey:@"pushTo"];
    
    Class Controller = NSClassFromString(name);
    if (Controller) {
        UIViewController *vc = [[Controller alloc] init];
        [self presentViewController:vc animated:YES completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
