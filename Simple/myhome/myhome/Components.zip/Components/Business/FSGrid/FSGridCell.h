//
//  FSGridCell.h
//  FSGrid
//
//  Created by fudon on 2017/1/10.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSGridCell : UICollectionViewCell

@property (nonatomic,strong) NSDictionary   *dic;

@end
