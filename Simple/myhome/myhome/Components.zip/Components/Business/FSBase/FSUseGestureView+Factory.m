//
//  FSUseGestureView+Factory.m
//  FSCalculator
//
//  Created by fudongdong on 2018/12/28.
//

#import "FSUseGestureView+Factory.h"
#import "UIView+ModalAnimation.h"
#import <objc/runtime.h>
#import "FSUIKit.h"
#import "FSToast.h"
#import "FSCryptorSupport.h"
#import "FSKeyValueCryptor.h"

@implementation FSUseGestureView (Factory)

static BOOL _hasShowed;
+ (void)verify:(UIView *)superView success:(void(^)(FSUseGestureView * view))success{
    [self verify:superView success:success buttonClick:nil];
}

+ (void)verify:(UIView *)superView success:(void(^)(FSUseGestureView * view))success cancel:(void(^)(void))cancel{
    [self verify:superView success:success buttonClick:^(FSUseGestureView *view, BOOL isLeft) {
        if (cancel) {
            cancel();
        }
    }];
}

+ (void)verify:(UIView *)superView success:(void(^)(FSUseGestureView * view))success buttonClick:(void(^)(FSUseGestureView * view, BOOL isLeft))buttonClick{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (_hasShowed) {
            return;
        }
        NSString *password = FSKeyValueCryptor.gesturePassword;
        if (!([password isKindOfClass:NSString.class] && password.length)) {
            [FSToast show:NSLocalizedString(@"[Set] to set gesture code", nil)];
            if (success) {
                success(nil);
            }
            return;
        }else{
            BOOL open = FSAppManager.sharedInstance.open;
            if (open) {
                if (success) {
                    success(nil);
                }
                return;
            }
        }
        
        const char *_akey = "sort";
        BOOL isPushing = [objc_getAssociatedObject(self, _akey) boolValue];
        if (isPushing) {
            return;
        }
        _hasShowed = YES;
        objc_setAssociatedObject(self, _akey, @YES, OBJC_ASSOCIATION_RETAIN);
        FSUseGestureView *use = [[FSUseGestureView alloc] initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height)];
        use.mode = FSUseGestureViewModeVerify;
        use.password = password;
        use.titleLabel.text = @"验证手势密码";
        [superView addSubview:use];
        use.backgroundColor = UIColor.whiteColor;
        use.verifySuccess = ^(FSUseGestureView * _Nonnull view, BOOL verifySuccess) {
            if (verifySuccess) {
                _hasShowed = NO;
                
                FSAppManager.sharedInstance.open = YES;
                [view popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                    if (success) {
                        success(view);
                    }
                    [modalView removeFromSuperview];
                }];
            }
        };
        use.buttonClick = ^(FSUseGestureView * _Nonnull view, BOOL isLeft) {
            if (buttonClick) {
                buttonClick(view,isLeft);
            }else if (!isLeft){
                [self bbiAction];
            }
            
            if (isLeft) {
                _hasShowed = NO;
                [view popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                    [modalView removeFromSuperview];
                }];
            }
        };
        
        [use pushAnimated:YES completion:^(UIView * _Nonnull modalView) {
            objc_setAssociatedObject(self, _akey, @NO, OBJC_ASSOCIATION_RETAIN);
        }];
    });
}

+ (void)change:(UIView *)superView password:(NSString *)password completion:(void(^)(FSUseGestureView *view))completion{
    dispatch_async(dispatch_get_main_queue(), ^{
        const char *_akey = "sort";
        BOOL isPushing = [objc_getAssociatedObject(self, _akey) boolValue];
        if (isPushing) {
            return;
        }
        objc_setAssociatedObject(self, _akey, @YES, OBJC_ASSOCIATION_RETAIN);
        
        FSUseGestureView *use = [[FSUseGestureView alloc] initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height)];
        use.mode = FSUseGestureViewModeChange;
        use.password = password;
        use.showLabel.text = @"请输入原密码";
        use.titleLabel.text = @"修改手势密码";
        [superView addSubview:use];
        use.backgroundColor = UIColor.whiteColor;
        use.changeSuccess = ^(FSUseGestureView * _Nonnull view) {
            if (completion) {
                completion(view);
            }
            
            [view popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                [modalView removeFromSuperview];
            }];
        };
        use.buttonClick = ^(FSUseGestureView * _Nonnull view, BOOL isLeft) {
            if (isLeft) {
                [view popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                    [modalView removeFromSuperview];
                }];
            }else{
                
            }
        };
        [use pushAnimated:YES completion:^(UIView * _Nonnull modalView) {
            objc_setAssociatedObject(self, _akey, @NO, OBJC_ASSOCIATION_RETAIN);
        }];
    });
}

+ (void)setup:(UIView *)superView completion:(void(^)(FSUseGestureView *view))completion{
    dispatch_async(dispatch_get_main_queue(), ^{
        const char *_akey = "sort";
        BOOL isPushing = [objc_getAssociatedObject(self, _akey) boolValue];
        if (isPushing) {
            return;
        }
        objc_setAssociatedObject(self, _akey, @YES, OBJC_ASSOCIATION_RETAIN);
        
        FSUseGestureView *use = [[FSUseGestureView alloc] initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height)];
        use.mode = FSUseGestureViewModeSet;
        use.showLabel.text = @"请设置新密码";
        use.titleLabel.text = @"设置手势密码";
        [superView addSubview:use];
        use.backgroundColor = UIColor.whiteColor;
        use.setSuccess = ^(FSUseGestureView * view) {
            if (completion) {
                completion(view);
            }
            [view popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                [modalView removeFromSuperview];
            }];
        };
        use.buttonClick = ^(FSUseGestureView * _Nonnull view, BOOL isLeft) {
            if (isLeft) {
                [view popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                    [modalView removeFromSuperview];
                }];
            }else{
                
            }
        };
        [use pushAnimated:YES completion:^(UIView * _Nonnull modalView) {
            objc_setAssociatedObject(self, _akey, @NO, OBJC_ASSOCIATION_RETAIN);
        }];
    });
}

+ (void)bbiAction{
    [FSUIKit alertOnCustomWindow:UIAlertControllerStyleActionSheet title:NSLocalizedString(@"You can use 'Core password' to reset gesture code", nil) message:nil actionTitles:@[NSLocalizedString(@"Delete gesture code", nil)] styles:@[@(UIAlertActionStyleDestructive)] handler:^(UIAlertAction *action) {
        __weak typeof(self)this = self;
        [FSUIKit alertInputOnCustomWindow:1 title:NSLocalizedString(@"Input 'Core password'", nil) message:nil ok:NSLocalizedString(@"Confirm", nil) handler:^(UIAlertController *bAlert, UIAlertAction *action) {
            UITextField *tf = bAlert.textFields.firstObject;
            if (tf.text.length == 0) {
                [FSToast show:NSLocalizedString(@"Please Input 'Core password'", nil)];
                return;
            }
            NSString *corePwd = [FSCryptorSupport localUserDefaultsCorePassword];
            if ([[FSCryptorSupport md5:tf.text] isEqualToString:corePwd]) {
                [FSKeyValueCryptor removeGesture];
                [FSToast show:NSLocalizedString(@"The old has be deleted,please set a new one", nil)];
                
                [this popAnimated:YES completion:^(UIView * _Nonnull modalView) {
                    [modalView removeFromSuperview];
                }];
            }else{
                [FSToast show:NSLocalizedString(@"'Core password' is incorrect", nil)];
            }
        } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:^(UITextField *textField) {
            textField.placeholder = NSLocalizedString(@"Input 'Core password'", nil);
        } completion:nil];
    }];
}

@end
