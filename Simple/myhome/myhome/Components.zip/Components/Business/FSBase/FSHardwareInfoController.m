//
//  FSHardwareInfoController.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/5/14.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSHardwareInfoController.h"
#import "FSKit.h"
#import "FuSoft.h"
#import "FSToast.h"

@interface FSHardwareInfoController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSArray        *dataArray;

@end

@implementation FSHardwareInfoController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"硬件信息";
    self.dataArray = [FSKit deviceInfos];
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    
    CGFloat rate = [FSKit freeStoragePercentage];
    if (rate < 0.3) {
        NSString *message = [[NSString alloc] initWithFormat:@"手机空间只剩%.2f%@",rate * 100,@"%"];
        [FSToast show:message];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.textLabel.text = [dic objectForKey:@"name"];
    cell.detailTextLabel.text = [dic objectForKey:@"value"];
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
