//
//  FSButtonsView.m
//  myhome
//
//  Created by FudonFuchina on 2016/12/11.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSButtonsView.h"
#import "FSMacro.h"

@interface FSButtonsView ()

@property (nonatomic,strong) UIView     *colorView;
@property (nonatomic,strong) UIColor    *normalColor;
@property (nonatomic,strong) UIColor    *selectedColor;

@end

@implementation FSButtonsView

- (instancetype)initWithFrame:(CGRect)frame items:(NSArray *)items normalColor:(UIColor *)normalColor selectedColor:(UIColor *)selectedColor
{
    self = [super initWithFrame:frame];
    if (self) {
        _normalColor = normalColor;
        _selectedColor = selectedColor;
        [self buttonsDesignViews:items];
    }
    return self;
}


- (void)buttonsDesignViews:(NSArray *)items
{
    float width = WIDTHFC / items.count;
    for (int x = 0; x < items.count; x ++) {
        UIButton *button = [FSViewManager buttonWithFrame:CGRectMake(width * x, 0, width, self.height) title:items[x] titleColor:_normalColor backColor:[UIColor whiteColor] fontInt:15 tag:TAG_BUTTON + x target:self selector:@selector(buttonClick:)];
        [self addSubview:button];
        if (x) {
            UIView *lineView = [FSViewManager seprateViewWithFrame:CGRectMake(0, 0, FS_LineThickness, button.height)];
            [button addSubview:lineView];
        }
    }
    
    _colorView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height - 2, self.width / items.count, 2)];
    _colorView.backgroundColor = _selectedColor;
    [self addSubview:_colorView];
    self.selectedIndex = 0;
}

- (void)buttonClick:(UIButton *)button
{
    [self selectedButton:button];
    
    if (_clickBlock) {
        _clickBlock(self,button.tag - TAG_BUTTON);
    }
}

- (void)setSelectedIndex:(NSInteger)selectedIndex
{
    _selectedIndex = selectedIndex;
    UIButton *button = [self viewWithTag:TAG_BUTTON + selectedIndex];
    [self selectedButton:button];
}

- (void)selectedButton:(UIButton *)button
{
    WEAKSELF(this);
    for (UIButton *btn in self.subviews) {
        if ([btn isKindOfClass:UIButton.class]) {
            if (btn == button) {
                [UIView animateWithDuration:.3 animations:^{
                    this.colorView.left = btn.left;
                    [btn setTitleColor:self->_selectedColor forState:UIControlStateNormal];
                }];
            }else{
                [btn setTitleColor:_normalColor forState:UIControlStateNormal];
            }
        }
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
