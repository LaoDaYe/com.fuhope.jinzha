//
//  UIView+ViewController.m
//  ShareEconomy
//
//  Created by fudon on 2016/9/1.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "UIView+ViewController.h"

@implementation UIView (ViewController)

- (FSBaseController *)viewController
{
    UIResponder *next = self.nextResponder;
    while (next != nil) {
        if ([next isKindOfClass:FSBaseController.class]) {
            __weak FSBaseController *vc = (FSBaseController *)next;
            return vc;
        }
        next = next.nextResponder;
    }
    return nil;
}

@end
