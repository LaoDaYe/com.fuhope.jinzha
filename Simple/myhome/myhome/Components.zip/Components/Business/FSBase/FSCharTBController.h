//
//  FSCharTBController.h
//  myhome
//
//  Created by fudon on 2016/11/2.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSCharTBController : UITabBarController

- (instancetype)initWithClasses:(NSArray<NSString *>*)classes titles:(NSArray<NSString *>*)titles types:(NSArray<NSNumber *>*)types;

@end
