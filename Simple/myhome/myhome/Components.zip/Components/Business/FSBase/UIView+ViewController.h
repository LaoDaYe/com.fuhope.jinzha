//
//  UIView+ViewController.h
//  ShareEconomy
//
//  Created by fudon on 2016/9/1.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FSBaseController.h"

@interface UIView (ViewController)

- (FSBaseController *)viewController;

@end
