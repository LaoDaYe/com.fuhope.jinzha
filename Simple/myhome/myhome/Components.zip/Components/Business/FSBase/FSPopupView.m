//
//  FSPopupView.m
//  myhome
//
//  Created by FudonFuchina on 2017/9/13.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSPopupView.h"
#if DEBUG
#import "FSToast.h"
#endif

@implementation FSPopupView

#if DEBUG
- (void)dealloc{
    [FSToast show:@"FSPopupView 已释放"];
}
#endif

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self popupDesignViews];
    }
    return self;
}

- (void)popupDesignViews{
    UIView *back = [[UIView alloc] initWithFrame:self.bounds];
    [self addSubview:back];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    [back addGestureRecognizer:tap];
}

- (void)tap{
    [self dismiss];
}

- (void)dismiss{
    [UIView animateWithDuration:.3 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
