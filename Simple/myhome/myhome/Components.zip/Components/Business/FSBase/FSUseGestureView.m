//
//  FSUseGestureView.m
//  FSCalculator
//
//  Created by fudongdong on 2017/12/27.
//

#import "FSUseGestureView.h"
#import "FSGestureView.h"
#import "FSKit.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import "FSToast.h"

static NSString *_FSGestureController_Switch = @"FSGestureController_switch";

@implementation FSUseGestureView{
    FSGestureView   *_g;
    
    // 用于修改密码
    NSInteger       _changeFlag;
    NSString        *_modifyPassword;
    
    // 用于设置密码
    NSInteger       _setFlag;
    NSString        *_setPassword;
}

#if DEBUG
- (void)dealloc{
    NSLog(@"FSUseGestureView dealloc");
}
#endif

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self designViews];
    }
    return self;
}

- (void)designViews{
    CGFloat w = UIScreen.mainScreen.bounds.size.width;
    CGFloat statusBarHeight = UIApplication.sharedApplication.statusBarFrame.size.height;
    
    _leftButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_leftButton setTitle:@"取消" forState:UIControlStateNormal];
    _leftButton.frame = CGRectMake(0, statusBarHeight, 76, 44);
    _leftButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [_leftButton addTarget:self action:@selector(cancelClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_leftButton];
    
    _rightButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_rightButton setTitle:@"忘记？" forState:UIControlStateNormal];
    _rightButton.frame = CGRectMake(w - 76, statusBarHeight, 76, 44);
    _rightButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [_rightButton addTarget:self action:@selector(cancelClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_rightButton];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(60, statusBarHeight, w - 120, 44)];
    if (@available(iOS 8.2, *)) {
        _titleLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
    }
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_titleLabel];
    
    CALayer *layer = CALayer.layer;
    layer.backgroundColor = UIColor.lightGrayColor.CGColor;
    layer.frame = CGRectMake(0, statusBarHeight + 44, w, 0.4);
    [self.layer addSublayer:layer];
    
    _showLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, statusBarHeight + 65, w - 20, 40)];
    _showLabel.textAlignment = NSTextAlignmentCenter;
    _showLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:_showLabel];
    
    _g = [[FSGestureView alloc] initWithFrame:CGRectMake(20, statusBarHeight + 100, w - 40, w - 40)];
    [self addSubview:_g];
    __weak typeof(self)this = self;
    [_g setResult:^(NSString *bResult) {
        [this handleResult:bResult];
    }];
    _g.start = ^{
        this.showLabel.text = nil;
    };
    
    [self handleFinger];
}

- (void)cancelClick:(UIButton *)button{
    if (self.buttonClick) {
        self.buttonClick(self, button == _leftButton);
    }
}

- (void)handleResult:(NSString *)result{
    if (self.mode == FSUseGestureViewModeVerify) {
        [self handleVerify:result];
    }else if (self.mode == FSUseGestureViewModeChange) {
        [self handleChange:result];
    }else if (self.mode == FSUseGestureViewModeSet){
        [self handleSet:result];
    }
}

- (void)handleSet:(NSString *)result{
    if (_setFlag == 0) {
        _setFlag ++;
        _setPassword = result;
        [self showLabelText:@"请再次输入确认" textColor:UIColor.blackColor];
    }else if (_setFlag == 1){
        if ([result isEqualToString:_setPassword]) {
            if (self.setSuccess) {
                self.setSuccess(self);
            }
        }else{
            _setFlag = 0;
            [self showLabelText:@"两次输入不一致，请重新输入" textColor:UIColor.redColor];
        }
    }
}

- (void)handleChange:(NSString *)result{
    if (_changeFlag == 0) {
        if ([result isEqualToString:self.password]) {
            _changeFlag ++;
            [self showLabelText:@"请设置新的手势密码" textColor:UIColor.blackColor];
        }else{
            [self showLabelText:@"原密码校验错误，请重新输入" textColor:UIColor.redColor];
        }
    }else if (_changeFlag == 1){
        _changeFlag ++;
        _modifyPassword = result;
        [self showLabelText:@"请再次输入确认" textColor:UIColor.blackColor];
    }else if (_changeFlag == 2){
        if ([result isEqualToString:_modifyPassword]) {
            if (self.changeSuccess) {
                self.changeSuccess(self);
            }
        }else{
            _changeFlag = 1;
            [self showLabelText:@"两次输入不一致，请重新输入" textColor:UIColor.redColor];
        }
    }
}

- (void)handleVerify:(NSString *)result{
    BOOL verifySuccess = self.password && [result isEqualToString:self.password];
    if (self.verifySuccess) {
        self.verifySuccess(self, verifySuccess);
    }
    
    if (verifySuccess == NO) {
        [self showLabelText:@"密码输入错误，请重新输入" textColor:UIColor.redColor];
    }
}

- (void)showLabelText:(NSString *)text textColor:(UIColor *)color{
    _showLabel.text = text;
    _showLabel.textColor = color;
}

- (void)handleFinger{
    BOOL supportOwnerAuthentication = [self supportToDeviceOwnerAuthentication];
    if (supportOwnerAuthentication) {
        UIColor *color = [UIColor colorWithRed:18 / 255.0 green:152/ 255.0 blue:233/255.0 alpha:1.0];
        UIButton *qButton = [UIButton buttonWithType:UIButtonTypeSystem];
        qButton.frame = CGRectMake(80, _g.frame.origin.y + _g.frame.size.height + 20, self.frame.size.width - 160, 44);
        [qButton setTitle:NSLocalizedString(@"Touch ID", nil) forState:UIControlStateNormal];
        [qButton setTitleColor:color forState:UIControlStateNormal];
        qButton.titleLabel.font = [UIFont systemFontOfSize:14];
        [qButton addTarget:self action:@selector(qButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:qButton];
        
        BOOL open = [_fs_userDefaults_objectForKey(_FSGestureController_Switch) boolValue];
        if (open) {
            [self qButtonClick];
        }
        
        UISwitch *s = [[UISwitch alloc] initWithFrame:CGRectMake(self.frame.size.width / 2 - 31/2.0 - 10, qButton.frame.origin.y + qButton.frame.size.height + 20, 51, 31)];
        [s addTarget:self action:@selector(switchClick:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:s];
        if (open) {
            s.on = open;
        }
    }
}

- (void)qButtonClick{
    __weak typeof(self)this = self;
    LAContext *ctx = [[LAContext alloc] init];
    NSError *errorDesc = nil;
    if ([ctx canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&errorDesc]) {
        [ctx evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:NSLocalizedString(@"Touch ID to unlock", nil) reply:^(BOOL success, NSError *error){
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                if (success) {
                    if (self.verifySuccess) {
                        self.verifySuccess(self, YES);
                    }
                    return;
                }
                if (error) {
                    [this handleFingerError:error];
                }
            });
        }];
    }else {
        [self handleFingerError:errorDesc];
    }
}

- (BOOL)supportToDeviceOwnerAuthentication{
    LAContext *ctx = [[LAContext alloc] init];
    return [ctx canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:NULL];
}

- (void)switchClick:(UISwitch *)s{
    _fs_userDefaults_setObjectForKey(@(s.isOn), _FSGestureController_Switch);
}

- (void)handleFingerError:(NSError *)error{
    switch (error.code) {
        case LAErrorAuthenticationFailed:{
            [FSToast show:NSLocalizedString(@"Authorization failed", nil)];
        }
            break;
        case LAErrorUserCancel:
        case LAErrorUserFallback:
        case LAErrorPasscodeNotSet:
        case LAErrorTouchIDNotAvailable:
        case LAErrorTouchIDNotEnrolled:{
            [FSToast show:@"手动输入密码"];
        }break;
        case LAErrorTouchIDLockout:{
            [FSToast show:NSLocalizedString(@"Need system unlock", nil)];
        }break;
        case LAErrorInvalidContext:{
            [FSToast show:@"请求验证出错"];
        }break;
        default:
            break;
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
