//
//  FSBaseView.m
//  ShareEconomy
//
//  Created by fudon on 16/5/4.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSBaseView.h"

@interface FSBaseView ()

@property (nonatomic,strong) UIView     *backShadowView;

@end

@implementation FSBaseView

#if DEBUG
- (void)dealloc{
    FSLog();
}
#endif

- (instancetype)initWithFrame:(CGRect)frame controller:(UIViewController *)controller{
    self = [super initWithFrame:frame];
    if (self) {
        self.responderController = controller;
        if ([controller.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            controller.navigationController.interactivePopGestureRecognizer.enabled = NO;
        }
        
        _backShadowView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _backShadowView.backgroundColor = [UIColor blackColor];
        [self addSubview:_backShadowView];
        _backShadowView.alpha = 0;
        [UIView animateWithDuration:.3 animations:^{
            self->_backShadowView.alpha = .28;
        }];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backTapAction)];
        [_backShadowView addGestureRecognizer:tap];
    }
    return self;
}

- (void)backTapAction
{
    if (self.backTapBlock) {
        [self freeAction];
        self.backTapBlock();
    }
}

- (void)freeAction
{
    if ([self.responderController.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.responderController.navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
    
    [UIView animateWithDuration:.3 animations:^{
        self->_backShadowView.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
