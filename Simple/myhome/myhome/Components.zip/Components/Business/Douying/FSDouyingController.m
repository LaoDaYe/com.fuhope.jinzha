//
//  FSDouyingController.m
//  myhome
//
//  Created by FudonFuchina on 2018/9/15.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSDouyingController.h"
#import "FSDouyingLabel.h"
#import "FuSoft.h"
#import "FSKit.h"
#import "UIViewExt.h"
#import "FSToast.h"

@interface FSDouyingController ()

@end

@implementation FSDouyingController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    
    self.view.backgroundColor = UIColor.blackColor;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self repeatedlyDoingSomething];
    });
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(0, HEIGHTFC - 50, WIDTHFC, 50);
    [self.view addSubview:button];
    [button addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
}

- (void)click{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)repeatedlyDoingSomething{
    static NSTimeInterval time = 0;
    static NSInteger count = 0;
    if (count == 0) {
        time = _fs_timeIntevalSince1970();
    }
    NSArray *txts = self.poets;
    if (txts.count > count) {
        NSString *sub = txts[count];
        FSDouyingLabel *label = self.makeALabel;
        label.top = 100 + count * 30;
        __weak typeof(self)this = self;
        [label douyingShow:sub completion:^{
            [this repeatedlyDoingSomething];
        }];
    }else{
        NSTimeInterval t = _fs_timeIntevalSince1970() - time;
        if (t > 15) {
            NSString *spend = [[NSString alloc] initWithFormat:@"耗时%.2f秒",t];
            [FSToast show:spend];
        }
        count = 0;
        return;
    }    
    count ++;
}

- (FSDouyingLabel *)makeALabel{
    FSDouyingLabel *label = [[FSDouyingLabel alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, 30)];
    label.textColor = UIColor.whiteColor;
    [self.view addSubview:label];
    return label;
}

- (NSArray *)array{
    static NSArray *txts = nil;
    if (!txts) {
        txts = @[
                 @"静夜思",
                 @"李白",
                 @"床 前 明 月 光",
                 @"疑 是 地 上 霜",
                 @"举 头 望 明 月",
                 @"低 头 思 故 乡"
                 ];
    }
    return txts;
}

- (NSArray *)poets{
    static NSArray *poets = nil;
    if (!poets) {
        poets = @[
                  @"咏梨",
                  @"AI",
                  @"江南烟雨四月天 落寞梨花飞如雪",
                  @"春泥有意碾作尘 流水无心任漂零",
                  @"百花争胜尤芳艳 万种风情挑人厌",
                  @"但惜梨园少颜色 春情伤却良人泪",
                  ];
    }
    return poets;
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
