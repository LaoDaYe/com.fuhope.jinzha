//
//  FSDouyingLabel.m
//  myhome
//
//  Created by FudonFuchina on 2018/9/15.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSDouyingLabel.h"
#import <FSCalculator.h>
#import <FSKit.h>

@implementation FSDouyingLabel{
    NSString    *_txt;
    NSInteger   _count;
}

- (void)douyingShow:(NSString *)txt completion:(void (^)(void))completion{
    _txt = nil;
    if ([txt isKindOfClass:NSString.class] && txt.length) {
        _txt = txt;
    }
    [self repeatedlyDoing:completion];
}

- (void)repeatedlyDoing:(void (^)(void))completion{
    if (_txt.length >= _count) {
        if (_count == 0) {
            CGFloat sw = UIScreen.mainScreen.bounds.size.width;
            CGFloat w = [FSCalculator textWidth:_txt font:[UIFont systemFontOfSize:17] labelHeight:30];
            self.frame = CGRectMake(sw / 2 - w / 2, self.frame.origin.y, w, 30);
        }
        NSString *sub = [_txt substringToIndex:_count];
        self.text = sub;
    }else{
        _count = 0;
        if (completion) {
            completion();
        }
        return;
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.18 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self repeatedlyDoing:completion];
    });
    _count ++;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
