//
//  FSSearchController.m
//  FSSearchDemo
//
//  Created by fudon on 2017/1/16.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSSearchController.h"

@interface FSSearchController ()<UISearchResultsUpdating,UISearchControllerDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;

@end

@implementation FSSearchController

- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor = [UIColor whiteColor];
    
    [self searchDesignViews];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear: animated];
//    self.searchController.active = YES;
}

- (void)searchDesignViews{
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchResultsUpdater = self;
    self.searchController.delegate = self;
    self.searchController.dimsBackgroundDuringPresentation = false;
    [self.searchController.searchBar sizeToFit];
    self.searchController.searchBar.backgroundColor = [UIColor lightGrayColor];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    self.tableView.tableHeaderView = self.searchController.searchBar;
}

#pragma mark UISearchControllerDelegate
- (void)didPresentSearchController:(UISearchController *)searchController
{
//    searchController.active = YES;
//    [self.searchController.searchBar becomeFirstResponder];
//    [UIView animateWithDuration:0.3 animations:^{
//    } completion:nil];
}

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController
{
    NSString *text = searchController.searchBar.text;
    if (!text.length) {
//        if (!searchController.isActive) {
//            [self.navigationController popViewControllerAnimated:NO];
//        }
        return;
    }
    
    [self.filteredCities removeAllObjects];
    NSPredicate *searchPredicate = [NSPredicate predicateWithFormat:@"SELF CONTAINS[c] %@", self.searchController.searchBar.text];
    self.filteredCities = [[self.allCities filteredArrayUsingPredicate:searchPredicate] mutableCopy];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (!self.searchController.active) {
//        NSString *key = self.cityKeys[section];
//        NSArray *citySection = self.cityDict[key];
        return 10;
    } else {
        return self.filteredCities.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // 根据UISearchController的active属性来判断cell中的内容
    if (!self.searchController.active) {
//        NSString *key = self.cityKeys[indexPath.section];
//        cell.textLabel.text = [self.cityDict[key] objectAtIndex:indexPath.row];
        cell.textLabel.text = @"dddd";
    } else {
        cell.textLabel.text = self.filteredCities[indexPath.row];
    }
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
