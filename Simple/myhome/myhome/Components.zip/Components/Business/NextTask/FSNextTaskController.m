//
//  FSNextTaskController.m
//  myhome
//
//  Created by FudonFuchina on 2017/9/19.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSNextTaskController.h"
#import "FSShare.h"
#import <FSUIKit.h>
#import "FSMacro.h"

@interface FSNextTaskController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSNextTaskController{
    NSArray     *_list;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self taskHandleDatas];
}

- (void)taskHandleDatas{
    _list = @[@"新功能与反馈需求",@"优化和修复bug等",@"账本增强修改及优化",@"数据迁移，让文件可以移植",@"近场分享文件功能",@"文件多建功能，目前是单一文件",@"还有很多..."];
    [self taskDesignViews];
}

- (void)accountExplain{
    NSString *content = @"这些功能是下期开发的任务，不一定会在下期发版中全部开发完毕，可能会推迟到下下期，也可能取消。一切以实际情况和大众反馈的需求为准。";
    [FSUIKit showAlertWithMessage:content controller:self];
}

- (void)taskDesignViews{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    [button addTarget:self action:@selector(accountExplain) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = bbi;
    
    UITableView *tb = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64 - 44) style:UITableViewStylePlain];
    tb.delegate = self;
    tb.dataSource = self;
    tb.rowHeight = 50;
    tb.tableFooterView = [UIView new];
    tb.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tb];
    
    UIButton *next = [UIButton buttonWithType:UIButtonTypeSystem];
    next.frame = CGRectMake(0, HEIGHTFC - 44, WIDTHFC, 44);
    [next setTitle:NSLocalizedString(@"Feature requests", nil) forState:UIControlStateNormal];
    [next setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    next.backgroundColor = THISCOLOR;
    [next addTarget:self action:@selector(demandAsk) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:next];
}

- (void)demandAsk{
    [FSShare emailShareWithSubject:NSLocalizedString(@"Feature requests", nil) on:self messageBody:nil recipients:@[_feedback_Email]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSString *text = [_list objectAtIndex:indexPath.row];
    cell.textLabel.text = text;
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
