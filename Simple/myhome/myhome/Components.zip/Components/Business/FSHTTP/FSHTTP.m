//
//  FSHTTP.m
//  myhome
//
//  Created by fudon on 2017/6/8.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSHTTP.h"

@implementation FSHTTP

- (NSURLSessionTask *)requestByGETWithUrl:(NSString *)urlString success:(void(^)(id bData))success fail:(void(^)(NSString *bError))fail
{
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionTask *task = [session dataTaskWithURL:[NSURL URLWithString:urlString]
                                    completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                              {
                                  if (error) {
                                      if (fail) {
                                          fail(error.localizedDescription);
                                      }
                                  }else{
                                      id object = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
                                      if (success) {
                                          success(object);
                                      }
                                  }
                              }];
    [task resume];
    return task;
}

- (void)downloadFileWithUrl:(NSString *)urlString success:(void(^)(NSURL *bPath))success fail:(void(^)(NSString *bError))fail
{
    NSURLSession *session = [NSURLSession sharedSession];
//    NSURL *url = [NSURL URLWithString:@"http://www.daka.com/resources/image/icon.png"] ;
    NSURL *url = [[NSURL alloc] initWithString:urlString];
    
    NSURLSessionDownloadTask *task = [session downloadTaskWithURL:url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
        if (error) {
            if (fail) {
                fail(error.localizedDescription);
            }
        }else{
            if (success) {
                success(location);
            }
        }
      }];
    // 启动任务
    [task resume];
}

- (void)requestWithUrl:(NSString *)urlString params:(NSDictionary *)dic method:(FSHTTPMethod)method
{
    NSURL *url = [NSURL URLWithString:urlString];
    if (method == FSHTTPMethodGET) {
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionTask *task = [session dataTaskWithURL:url
                                        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                  {
                                      NSLog(@"%@", [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil]);
                                      
                                  }];
        [task resume];
    }else if (method == FSHTTPMethodPOST){
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        request.HTTPMethod = @"POST";
        request.HTTPBody = [@"username=daka&pwd=123" dataUsingEncoding:NSUTF8StringEncoding];
        
        NSURLSession *session = [NSURLSession sharedSession];
        // 由于要先对request先行处理,我们通过request初始化task
        NSURLSessionTask *task = [session dataTaskWithRequest:request
                                            completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                  {
                                      NSLog(@"%@", [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil]);
                                  }];
        [task resume];
    }
}

@end
