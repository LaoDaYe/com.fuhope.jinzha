//
//  FSSession.m
//  Expand
//
//  Created by Fudongdong on 2017/11/16.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSSession.h"
#import <FSKit.h>

@implementation FSSession

//    NSURL *url = [NSURL URLWithString:@"http://www.daka.com/login?username=daka&pwd=123"];
+ (NSURLSessionTask *)get:(NSString *)url completion:(void(^)(NSDictionary *bData,NSString *error))completion {
    if (!([url isKindOfClass:NSString.class] && url.length)) {
        return nil;
    }
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *URL = [NSURL URLWithString:url];
    if (!URL) {
        return nil;
    }
    NSURLSessionTask *task = [session dataTaskWithURL:URL completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if ([data isKindOfClass:NSData.class]) {
            NSString *st = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            NSString *str = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            NSDictionary *dic = [FSKit objectFromJSonstring:str];
            if (completion) {
                completion(dic,nil);
            }
        }else{
            if (completion) {
                completion(nil,error.localizedDescription);
            }
        }
    }];
    [task resume];
    return task;
}

@end
