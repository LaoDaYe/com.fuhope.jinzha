//
//  FSPwdAPI.m
//  myhome
//
//  Created by FudonFuchina on 2018/5/1.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSPwdAPI.h"
#import <FSDBMaster.h>
#import <FSTuple.h>
#import "FSMacro.h"
#import "FSCryptor.h"
#import "FSCryptorSupport.h"
#import "FSKeyValueCryptor.h"
#import "FSAppConfig.h"

@implementation FSPwdAPI

+ (NSString *)changeCorePasswordWithOld:(NSString *)old new:(NSString *)new{
    NSString *error = [self checkParamsForOldPassword:old newPassword:new];
    if (error) {
        return error;
    }
    
    // 第一部分，单独改这个key_value表
    NSString *now = [FSCryptorSupport md5:new];
    NSArray *cfgs = [FSKeyValueCryptor cryptorFields];
    if (!_fs_isValidateArray(cfgs)) {
        return nil;
    }
    for (NSString *key in cfgs) {
        NSString *error = [self updateCFGS:key new:now];
        if (error) {
            return error;
        }
    }

    // 第二部分，改表
    NSArray *tables = [self needChangeTables];
    if (!_fs_isValidateArray(tables)) {
        return nil;
    }
    NSString *ori = [FSCryptorSupport md5:old];
    for (Tuple2 *t in tables) {
        NSString *tb = t._1;
        NSArray *fields = t._2;
        NSString *error = [self changeCorePassword:tb fields:fields oldPwd:ori newPwd:now];
        if (error) {
            return error;
        }
    }
    
    return nil;
}

+ (NSString *)changeCorePasswordOnlyWithNewPwd:(NSString *)new{
    if (!([new isKindOfClass:NSString.class] && new.length >= 3)) {
        return @"新密码长度必须大于2位";
    }
    
    // 第一部分，单独改这个key_value表
    NSString *now = [FSCryptorSupport md5:new];
    NSString *ori = [FSCryptorSupport localUserDefaultsCorePassword];
    if ([ori isEqualToString:now]) {
        return @"新密码跟旧密码相同，不需要修改";
    }
    
    NSArray *cfgs = [FSKeyValueCryptor cryptorFields];
    if (!_fs_isValidateArray(cfgs)) {
        return nil;
    }
    
    for (NSString *key in cfgs) {
        NSString *error = [self updateCFGS:key new:now];
        if (error) {
            return error;
        }
    }

    // 第二部分，改表
    NSArray *tables = [self needChangeTables];
    if (!_fs_isValidateArray(tables)) {
        return nil;
    }
    
    for (Tuple2 *t in tables) {
        NSString *tb = t._1;
        NSArray *fields = t._2;
        NSString *error = [self changeCorePassword:tb fields:fields oldPwd:ori newPwd:now];
        if (error) {
            return error;
        }
    }

    return nil;
}

+ (NSString *)updateCFGS:(NSString *)key new:(NSString *)newMD5{
    NSString *text = [FSKeyValueCryptor objectForKey:key];
    if (!_fs_isValidateString(text)) {
        return nil;
    }
    NSString *miwen = [FSCryptor aes256EncryptString:text password:newMD5];
    if (miwen) {
        return [FSAppConfig saveObject:miwen forKey:key];
    }
    return nil;
}

+ (NSString *)checkParamsForOldPassword:(NSString *)oldA newPassword:(NSString *)newA{
    if (!_fs_isValidateString(oldA)) {
        return @"旧密码为空";
    }
    BOOL oldRight = [self checkOldPasswordCorrect:oldA];
    if (!oldRight) {
        return @"旧密码错误";
    }
    if (!_fs_isValidateString(newA)) {
        return @"新密码为空";
    }
    if (newA.length < 3) {
        return @"新密码小于3位";
    }
    return nil;
}

+ (NSString *)changeCorePassword:(NSString *)table fields:(NSArray<NSString *> *)fields oldPwd:(NSString *)ori newPwd:(NSString *)now{
    if (!_fs_isValidateString(table)) {
        return @"表名为空";
    }
    if (!_fs_isValidateArray(fields)) {
        return @"字段名为空";
    }
    
    FSDBMaster *master = [FSDBMaster sharedInstance];
    BOOL exist = [master checkTableExist:table];
    if (!exist) {
        return nil;
    }
    static NSString *_aid = @"aid";
    NSInteger page = 0;
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ limit 0,1;",table];
    NSArray *list = [master querySQL:sql tableName:table];
    while (_fs_isValidateArray(list)) {
        NSDictionary *m = list.firstObject;
        NSNumber *aid = [m objectForKey:_aid];
        if (!aid) {
            return @"aid为空";
        }
        for (NSString *f in fields) {
            NSString *dbString = [m objectForKey:f];
            NSString *write = [FSCryptor aes256DecryptString:dbString password:ori];
            if (write) {
                NSString *newString = [FSCryptor aes256EncryptString:write password:now];
                NSString *update = [[NSString alloc] initWithFormat:@"UPDATE %@ SET %@ = '%@' WHERE aid = %@;",table,f,newString,aid];
                NSString *error = [master updateSQL:update];
                if (error) {
                    NSString *msg = [[NSString alloc] initWithFormat:@"更新(%@)表第%@条数据(%@)字段失败：%@",table,@(page + 1),f,error];
                    return msg;
                }
            }
        }
        
        page ++;
        sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ limit %@,1;",table,@(page)];
        list = [master querySQL:sql tableName:table];
    }
    return nil;
}

+ (NSArray<Tuple2 *> *)needChangeTables{
    static NSArray *infos = nil;
    if (!infos) {
        infos = @[
                        [Tuple2 v1:_tb_contact v2:@[@"name",@"phone"]],
                        [Tuple2 v1:_tb_birth v2:@[@"name"]],
                        [Tuple2 v1:_tb_diary v2:@[@"content"]],
                        [Tuple2 v1:_tb_alert v2:@[@"content"]],
                        [Tuple2 v1:_tb_password v2:@[@"name",@"login",@"pwd",@"phone",@"mail",@"note"]],
                        [Tuple2 v1:_tb_card v2:@[@"card",@"note"]],
                        ];
    }
    return infos;
}

+ (BOOL)checkOldPasswordCorrect:(NSString *)old_A{
    NSString *db = [FSCryptorSupport theCorePasswordInSQLite];
    NSString *makeD = [FSCryptorSupport makeD:old_A];
    return [db isEqualToString:makeD];
}

+ (void)completionHandle:(NSString *)newA{
    [FSCryptorSupport userDefaultsCorePasswordForA:newA];
    [FSCryptorSupport insertCorePasswordIntoSQLite:newA];
    [FSCryptorSupport changeMemoryPassword:newA];
}

+ (NSString *)nowPwd{
    NSString *db = [FSCryptorSupport theCorePasswordInSQLite];
    if (db.length > 4) {
        NSString *sub = [db substringToIndex:3];
        return [[NSString alloc] initWithFormat:@"校验值尾数：%@",sub];
    }
    return nil;
}

@end
