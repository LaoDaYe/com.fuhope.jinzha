//
//  FSKeyValueCryptor.m
//  myhome
//
//  Created by FudonFuchina on 2018/5/5.
//  Copyright © 2018年 fuhope. All rights reserved.
//

/*
    说明：在修改核心密码的时候，需要修改
 */

#import "FSKeyValueCryptor.h"
#import "FSAppConfig.h"
#import "FSCryptorSupport.h"
#import <FSKit.h>

static NSString *_UDKey_gestureKey      = @"jinzha_gesture";        // 手势密码

@implementation FSKeyValueCryptor

+ (NSArray<NSString *> *)cryptorFields{
    return @[_UDKey_gestureKey];
}

+ (void)setGesturePassword:(NSString *)pwd{
    [self saveObject:pwd forKey:_UDKey_gestureKey];
}

+ (NSString *)gesturePassword{
    return [self objectForKey:_UDKey_gestureKey];
}

+ (void)removeGesture{
    [self removeObjectForKey:_UDKey_gestureKey];
}

+ (NSString *)saveObject:(NSString *)value forKey:(NSString *)key{
    if (!([value isKindOfClass:NSString.class] || [value isKindOfClass:NSNumber.class])) {
        return nil;
    }
    if (!_fs_isValidateString(key)) {
        return nil;
    }
    NSString *ciphertext = [FSCryptorSupport aes256EncryptString:value];
    return [FSAppConfig saveObject:ciphertext forKey:key];
}

+ (NSString *)objectForKey:(NSString *)key{
    NSString *ciphertext = [FSAppConfig objectForKey:key];
    NSString *text = [FSCryptorSupport aes256DecryptString:ciphertext];
    return text;
}

+ (void)removeObjectForKey:(NSString *)key{
    [FSAppConfig removeObjectForKey:key];
}

@end
