//
//  FSURLAPI.m
//  myhome
//
//  Created by FudonFuchina on 2018/8/26.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSURLAPI.h"
#import "FSMacro.h"
#import <FSTuple.h>

@implementation FSURLAPI

+ (void)initConfigForNewUsers:(void(^)(void))completion{
    _fs_dispatch_global_main_queue_async(^{
        _fs_userDefaultsOnce(@"firstTime_FSURLAPI", ^{
            NSArray *array = @[
                               [Tuple2 v1:@"百度" v2:@"https://www.baidu.com"],
                               [Tuple2 v1:@"京东" v2:@"https://www.jd.com"],
                               [Tuple2 v1:@"美团" v2:@"https://i.meituan.com"],
                               [Tuple2 v1:@"天猫" v2:@"https://www.tmall.com"],
                               [Tuple2 v1:@"淘宝" v2:@"https://www.taobao.com"],
                               [Tuple2 v1:@"好123" v2:@"https://www.hao123.com"],
                               [Tuple2 v1:@"腾讯新闻" v2:@"https://xw.qq.com"],
                               [Tuple2 v1:@"网易新闻" v2:@"https://3g.163.com"],
                               [Tuple2 v1:@"简书" v2:@"https://www.jianshu.com"],
                               [Tuple2 v1:@"优酷" v2:@"https://www.youku.com"],
                               [Tuple2 v1:@"腾讯视频" v2:@"https://m.v.qq.com"],
                               [Tuple2 v1:@"爱奇艺" v2:@"https://m.iqiyi.com"],
                               ];
            for (Tuple2 *t in array) {
                [FSURLAPI addUrl:t._1 url:t._2];
            }
        });
    }, ^{
        if (completion) {
            completion();
        }
    });
}

+ (NSString *)addUrl:(NSString *)name url:(NSString *)url{
    FSDBMaster *master = FSDBMaster.sharedInstance;
    NSString *error = [master insert_fields_values:@{
                                                     @"time":@(_fs_integerTimeIntevalSince1970()),
                                                     @"name":name,
                                                     @"url":url,
                                                     @"type":@"默认分类",
                                                     @"count":@0
                                                     } table:_tb_url];
    return error;
}

@end
