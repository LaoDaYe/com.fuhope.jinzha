//
//  FSABAPI.m
//  myhome
//
//  Created by FudonFuchina on 2018/4/30.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSABAPI.h"
#import "FSAccountConfiger.h"
#import "FSDBSupport.h"

@implementation FSABAPI

#pragma mark 流水
+ (NSMutableArray<FSABModel *> *)abFlowWithTable:(NSString *)tableName issSR:(BOOL)isSR page:(NSInteger)page start:(NSTimeInterval)start end:(NSTimeInterval)end{
    static NSString *sring = nil;
    if (sring == nil) {
        sring = [[NSString alloc] initWithFormat:@"%@%@",_subject_SR,_ING_KEY];
    }
    static NSString *sred = nil;
    if (sred == nil) {
        sred = [[NSString alloc] initWithFormat:@"%@%@",_subject_SR,_ED_KEY];
    }
    static NSString *cbing = nil;
    if (cbing == nil) {
        cbing = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ING_KEY];
    }
    static NSString *cbed = nil;
    if (cbed == nil) {
        cbed = [[NSString alloc] initWithFormat:@"%@%@",_subject_CB,_ED_KEY];
    }

    NSInteger unit = 30;
    //    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@') and cast(time as real) BETWEEN %@ AND %@ order by cast(time as real) DESC limit %@,%@;",_tableName,sring,sring,sred,sred,cbing,cbing,cbed,cbed,@(_start),@(_end),@(self.page * unit),@(unit)];
    NSString *sql = nil;
    if (isSR) {
        sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@') and cast(time as real) BETWEEN %@ AND %@ order by cast(time as real) DESC limit %@,%@;",tableName,sring,sring,sred,sred,@(start),@(end),@(page * unit),@(unit)];
    }else{
        sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (atype = '%@' OR btype = '%@' OR atype = '%@' OR btype = '%@') and cast(time as real) BETWEEN %@ AND %@ order by cast(time as real) DESC limit %@,%@;",tableName,cbing,cbing,cbed,cbed,@(start),@(end),@(page * unit),@(unit)];
    }
    NSMutableArray *array = [FSDBSupport querySQL:sql class:FSABModel.class tableName:tableName];
    for (FSABModel *model in array) {
        NSString *type = nil;
        if ([model.atype hasPrefix:_subject_SR] || [model.atype hasPrefix:_subject_CB]) {
            type = model.atype;
        }
        if ([model.btype hasPrefix:_subject_SR] || [model.btype hasPrefix:_subject_CB]) {
            type = model.btype;
        }
        [model processPropertiesWithType:type search:nil isCompany:NO];
    }
    return array;
}

@end
