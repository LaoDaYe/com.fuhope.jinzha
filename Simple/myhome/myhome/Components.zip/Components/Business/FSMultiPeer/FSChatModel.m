//
//  FSChatModel.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSChatModel.h"

@implementation FSChatModel

@end
