//
//  FSChatInputView.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSChatInputView.h"

@implementation FSChatInputView{
    UIButton    *_photo;
    UIButton    *_send;
    UITextView  *_textView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self chatDesignViews];
    }
    return self;
}

- (void)chatDesignViews{
    UIView *line = [[UIView alloc] init];
    line.translatesAutoresizingMaskIntoConstraints = NO;
    line.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:line];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[line]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(line)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[line(0.6)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(line)]];

    _photo = [UIButton buttonWithType:UIButtonTypeSystem];
    _photo.translatesAutoresizingMaskIntoConstraints = NO;
    _photo.tintColor = [UIColor lightGrayColor];
    [_photo setImage:[UIImage imageNamed:@"photo_chat"] forState:UIControlStateNormal];
    [_photo addTarget:self action:@selector(photoAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_photo];
    
    _textView = [[UITextView alloc] init];
    _textView.backgroundColor = [UIColor whiteColor];
    _textView.layer.cornerRadius = 10;
    _textView.layer.borderWidth = 0.6;
    _textView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _textView.font = [UIFont systemFontOfSize:14];
    _textView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_textView];
    
    _send = [UIButton buttonWithType:UIButtonTypeSystem];
    _send.translatesAutoresizingMaskIntoConstraints = NO;
    [_send setTitle:NSLocalizedString(@"Send", nil) forState:UIControlStateNormal];
    [_send addTarget:self action:@selector(sendAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_send];

    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_photo(66)]-0-[_textView]-0-[_send(66)]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_textView,_photo,_send)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_photo]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_photo)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_send]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_send)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-7-[_textView]-7-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_textView)]];
}

- (void)photoAction{
    if (self.photoCallback) {
        self.photoCallback();
    }
}

- (void)sendAction{
    if (self.sendMessage) {
        self.sendMessage(_textView.text);
    }
}

- (void)clearText{
    _textView.text = @"";
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
