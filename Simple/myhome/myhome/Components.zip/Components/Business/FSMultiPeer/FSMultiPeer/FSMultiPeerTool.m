//
//  FSMultiPeerTool.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSMultiPeerTool.h"

@implementation FSMultiPeerTool

+ (NSString *)deviceNameBytesShorterThan64Bytes{
    NSString *name = [UIDevice currentDevice].name;
    NSInteger length = [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    while (length > 63) {
        name = [name substringToIndex:name.length -2];
        length = [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    }
    return name;
}

+ (NSString *)multiPeerServiceType{
    static NSString *const _Jinzha_Chat = @"Jinzha-Chat";
    return _Jinzha_Chat;
}

+ (NSString *)session:(MCSession *)session sendObject:(NSDictionary *)from toUsers:(NSArray<NSString *> *)users withMode:(MCSessionSendDataMode)mode{
    if (![from isKindOfClass:NSDictionary.class]) {
        return @"数据不合法";
    }
    if (!([users isKindOfClass:NSArray.class] && users.count)) {
        return @"用户为空";
    }
    
    NSMutableArray *array = [self hanleUsers:users session:session];
    if (array.count == 0) {
        return @"用户已失去连接";
    }
    NSString *string = [FSKit jsonStringWithObject:from];
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    BOOL success = [session sendData:data toPeers:array withMode:mode error:&error];
    if (!success) {
        return error.localizedDescription;
    }
    return nil;
}

+ (Tuple2*)session:(MCSession *)session sendImageWithURL:(NSURL *)url toUsers:(NSString *)user withMode:(MCSessionSendDataMode)mode completion:(void(^)(NSError *error))completion{
    if (!([user isKindOfClass:NSString.class] && user.length)) {
        return [Tuple2 v1:nil v2:@"已失去连接"];
    }
    NSMutableArray *array = [self hanleUsers:@[user] session:session];
    if (array.count == 0) {
        return [Tuple2 v1:nil v2:@"已失去连接"];
    }
    MCPeerID *p = array.firstObject;
    NSString *name = [url.absoluteString lastPathComponent];
    NSProgress *process = [session sendResourceAtURL:url withName:name toPeer:p withCompletionHandler:^(NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) {
                completion(error);
            }
        });
    }];
    return [Tuple2 v1:process v2:nil];
}

+ (NSMutableArray *)hanleUsers:(NSArray<NSString *> *)users session:(MCSession *)session{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (MCPeerID *p in session.connectedPeers) {
        for (NSString *name in users) {
            if ([p.displayName isEqualToString:name]) {
                [array addObject:p];
            }
        }
    }
    return array;
}

@end
