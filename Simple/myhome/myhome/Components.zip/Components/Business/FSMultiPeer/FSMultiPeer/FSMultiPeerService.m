//
//  FSMultiPeerService.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSMultiPeerService.h"
#import <FSKit.h>
#import "FSToast.h"
#import "FSChatModel.h"
#import <FSUIKit.h>

@interface FSMultiPeerService ()<MCSessionDelegate,MCNearbyServiceAdvertiserDelegate>
@property (nonatomic,strong) NSMutableArray     *peers;

@end

@implementation FSMultiPeerService

- (void)dealloc{
    [_session disconnect];
    _session = nil;
    [_advertiser stopAdvertisingPeer];
    _advertiser = nil;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        [self serviceConfigs];
    }
    return self;
}

- (void)serviceConfigs{
    _peerID = [[MCPeerID alloc] initWithDisplayName:[FSMultiPeerTool deviceNameBytesShorterThan64Bytes]];
    _advertiser = [[MCNearbyServiceAdvertiser alloc] initWithPeer:_peerID
                                                                              discoveryInfo:nil
                                                                                serviceType:[FSMultiPeerTool multiPeerServiceType]];
    _advertiser.delegate = self;
    [_advertiser startAdvertisingPeer];
}

#pragma mark MCNearbyServiceAdvertiserDelegate
- (void)            advertiser:(MCNearbyServiceAdvertiser *)advertiser
  didReceiveInvitationFromPeer:(MCPeerID *)peerID
                   withContext:(nullable NSData *)context
             invitationHandler:(void (^)(BOOL accept, MCSession * __nullable session))invitationHandler{
    for (MCPeerID *p in self.session.connectedPeers) {
        if ([p.displayName isEqualToString:peerID.displayName]) {
            return;
        }
    }
    if (self.session.connectedPeers.count > 5) {
        invitationHandler(NO,_session);
        return;
    }
    if (!_session) {
        _session = [[MCSession alloc] initWithPeer:self.peerID
                                  securityIdentity:nil
                              encryptionPreference:MCEncryptionNone];
        _session.delegate = self;
    }
    NSString *alert = [[NSString alloc] initWithFormat:@"'%@' %@",peerID.displayName,NSLocalizedString(@"want to connect", nil)];
    [FSUIKit alertOnCustomWindow:UIAlertControllerStyleActionSheet title:alert message:nil actionTitles:@[NSLocalizedString(@"Allow", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        invitationHandler(YES,self->_session);
    } cancelTitle:@"Cancel" cancel:^(UIAlertAction *action) {
        invitationHandler(NO,self->_session);
    } completion:nil];
}

- (void)advertiser:(MCNearbyServiceAdvertiser *)advertiser didNotStartAdvertisingPeer:(NSError *)error{
    [advertiser stopAdvertisingPeer];
    dispatch_async(dispatch_get_main_queue(), ^{
        [FSUIKit showAlertWithMessageOnCustomWindow:error.localizedDescription];
    });
}

#pragma mark MCSessionDelegate
// Remote peer changed state.
- (void)session:(MCSession *)session peer:(MCPeerID *)peerID didChangeState:(MCSessionState)state{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.usersChanged) {
            self.usersChanged(self.session.connectedPeers);
        }
    });
}

// Received data from remote peer.
- (void)session:(MCSession *)session didReceiveData:(NSData *)data fromPeer:(MCPeerID *)peerID{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([data isKindOfClass:NSData.class]) {
            if (self.receivedData) {
                NSString *json = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                id value = [FSKit objectFromJSonstring:json];
                self.receivedData(value);
            }
        }
    });
}

// Start receiving a resource from remote peer.
- (void)                    session:(MCSession *)session
  didStartReceivingResourceWithName:(NSString *)resourceName
                           fromPeer:(MCPeerID *)peerID
                       withProgress:(NSProgress *)progress{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.receiveResource) {
            self.receiveResource(resourceName, peerID.displayName, progress);
        }
    });
}

// Finished receiving a resource from remote peer and saved the content
// in a temporary location - the app is responsible for moving the file
// to a permanent location within its sandbox.
- (void)                    session:(MCSession *)session
 didFinishReceivingResourceWithName:(NSString *)resourceName
                           fromPeer:(MCPeerID *)peerID
                              atURL:(nullable NSURL *)localURL
                          withError:(nullable NSError *)error{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.finishedResource) {
            self.finishedResource(resourceName, peerID.displayName, localURL, error);
        }        
    });
}

// Received a byte stream from remote peer.
- (void)    session:(MCSession *)session
   didReceiveStream:(NSInputStream *)stream
           withName:(NSString *)streamName
           fromPeer:(MCPeerID *)peerID{
    
}

// Made first contact with peer and have identity information about the
// remote peer (certificate may be nil).
- (void)        session:(MCSession *)session
  didReceiveCertificate:(nullable NSArray *)certificate
               fromPeer:(MCPeerID *)peerID
     certificateHandler:(void (^)(BOOL accept))certificateHandler{
    certificateHandler(YES);
}

@end
