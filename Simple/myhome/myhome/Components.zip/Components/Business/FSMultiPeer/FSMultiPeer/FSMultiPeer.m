//
//  FSMultiPeer.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSMultiPeer.h"

@implementation FSMultiPeer

static FSMultiPeer *_instance = nil;
+(FSMultiPeer *)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[FSMultiPeer alloc] init];
    });
    return _instance;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        [self baseConfigs];
    }
    return self;
}

- (void)baseConfigs{
    
}

@end
