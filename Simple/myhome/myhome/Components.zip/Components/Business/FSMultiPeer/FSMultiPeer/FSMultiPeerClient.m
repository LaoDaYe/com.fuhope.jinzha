//
//  FSMultiPeerClient.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSMultiPeerClient.h"
#import "FSMultiPeerTool.h"
#import <FSKit.h>
#import "FSToast.h"
#import <FSUIKit.h>

@interface FSMultiPeerClient ()<MCNearbyServiceBrowserDelegate,MCSessionDelegate>
@property (nonatomic,strong) NSMutableArray     *peers;
@property (nonatomic,copy) void (^connectReslut)(BOOL result);
@end

@implementation FSMultiPeerClient

- (void)dealloc{
    [_session disconnect];
    _session = nil;
    [_browser stopBrowsingForPeers];
    _browser = nil;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        [self clientConfigs];
    }
    return self;
}

- (void)clientConfigs{
    _peerID = [[MCPeerID alloc] initWithDisplayName:[FSMultiPeerTool deviceNameBytesShorterThan64Bytes]];
    _browser = [[MCNearbyServiceBrowser alloc] initWithPeer:_peerID serviceType:[FSMultiPeerTool multiPeerServiceType]];
    _browser.delegate = self;
    [_browser startBrowsingForPeers];
}

- (void)connectToPeerID:(MCPeerID *)peerID completion:(void(^)(BOOL connected))completion{
    if (!self.connectReslut) {
        self.connectReslut = completion;
    }
    if (!_session) {
        _session = [[MCSession alloc] initWithPeer:_peerID securityIdentity:nil encryptionPreference:MCEncryptionNone];
        _session.delegate = self;
    }
    for (MCPeerID *p in _session.connectedPeers) {
        if ([p.displayName isEqualToString:peerID.displayName]) {
            if (self.connectReslut) {
                self.connectReslut(YES);
                return;
            }
        }
    }
    [_browser invitePeer:peerID toSession:_session withContext:nil timeout:10];
}

#pragma mark MCNearbyServiceBrowserDelegate
- (void)        browser:(MCNearbyServiceBrowser *)browser
              foundPeer:(MCPeerID *)peerID
      withDiscoveryInfo:(nullable NSDictionary<NSString *, NSString *> *)info{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([peerID.displayName isEqualToString:[FSMultiPeerTool deviceNameBytesShorterThan64Bytes]]) {
            if (self.tips) {
                self.tips(NSLocalizedString(@"Searching...", nil));
            }
            return;
        }
        if (self.findAFriend) {
            self.findAFriend(peerID);
        }
    });
}

// A nearby peer has stopped advertising.
- (void)browser:(MCNearbyServiceBrowser *)browser lostPeer:(MCPeerID *)peerID{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.loseAFriend) {
            self.loseAFriend(peerID);
        }
        NSString *message = [[NSString alloc] initWithFormat:@"'%@' %@",peerID.displayName,NSLocalizedString(@"Leaved", nil)];
        [FSToast show:message];
        [self->_session cancelConnectPeer:peerID];
    });
}

// Browsing did not start due to an error.
- (void)browser:(MCNearbyServiceBrowser *)browser didNotStartBrowsingForPeers:(NSError *)error{
    [browser stopBrowsingForPeers];
    dispatch_async(dispatch_get_main_queue(), ^{
        [FSUIKit showAlertWithMessageOnCustomWindow:error.localizedDescription];
    });
}

#pragma mark MCSessionDelegate
// Remote peer changed state.
- (void)session:(MCSession *)session peer:(MCPeerID *)peerID didChangeState:(MCSessionState)state{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.connectReslut) {
            self.connectReslut(state == MCSessionStateConnected);
        }
    });
}

- (void)session:(MCSession *)session didReceiveData:(NSData *)data fromPeer:(MCPeerID *)peerID{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([data isKindOfClass:NSData.class]) {
            if (self.receivedData) {
                NSString *json = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                id value = [FSKit objectFromJSonstring:json];
                self.receivedData(value);
            }
        }
    });
}

// Start receiving a resource from remote peer.
- (void)                    session:(MCSession *)session
  didStartReceivingResourceWithName:(NSString *)resourceName
                           fromPeer:(MCPeerID *)peerID
                       withProgress:(NSProgress *)progress{
}

// Finished receiving a resource from remote peer and saved the content
// in a temporary location - the app is responsible for moving the file
// to a permanent location within its sandbox.
- (void)                    session:(MCSession *)session
 didFinishReceivingResourceWithName:(NSString *)resourceName
                           fromPeer:(MCPeerID *)peerID
                              atURL:(nullable NSURL *)localURL
                          withError:(nullable NSError *)error{
}

// Received a byte stream from remote peer.
- (void)    session:(MCSession *)session
   didReceiveStream:(NSInputStream *)stream
           withName:(NSString *)streamName
           fromPeer:(MCPeerID *)peerID{
    
}

// Made first contact with peer and have identity information about the
// remote peer (certificate may be nil).
- (void)        session:(MCSession *)session
  didReceiveCertificate:(nullable NSArray *)certificate
               fromPeer:(MCPeerID *)peerID
     certificateHandler:(void (^)(BOOL accept))certificateHandler{
    certificateHandler(YES);
}

@end
