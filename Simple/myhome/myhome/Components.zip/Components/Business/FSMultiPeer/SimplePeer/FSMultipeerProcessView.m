//
//  FSMultipeerProcessView.m
//  Expand
//
//  Created by Fudongdong on 2017/10/24.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSMultipeerProcessView.h"

@implementation FSMultipeerProcessView{
    UIProgressView  *_progressView;
    UILabel         *_name;
    UILabel         *_file;
    UIButton        *_button;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self processDesignViews];
    }
    return self;
}

- (void)processDesignViews{
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
    effectView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:effectView];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[effectView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(effectView)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[effectView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(effectView)]];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [effectView addGestureRecognizer:tap];
    
    _name = [[UILabel alloc] init];
    _name.translatesAutoresizingMaskIntoConstraints = NO;
    _name.textColor = [UIColor whiteColor];
    _name.textAlignment = NSTextAlignmentCenter;
    _name.text = @"John";
    _name.font = [UIFont boldSystemFontOfSize:16];
    [self addSubview:_name];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_name]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_name)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-100-[_name(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_name)]];
    
    _file = [[UILabel alloc] init];
    _file.translatesAutoresizingMaskIntoConstraints = NO;
    _file.textColor = [UIColor whiteColor];
    _file.textAlignment = NSTextAlignmentCenter;
    _file.text = @"John";
    _file.font = [UIFont systemFontOfSize:14];
    [self addSubview:_file];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_file]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_file)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[_name]-0-[_file(20)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_file,_name)]];

    _progressView = [[UIProgressView alloc] init];
    _progressView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_progressView];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_progressView]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_progressView)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[_file]-60-[_progressView(3)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_progressView,_file)]];
    
    _button = [UIButton buttonWithType:UIButtonTypeSystem];
    _button.translatesAutoresizingMaskIntoConstraints = NO;
    [_button setTitle:@"确定" forState:UIControlStateNormal];
    [_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _button.backgroundColor = [UIColor lightGrayColor];
    _button.enabled = NO;
    [self addSubview:_button];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_button]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[_progressView]-60-[_button(44)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_button,_progressView)]];
}

- (void)setName:(NSString *)name{
    _name.text = name;
}

- (void)setFile:(NSString *)file{
    _file.text = file;
}

- (void)setProcess:(CGFloat)process{
    _progressView.progress = process;
    if (process == 1.0) {
        _button.enabled = YES;
        _button.backgroundColor = [UIColor colorWithRed:0x1d/255.0 green:0x9c/255.0 blue:0xe1/255.0 alpha:1.0];
    }
}

- (void)tapAction{
    if (self.tapCallback) {
        self.tapCallback(self);
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
