//
//  FSTransferDatabaseController.m
//  myhome
//
//  Created by FudonFuchina on 2017/11/5.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSTransferDatabaseController.h"
#import "FSMultiPeerClient.h"
#import "FSDBMaster.h"
#import <FSUIKit.h>
#import "FSMacro.h"

@interface FSTransferDatabaseController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSTransferDatabaseController{
    FSMultiPeerClient          *_peerClient;
    UITableView                *_tableView;
    NSMutableArray             *_users;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Search devices", nil);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(popAction) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    if (!_users) {
        _users = [[NSMutableArray alloc] init];
    }
    [self mpHandleDatas];
    
    [self showTip];
}

- (void)popAction{
    [self.navigationController popToRootViewControllerAnimated:NO];
}

- (void)mpHandleDatas{
    __weak typeof(self)this = self;
    _peerClient = [[FSMultiPeerClient alloc] init];
    _peerClient.tips = ^(NSString *str) {
        this.title = str;
    };
    _peerClient.findAFriend = ^(MCPeerID *user) {
        [this addAFriend:user];
    };
    _peerClient.loseAFriend = ^(MCPeerID *users) {
        [this loseAFriend:users];
    };
}

- (void)addAFriend:(MCPeerID *)user{
    BOOL contain = NO;
    for (MCPeerID *p in _users) {
        if ([p.displayName isEqualToString:user.displayName]) {
            contain = YES;
        }
    }
    if (!contain) {
        [_users insertObject:user atIndex:0];
    }
    [self mpDesignViews];
}

- (void)loseAFriend:(MCPeerID *)peer{
    NSMutableArray *lost = [[NSMutableArray alloc] init];
    for (MCPeerID *p in _users) {
        if ([p.displayName isEqualToString:peer.displayName]) {
            [lost addObject:p];
        }
    }
    [_users removeObjectsInArray:lost];
    [self mpDesignViews];
}

- (void)mpDesignViews{
    if (!_tableView) {
//        [FSTrack event:_UMeng_Event_transfer_page];
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 60;
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
    }else{
        [_tableView reloadData];
    }
}

- (void)showTip{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, HEIGHTFC, WIDTHFC, 50)];
    view.backgroundColor = FSAPPCOLOR;
    [self.view addSubview:view];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, WIDTHFC - 20, 50)];
    label.font = [UIFont systemFontOfSize:14];
    label.text = NSLocalizedString(@"Transfer database message", nil);
    label.textColor = UIColor.whiteColor;
    label.numberOfLines = 0;
    [view addSubview:label];
    
    [UIView animateWithDuration:1 animations:^{
        view.top = HEIGHTFC - 50 - FS_iPhone_X * 34;
    } completion:^(BOOL finished) {
        if (finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIView animateWithDuration:.5 animations:^{
                    view.top = HEIGHTFC;
                } completion:^(BOOL finished) {
                    if (finished) {
                        [view removeFromSuperview];
                    }
                }];
            });
        }
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _users.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    MCPeerID *p = [_users objectAtIndex:indexPath.row];
    cell.textLabel.text = p.displayName;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (_peerClient.session.connectedPeers.count > 5) {
        [FSUIKit showAlertWithMessage:NSLocalizedString(@"The connection is full", nil) controller:self];
        return;
    }
    
    MCPeerID *p = [_users objectAtIndex:indexPath.row];
    __weak typeof(self)this = self;
    self.title = [[NSString alloc] initWithFormat:@"%@'%@'",NSLocalizedString(@"Connect", nil),p.displayName];
    [_peerClient connectToPeerID:p completion:^(BOOL connected) {
        if (connected) {
            this.title = NSLocalizedString(@"Search devices", nil);
            [this pushToChatPage:p from:NO];
        }else{
            this.title = NSLocalizedString(@"Connect...", nil);
        }
    }];
}

- (void)pushToChatPage:(MCPeerID *)p from:(BOOL)service{
    NSString *title = [[NSString alloc] initWithFormat:@"%@'%@',%@?",NSLocalizedString(@"Connected", nil),p.displayName,NSLocalizedString(@"Send the database", nil)];
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:title message:nil actionTitles:@[NSLocalizedString(@"Send", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        [self sendFile:p];
    }];
}

- (void)sendFile:(MCPeerID *)p{
    NSString *path = [[FSDBMaster sharedInstance] dbPath];
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:path]){
        [FSToast show:NSLocalizedString(@"No data", nil)];
        return;
    }
    NSURL *url = [NSURL fileURLWithPath:path];
    Tuple2 *t = [FSMultiPeerTool session:_peerClient.session sendImageWithURL:url toUsers:p.displayName withMode:MCSessionSendDataReliable completion:^(NSError *error) {
        if (error) {
            [FSUIKit showAlertWithMessage:error.localizedDescription controller:self];
        }else{
            [FSUIKit showAlertWithMessage:NSLocalizedString(@"Send complete", nil) controller:self ];
        }
    }];
    NSString *error = t._2;
    if (error) {
        [FSToast show:error];
        return;
    }
    NSProgress *process = t._1;
    [self listenProcess:process];
}

- (void)listenProcess:(NSProgress *)p{
    if (p.completedUnitCount == p.totalUnitCount) {
        self.title = NSLocalizedString(@"Send complete", nil);
        return;
    }
    CGFloat process = p.completedUnitCount * 1.00 / p.totalUnitCount;
    NSString *title = [[NSString alloc] initWithFormat:@"%.2f%%",process * 100];
    self.title = title;
    __weak typeof(self)this = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [this listenProcess:p];
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
