//
//  FSMultiPeerController.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSMultiPeerController.h"
#import "FSMultiPeerService.h"
#import "FSMultiPeerClient.h"
#import "FSChatViewController.h"
#import "FSMultipeerProcessView.h"
#import <FSUIKit.h>
#import "FSToast.h"
#import "FuSoft.h"

@interface FSMultiPeerController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSMultiPeerController{
    FSMultiPeerService         *_peerService;
    FSMultiPeerClient          *_peerClient;
    UITableView                *_tableView;
    NSMutableArray             *_users;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (!_users) {
        _users = [[NSMutableArray alloc] init];
    }
    [self mpHandleDatas];
}

- (void)mpHandleDatas{
    __weak typeof(self)this = self;
    _peerService = [[FSMultiPeerService alloc] init];
//    _peerService.usersChanged = ^(NSArray<MCPeerID *> *users) {
//        [this handleUsers:users];
//    };
    _peerService.receivedData = ^(id bData) {
        [this receivedData:bData];
    };
    
    _peerClient = [[FSMultiPeerClient alloc] init];
//    _peerClient.usersChanged = ^(NSArray<MCPeerID *> *users) {
//        [this handleUsers:users];
//    };
    _peerClient.tips = ^(NSString *str) {
        this.title = str;
    };
    _peerClient.findAFriend = ^(MCPeerID *user) {
        [this addAFriend:user];
    };
    _peerClient.loseAFriend = ^(MCPeerID *users) {
        [this loseAFriend:users];
    };
    _peerClient.receivedData = ^(id bData) {
        [this receivedData:bData];
    };
}

- (void)receivedData:(id)bData{
    NSDictionary *dic = bData;
    NSString *type = [dic objectForKey:_send_type];
    if ([type isKindOfClass:NSString.class] && [type isEqualToString:@"image"]) {// 图片
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:@"收到图片，是否存入相册？" message:nil actionTitles:@[@"存入"] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            NSString *base64 = dic[@"data"];
            NSData *data = [[NSData alloc]initWithBase64EncodedString:base64 options:(NSDataBase64DecodingIgnoreUnknownCharacters)];
            UIImage *image = [[UIImage alloc] initWithData:data];
            if (image) {
                UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
            }
        }];
    }else{
        [FSToast show:dic[@"content"]];
    }
}

- (void)addAFriend:(MCPeerID *)user{
    BOOL contain = NO;
    for (MCPeerID *p in _users) {
        if ([p.displayName isEqualToString:user.displayName]) {
            contain = YES;
        }
    }
    if (!contain) {
        [_users insertObject:user atIndex:0];
    }
    [self mpDesignViews];
}

- (void)loseAFriend:(MCPeerID *)peer{
    NSMutableArray *lost = [[NSMutableArray alloc] init];
    for (MCPeerID *p in _users) {
        if ([p.displayName isEqualToString:peer.displayName]) {
            [lost addObject:p];
        }
    }
    [_users removeObjectsInArray:lost];
    [self mpDesignViews];
}

- (void)mpDesignViews{
    if (!_tableView) {
        self.title = @"附近的人";
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 60;
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
    }else{
        [_tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _users.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    MCPeerID *p = [_users objectAtIndex:indexPath.row];
    cell.textLabel.text = p.displayName;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ((_peerService.session.connectedPeers.count + _peerClient.session.connectedPeers.count) > 5) {
        [FSUIKit showAlertWithMessage:@"连接人数已满" controller:self];
        return;
    }
    
    MCPeerID *p = [_users objectAtIndex:indexPath.row];
    for (MCPeerID *ps in _peerService.session.connectedPeers) {
        if ([p.displayName isEqualToString:ps.displayName]) {
            [self pushToChatPage:p from:YES];
            return;
        }
    }
    __weak typeof(self)this = self;
    self.title = [[NSString alloc] initWithFormat:@"连接'%@'",p.displayName];
    [_peerClient connectToPeerID:p completion:^(BOOL connected) {
        this.title = @"附近的人";
        if (connected) {
            [this pushToChatPage:p from:NO];
        }
    }];
}

- (void)pushToChatPage:(MCPeerID *)p from:(BOOL)service{
    FSChatViewController *c = [[FSChatViewController alloc] init];
    c.title = p.displayName;
    [self.navigationController pushViewController:c animated:YES];
    __weak typeof(self)this = self;
    c.sendDataBlock = ^(NSString *str) {
        NSString *error = nil;
        if (service) {
            error = [FSMultiPeerTool session:self->_peerService.session sendObject:@{@"content":str} toUsers:@[p.displayName] withMode:MCSessionSendDataReliable];
        }else{
            error = [FSMultiPeerTool session:self->_peerClient.session sendObject:@{@"content":str} toUsers:@[p.displayName] withMode:MCSessionSendDataReliable];
        }
        if (error) {
            [FSUIKit showAlertWithMessage:error controller:this];
        }
    };
    c.sendImage = ^(NSURL *url) {
        if (service) {
            Tuple2 *t = [FSMultiPeerTool session:self->_peerService.session sendImageWithURL:url toUsers:p.displayName withMode:MCSessionSendDataReliable completion:^(NSError *error) {
                if (error) {
                    [FSUIKit showAlertWithMessage:error.localizedDescription controller:this];
                }else{
                    [FSUIKit showAlertWithMessage:@"发送成功" controller:this];
                }
            }];
            NSString *error = t._2;
            if (error) {
                [FSToast show:error];
            }
            NSProgress *process = t._1;
            [self listenProcess:process];
        }else{
            Tuple2 *t = [FSMultiPeerTool session:self->_peerClient.session sendImageWithURL:url toUsers:p.displayName withMode:MCSessionSendDataReliable completion:^(NSError *error) {
                if (error) {
                    [FSUIKit showAlertWithMessage:error.localizedDescription controller:this];
                }else{
                    [FSUIKit showAlertWithMessage:@"发送完成" controller:this];
                }
            }];
            NSString *error = t._2;
            if (error) {
                [FSToast show:error];
            }
            NSProgress *process = t._1;
            [self listenProcess:process];
        }
    };
}

- (void)listenProcess:(NSProgress *)p{
//    if (p.completedUnitCount == p.totalUnitCount) {
//        return;
//    }
    CGFloat process = p.completedUnitCount * 1.00 / p.totalUnitCount;
    self.title = @(process).stringValue;
    
    FSMultipeerProcessView *pView = [[FSMultipeerProcessView alloc] initWithFrame:self.view.bounds];
    [pView setName:@"测试"];
    [pView setFile:@"文件"];
    [pView setProcess:process];
    [self.view addSubview:pView];
    __weak typeof(self)this = self;
    pView.tapCallback = ^(FSMultipeerProcessView *view) {
        this.title = @"发送完成";
        [view removeFromSuperview];
    };
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self listenProcess:p];
//    });
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *) error contextInfo:(void *)contextInfo{
    if (error) {
        [FSToast show:error.localizedDescription];
    }else{
        [FSToast show:@"已保存到相册"];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
