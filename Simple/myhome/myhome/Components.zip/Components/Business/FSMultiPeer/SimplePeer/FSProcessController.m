

//
//  FSProcessController.m
//  Expand
//
//  Created by Fudongdong on 2017/10/24.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSProcessController.h"
#import <FSKit.h>
#import <FuSoft.h>
#import <FSTuple.h>
#import "FSMultiPeerService.h"
#import "FSChatTextCell.h"
#import "FSChatFileCell.h"
#import "FSChatImageCell.h"
#import "FSChatProcessCell.h"
#import "FSChatImageController.h"
#import <FSDate.h>
#import <FSUIKit.h>
#import <FSCalculator.h>

@interface FSProcessModel : NSObject

@property (nonatomic,copy) NSString   *content;    // 文件内容或链接
@property (nonatomic,copy) NSString   *from;       // 发送者
@property (nonatomic,assign) NSInteger type;       // 类型  0：文字，1.图片，2.文件
@property (nonatomic,strong) id       progress;    // 进程对象
@property (nonatomic,assign)CGFloat   cellHeight;  // 文字：文字内容+50
@property (nonatomic,copy) NSString   *time;       // 发来的时间

@property (nonatomic,copy) NSString   *fileName;    // 文件名字
@property (nonatomic,strong) NSURL    *url;         // 文件在本地的路径


+ (FSProcessModel *)modelWithDictionary:(NSDictionary *)dictionary;

@end

@implementation FSProcessModel

+ (FSProcessModel *)modelWithDictionary:(NSDictionary *)dictionary{
    FSProcessModel *m = [[FSProcessModel alloc] init];
    m.content = dictionary[@"content"];
    m.from = dictionary[@"from"];
    m.type = [dictionary[@"type"] integerValue];
    return m;
}

@end

@interface FSProcessController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) FSMultiPeerService *service;
@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) NSMutableArray *list;

@end

@implementation FSProcessController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configService];
    [self processDesignViews];
}

- (void)configService{
    self.list = [[NSMutableArray alloc] init];
    _service = [[FSMultiPeerService alloc] init];
    WEAKSELF(this);
    _service.receivedData = ^(id bData) {
        [this receivedData:bData];
    };
    _service.receiveResource = ^(NSString *rName, NSString *from, NSProgress *p) {
        FSProcessModel *model = [[FSProcessModel alloc] init];
        model.content = @"给您发来一张图片";
        model.from = from;
        model.fileName = rName;
        model.time = [FSDate stringWithDate:[NSDate date] formatter:nil];
        model.type = 3;
        model.progress = p;
        model.cellHeight = 80;
        [this addData:model atIndex:0];
    };
    _service.finishedResource = ^(NSString *rName, NSString *from, NSURL *local, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                [FSUIKit showAlertWithMessage:error.localizedDescription controller:this];return;
            }
            for (FSProcessModel *model in this.list) {
                if ([from isEqualToString:model.from] && [model.fileName isEqualToString:rName]) {
                    model.url = local;
                }
                [this regetData];
            }
        });
    };
}

- (void)receivedData:(id)bData{
    NSDictionary *dic = bData;
    NSString *type = [dic objectForKey:_send_type];
    if ([type isKindOfClass:NSString.class] && [type isEqualToString:@"image"]) {// 图片
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:@"收到图片，是否存入相册？" message:nil actionTitles:@[@"存入"] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            NSString *base64 = dic[@"data"];
            NSData *data = [[NSData alloc]initWithBase64EncodedString:base64 options:(NSDataBase64DecodingIgnoreUnknownCharacters)];
            UIImage *image = [[UIImage alloc] initWithData:data];
            if (image) {
                UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:),NULL);
            }
        }];
    }else{
        NSString *str = dic[@"content"];
        if (![str isKindOfClass:NSString.class]) {
            return;
        }
        NSDictionary *value = @{@"content":str,@"from":dic[@"from"]?:@"猜猜我是谁",@"type":@"0"};
        FSProcessModel *model = [FSProcessModel modelWithDictionary:value];
        CGFloat height = [FSCalculator textHeight:str font:FONTFC(14) labelWidth:WIDTHFC - 45];
        model.cellHeight = MAX(30, height) + 50;
        [self addData:model atIndex:0];
    }
}

- (void)bbiAction{
    NSString *content = @"给您发送了一张图片";
    FSProcessModel *model = [[FSProcessModel alloc] init];
    model.content = content;
    model.from = @"xxx";
    model.type = 3;
    model.cellHeight = 70;
    [self addData:model atIndex:0];
}

- (void)processDesignViews{
    if (!_tableView) {
        self.title = @"等待接收";
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(bbiAction)];
        self.navigationItem.rightBarButtonItem = bbi;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
    }
}

- (void)regetData{
    dispatch_async(dispatch_get_main_queue(), ^{
        for (FSProcessModel *model in self.list) {
            if ([model.progress isKindOfClass:NSProgress.class]) {
                [self updateData:model];
                NSProgress *p = model.progress;
                if (p.totalUnitCount > p.completedUnitCount) {
                    __weak typeof(self)this = self;
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [this regetData];
                    });
                }
            }
        }
    });
}

- (void)addData:(FSProcessModel *)model atIndex:(NSInteger)index{
    if (![model isKindOfClass:FSProcessModel.class]) {
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.list insertObject:model atIndex:index];
        NSIndexPath *ip = [NSIndexPath indexPathForRow:index inSection:0];
        if (ip) {
            NSArray *ips = [NSArray arrayWithObjects:ip,nil];
            [self.tableView insertRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationNone];
        }
    });
}

- (void)updateData:(FSProcessModel *)model{
    dispatch_async(dispatch_get_main_queue(), ^{
        for (FSProcessModel *t in self.list) {
            if ([t.from isEqualToString:model.from]) {
                NSInteger index = [self.list indexOfObject:t];
                if (index != NSNotFound) {
                    NSIndexPath *p = [NSIndexPath indexPathForRow:index inSection:0];
                    [UIView performWithoutAnimation:^{
                        [self.tableView reloadRowsAtIndexPaths:@[p] withRowAnimation:UITableViewRowAnimationNone];
                    }];
                }
            }
        }
    });
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSProcessModel *t = self.list[indexPath.row];
    if (t.type == 0) {
        static NSString *identifier = @"cell";
        FSChatTextCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[FSChatTextCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        }
        [cell setName:t.from];
        [cell setContent:t.content];
        [cell setTime: [FSDate stringWithDate:[NSDate date] formatter:nil]];
        return cell;
    }else if (t.type == 1){
        static NSString *identifier = @"image";
        FSChatImageCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[FSChatImageCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        }
        return cell;
    }else if (t.type == 2){
        static NSString *identifier = @"file";
        FSChatFileCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[FSChatFileCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        }
        return cell;
    }else if (t.type == 3){
        static NSString *identifier = @"process";
        FSChatProcessCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[FSChatProcessCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        }
        [cell setName:t.from];
        [cell setContent:t.content];
        [cell setTime:t.time];
        NSProgress *p = t.progress;
        NSString *process = nil;
        if (p.completedUnitCount == p.totalUnitCount) {
            process = @"查看";
        }else{
            process = [[NSString alloc] initWithFormat:@"%.2f%%",p.completedUnitCount * 100.0 / p.totalUnitCount];
        }
        [cell setProcess:process];
        return cell;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    FSProcessModel *t = self.list[indexPath.row];
    return t.cellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    // TODO:拿到本地地址，判断如果是图片就显示，如果是文件就推到新页面根据类型选择打开
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    FSProcessModel *t = self.list[indexPath.row];
    if (t.type == 0) {
        
    }else if (t.type == 3){
        NSString *see = @"查看";
        NSString *save = @"存入相册";
        [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:@"操作方式" message:nil actionTitles:@[see,save] styles:@[@(UIAlertActionStyleDefault),@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            if ([action.title isEqualToString:see]) {
                FSChatImageController *imageController = [[FSChatImageController alloc] init];
                imageController.url = t.url;
                [self.navigationController pushViewController:imageController animated:YES];                
            }else if ([action.title isEqualToString:save]){
                UIImage *image = [FSChatImageController imageWithURL:t.url];
                if (image) {
                    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:),NULL);
                }
            }
        }];
        
    }
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *) error contextInfo:(void *)contextInfo{
    if (error) {
        [FSUIKit showAlertWithMessage:error.localizedDescription controller:self];
    }else{
        [FSUIKit showAlertWithMessage:@"已保存到相册" controller:self];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
