//
//  FSChatFileCell.h
//  myhome
//
//  Created by FudonFuchina on 2017/10/28.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSChatFileCell : UITableViewCell

- (void)setName:(NSString *)name;
- (void)setTime:(NSString *)time;

@end
