//
//  FSPeersController.h
//  myhome
//
//  Created by FudonFuchina on 2017/10/24.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSPeersController : FSBaseController

@end
