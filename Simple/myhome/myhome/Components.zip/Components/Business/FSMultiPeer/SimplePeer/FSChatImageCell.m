//
//  FSChatImageCell.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/28.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSChatImageCell.h"

@implementation FSChatImageCell{
    UILabel     *_nameLabel;
    UILabel     *_time;
    UIImageView *_image;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self imageDesignViews];
    }
    return self;
}

- (void)imageDesignViews{
    self.backgroundColor = [UIColor clearColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    _nameLabel = [[UILabel alloc] init];
    _nameLabel.font = [UIFont systemFontOfSize:14];
    _nameLabel.textColor = [UIColor grayColor];
    _nameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_nameLabel];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_nameLabel]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_nameLabel)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_nameLabel(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_nameLabel)]];
    
    _time = [[UILabel alloc] init];
    _time.font = [UIFont systemFontOfSize:14];
    _time.textColor = [UIColor grayColor];
    _time.textAlignment = NSTextAlignmentRight;
    _time.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_time];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_time(150)]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_time)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_time(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_time)]];
    
    _image = [[UIImageView alloc] init];
    _image.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_image];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_image(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_image)]];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
