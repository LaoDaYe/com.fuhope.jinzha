//
//  FSReceiveDatabaseController.m
//  myhome
//
//  Created by FudonFuchina on 2017/11/5.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSReceiveDatabaseController.h"
#import "FSMultiPeerService.h"
#import "FSDBMaster.h"
#import <FSUIKit.h>
#import "FSMacro.h"
#import "FSTrackKeys.h"

@interface FSReceiveDatabaseController ()

@property (nonatomic,strong) FSMultiPeerService     *service;
@property (nonatomic,strong) UIButton               *button;
@property (nonatomic,strong) NSURL                  *url;

@end

@implementation FSReceiveDatabaseController

- (void)viewDidLoad {
    [super viewDidLoad];
    [FSTrack event:_UMeng_Event_receive_page];
    [self configService];
    [self processDesignViews];
}

- (void)configService{
    _service = [[FSMultiPeerService alloc] init];
    WEAKSELF(this);
    _service.receiveResource = ^(NSString *rName, NSString *from, NSProgress *p) {
        this.url = nil;
        [this listenProgress:p];
    };
    _service.finishedResource = ^(NSString *rName, NSString *from, NSURL *local, NSError *error) {
        [this.button setTitle:@"100.00%" forState:UIControlStateNormal];
        [this handleURL:local error:error];
    };
}

- (void)handleURL:(NSURL *)local error:(NSError *)error{
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:NSLocalizedString(@"File received complete and does it cover the local database?", nil) message:nil actionTitles:@[NSLocalizedString(@"Cover", nil)] styles:@[@(UIAlertActionStyleDestructive)] handler:^(UIAlertAction *action) {
        NSData *data = [[NSData alloc] initWithContentsOfURL:local];
        if (!data) {
            [FSUIKit showAlertWithMessage:NSLocalizedString(@"Receive file failed", nil) controller:self];
            return;
        }
        FSDBMaster *master = [FSDBMaster sharedInstance];
        NSString *target = [master dbPathWithFileName:_db_first_name];
        BOOL success = [data writeToFile:target atomically:YES];
        if (!success) {
            [FSUIKit showAlertWithMessage:error.localizedDescription controller:self];
        }else{
            if (!self.url) {
                self.url = local;
            }
            [FSTrack event:_UMeng_Event_transfer_db_success];
            [FSUIKit showAlertWithMessage:NSLocalizedString(@"Import success,please restart app", nil) controller:self handler:^(UIAlertAction *action) {
                if (self.hasReceivedData) {
                    self.hasReceivedData(self);
                }
            }];
        }
    }];
}

- (void)listenProgress:(NSProgress *)p{
    if (p.completedUnitCount == p.totalUnitCount) {
        return;
    }
    CGFloat progress = p.completedUnitCount * 1.00 / p.totalUnitCount;
    NSString *title = [[NSString alloc] initWithFormat:@"%.2f%%",progress];
    [self.button setTitle:title forState:UIControlStateNormal];
    __weak typeof(self)this = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [this listenProgress:p];
    });
}

- (void)processDesignViews{
    if (!_button) {
        self.title = NSLocalizedString(@"Receive file", nil);
        _button = [UIButton buttonWithType:UIButtonTypeSystem];
        [_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _button.frame = CGRectMake((WIDTHFC - 90) / 2, HEIGHTFC / 2 - 45, 90, 90);
        _button.layer.cornerRadius = _button.height / 2;
        [_button setTitle:@"0.00%" forState:UIControlStateNormal];
        _button.backgroundColor = FSAPPCOLOR;
        [_button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_button];
    }
}

- (void)dismissAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)buttonClick{
    [self handleURL:self.url error:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
