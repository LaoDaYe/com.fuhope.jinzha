//
//  FSMultiPeerController.h
//  myhome
//
//  Created by FudonFuchina on 2017/10/21.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSMultiPeerController : FSBaseController

@end
