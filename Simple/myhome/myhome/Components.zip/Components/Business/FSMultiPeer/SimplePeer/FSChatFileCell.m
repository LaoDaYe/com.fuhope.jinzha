//
//  FSChatFileCell.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/28.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSChatFileCell.h"

@implementation FSChatFileCell{
    UILabel     *_nameLabel;
    UILabel     *_time;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self fileDesignViews];
    }
    return self;
}

- (void)fileDesignViews{
    self.backgroundColor = [UIColor clearColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    _nameLabel = [[UILabel alloc] init];
    _nameLabel.font = [UIFont systemFontOfSize:14];
    _nameLabel.textColor = [UIColor grayColor];
    _nameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_nameLabel];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_nameLabel]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_nameLabel)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_nameLabel(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_nameLabel)]];
    
    _time = [[UILabel alloc] init];
    _time.font = [UIFont systemFontOfSize:14];
    _time.textColor = [UIColor grayColor];
    _time.textAlignment = NSTextAlignmentRight;
    _time.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_time];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_time(150)]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_time)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_time(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_time)]];
    
}

- (void)setName:(NSString *)name{
    _nameLabel.text = name;
}

- (void)setTime:(NSString *)time{
    _time.text = time;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
