//
//  FSChatProcessCell.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/28.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSChatProcessCell.h"

@implementation FSChatProcessCell{
    UILabel     *_nameLabel;
    UILabel     *_time;
    UILabel     *_content;
    UILabel     *_process;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self processDesignViews];
    }
    return self;
}

- (void)processDesignViews{
    self.backgroundColor = [UIColor clearColor];
    
    _nameLabel = [[UILabel alloc] init];
    _nameLabel.font = [UIFont systemFontOfSize:14];
    _nameLabel.textColor = [UIColor grayColor];
    _nameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_nameLabel];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[_nameLabel]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_nameLabel)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_nameLabel(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_nameLabel)]];
    
    _time = [[UILabel alloc] init];
    _time.font = [UIFont systemFontOfSize:14];
    _time.textColor = [UIColor grayColor];
    _time.textAlignment = NSTextAlignmentRight;
    _time.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_time];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_time(150)]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_time)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[_time(30)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_time)]];
    
    _content = [[UILabel alloc] init];
    _content.numberOfLines = 0;
    _content.font = [UIFont systemFontOfSize:14];
    _content.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_content];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-30-[_content]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_content)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-40-[_content]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_content)]];
    
    _process = [[UILabel alloc] init];
    _process.font = [UIFont systemFontOfSize:14];
    _process.textAlignment = NSTextAlignmentRight;
    _process.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_process];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_process(60)]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_process)]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-40-[_process]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_process)]];
}

- (void)setName:(NSString *)name{
    _nameLabel.text = name;
}

- (void)setTime:(NSString *)time{
    _time.text = time;
}

- (void)setContent:(NSString *)content{
    _content.text = content;
}

- (void)setProcess:(NSString *)process{
    _process.text = process;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
