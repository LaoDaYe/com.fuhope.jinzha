//
//  GZSBigPictureController.m
//  GZSalesApp
//
//  Created by fudon on 16/1/22.
//  Copyright © 2016年 www.Fudongdong.com. All rights reserved.
//

#import "FSChatImageController.h"
#import "FSSeeImageView.h"
#import "FSUIKit.h"
#import "FuSoft.h"

@interface FSChatImageController ()<UIScrollViewDelegate>

@property (nonatomic,assign) NSInteger    index;
@property (nonatomic,assign) BOOL        isTapped;
@property (nonatomic,assign) NSInteger    imageCount;

@end

@implementation FSChatImageController

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
    _isTapped = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = YES;
    
    UIImage *image = [self.class imageWithURL:self.url];
    if ([image isKindOfClass:UIImage.class]) {
        WEAKSELF(this);
        FSSeeImageView *seeImageView = [[FSSeeImageView alloc] initWithFrame:CGRectZero dataSource:@[image]];
        [self.view addSubview:seeImageView];
        seeImageView.singleBlock = ^ (FSSeeImageView *bView){
            [this tapAction];
        };
        seeImageView.indexChangedBlock = ^ (FSSeeImageView *bView,NSInteger bIndex){
            this.index = bIndex;
            this.title = [[NSString alloc] initWithFormat:@"%@/%@",@(bIndex + 1),@(bView.dataSource.count)];
        };
    } else {
        [FSUIKit showAlertWithMessage:@"文件不存在" controller:self handler:^(UIAlertAction *action) {
            [self.navigationController popViewControllerAnimated:YES];
        }];
    }
}

+ (UIImage *)imageWithURL:(NSURL *)url{
    NSData *data = [[NSData alloc] initWithContentsOfURL:url];
    UIImage *image = [[UIImage alloc] initWithData:data];
    return image;
}

- (void)tapAction{
    _isTapped = !_isTapped;
    self.navigationController.navigationBar.hidden = !_isTapped;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

