//
//  FSPeersController.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/24.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSPeersController.h"
#import "FSMultiPeerController.h"
#import "FSProcessController.h"
#import "FSMacro.h"

@interface FSPeersController ()

@end

@implementation FSPeersController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self peersDesignViews];
}

- (void)peersDesignViews{
    self.title = @"无流量传输文件";
    UIButton *rece = [UIButton buttonWithType:UIButtonTypeSystem];
    rece.translatesAutoresizingMaskIntoConstraints = NO;
    rece.backgroundColor = FSAPPCOLOR;
    rece.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    rece.layer.cornerRadius = 8;
    [rece setTitle:@"我要接收" forState:UIControlStateNormal];
    [rece setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rece addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rece];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[rece]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(rece)]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[rece(100)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(rece)]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:rece attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1 constant:-5]];
    
    UIButton *send = [UIButton buttonWithType:UIButtonTypeSystem];
    send.translatesAutoresizingMaskIntoConstraints = NO;
    send.backgroundColor = APPCOLOR;
    send.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    send.layer.cornerRadius = 8;
    send.tag = 1;
    [send setTitle:@"我要发送" forState:UIControlStateNormal];
    [send setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [send addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:send];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[send]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(send)]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[send(100)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(send)]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:send attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1 constant:5]];
}

- (void)btnClick:(UIButton *)btn{
    if (btn.tag == 0) {
        FSProcessController *p = [[FSProcessController alloc] init];
        [self.navigationController pushViewController:p animated:YES];
    }else{
        FSMultiPeerController *m = [[FSMultiPeerController alloc] init];
        [self.navigationController pushViewController:m animated:YES];        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
