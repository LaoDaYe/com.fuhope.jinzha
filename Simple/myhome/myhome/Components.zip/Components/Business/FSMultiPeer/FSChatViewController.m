//
//  FSChatViewController.m
//  myhome
//
//  Created by FudonFuchina on 2017/10/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSChatViewController.h"
#import "FSChatInputView.h"
#import <Photos/Photos.h>
#import <FSUIKit.h>
#import "FSMacro.h"

@interface FSChatViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray     *list;

@end

@implementation FSChatViewController{
    FSChatInputView     *_chatView;
    UITableView         *_tableView;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self chatDesignViews];
}

- (void)chatHandleDatas{
    
}

- (void)chatDesignViews{
    if (!_chatView) {
        self.view.backgroundColor = [UIColor whiteColor];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardAction:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardAction:) name:UIKeyboardWillHideNotification object:nil];
        
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"File", nil) style:UIBarButtonItemStyleDone target:self action:@selector(fileAction)];
        self.navigationItem.rightBarButtonItem = bbi;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64 - 50) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];

        CGFloat value = 0xf8/255.0;
        _chatView = [[FSChatInputView alloc] initWithFrame:CGRectMake(0, HEIGHTFC - 50, WIDTHFC, 50)];
        _chatView.backgroundColor = [UIColor colorWithRed:value green:value blue:value alpha:1.0];
        [self.view addSubview:_chatView];
        __weak typeof(self)this = self;
        _chatView.sendMessage = ^(NSString *message) {
            if (this.sendDataBlock) {
                this.sendDataBlock(message);
            }
        };
        _chatView.photoCallback = ^{
            [this showPhoto];
        };
    }
}

- (void)keyboardAction:(NSNotification *)notification{
    CGSize kbSize = [FSKit keyboardSizeFromNotification:notification];
    BOOL show = [notification.name isEqualToString:UIKeyboardWillShowNotification];
    [UIView animateWithDuration:.3 animations:^{
        self->_chatView.top = HEIGHTFC - 50 - (show?kbSize.height:0);
    }];
}

- (void)fileAction{
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:@"发出数据库" message:@"您可以把本app的数据库(所有数据)发给您的其他手机或朋友，实现数据转移" actionTitles:@[NSLocalizedString(@"Send", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        
    }];
}

- (void)sendImageMethod:(NSURL *)url{
    if (self.sendImage) {
        self.sendImage(url);
    }
}

- (void)showPhoto{
    NSString *shot = @"拍照";
    NSString *pics = @"相册";
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:@"发送图片" message:@"将图片发送给朋友，不消耗流量" actionTitles:@[shot,pics] styles:@[@(UIAlertActionStyleDefault),@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        if ([action.title isEqualToString:shot]) {
            [self cameraOrPhoto:UIImagePickerControllerSourceTypeCamera];
        }else if ([action.title isEqualToString:pics]){
            [self cameraOrPhoto:UIImagePickerControllerSourceTypePhotoLibrary];
        }
    }];
}

- (void)cameraOrPhoto:(UIImagePickerControllerSourceType)type{
    if (![UIImagePickerController isSourceTypeAvailable:type]) {
        [FSUIKit showAlertWithMessage:@"您的设备不支持" controller:self];
        return;
    }
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = type;
    [self presentViewController:picker animated:YES completion:nil];
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

#pragma mark Camera
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    NSURL *url = nil;
    if (@available(iOS 11.0, *)) {
        url = [info objectForKey:UIImagePickerControllerImageURL];
    } else {
        url = [info objectForKey:UIImagePickerControllerReferenceURL];
    }
    [self sendImageMethod:url];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
