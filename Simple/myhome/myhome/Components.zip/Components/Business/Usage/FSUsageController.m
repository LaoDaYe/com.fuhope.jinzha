//
//  FSUsageController.m
//  myhome
//
//  Created by FudonFuchina on 2017/11/5.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSUsageController.h"
#import <FSTuple.h>
#import "FSWebKitController.h"
#import "AppConfiger.h"
#import "FuSoft.h"
#import "FSKit.h"
#import "FSTrackKeys.h"

@interface FSUsageController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation FSUsageController{
    NSArray *_list;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self usageHandleDatas];
}

- (void)usageHandleDatas{
    _list = @[
              [Tuple2 v1:NSLocalizedString(@"Accountbooks", nil) v2:_Watch_Account],
              
              ];
    [self usageDesignViews];
}

- (void)usageDesignViews{
    self.title = NSLocalizedString(@"Usage", nil);
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64 - 49) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = 54;
    tableView.tableFooterView = [UIView new];
    tableView.showsVerticalScrollIndicator = NO;
    tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    Tuple2 *t = _list[indexPath.row];
    cell.textLabel.text = t._1;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    Tuple2 *t = _list[indexPath.row];
    if (_fs_isValidateString(t._2)) {
        FSWebKitController *webController = [[FSWebKitController alloc] init];
        webController.urlString = t._2;
        [self.navigationController pushViewController:webController animated:YES];
        [FSTrack event:_UMeng_Event_watch_video];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
