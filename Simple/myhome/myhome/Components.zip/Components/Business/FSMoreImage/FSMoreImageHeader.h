//
//  FSMoreImageHeader.h
//  FSImage
//
//  Created by fudon on 2016/10/11.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#ifndef FSMoreImageHeader_h
#define FSMoreImageHeader_h

#define FSMoreGreenColor  [UIColor colorWithRed:31.0 / 255.0 green:185 / 255.0 blue:34 / 255.0 alpha:1]

#endif /* FSMoreImageHeader_h */
