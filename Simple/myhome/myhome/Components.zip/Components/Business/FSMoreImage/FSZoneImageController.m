//
//  FSZoneImageController.m
//  GZSalesApp
//
//  Created by fudon on 2016/12/9.
//  Copyright © 2016年 www.Fudongdong.com. All rights reserved.
//

#import "FSZoneImageController.h"
#import "FSImagePicker.h"
#import "FSIPModel.h"
#import "FSMoreZoneImageCell.h"
#import "FSAllImageController.h"
#import "FSImagePickerController.h"

@interface FSZoneImageController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSDictionary       *allImages;
@property (nonatomic,strong) NSArray            *allKeys;

@end

@implementation FSZoneImageController

#if DEBUG
- (void)dealloc
{
    NSLog(@"%s",__FUNCTION__);
}
#endif

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"照片";
    UIBarButtonItem *rightBBI = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", nil) style:UIBarButtonItemStylePlain target:self action:@selector(bbiRightAction)];
    self.navigationItem.rightBarButtonItem = rightBBI;
    
    FSImagePickerController *ip = (FSImagePickerController *)self.navigationController;
    _allImages = ip.picker.allThumbnails;
    _allKeys = [_allImages allKeys];
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 64) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.tableFooterView = [UIView new];
    [self.view addSubview:tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _allKeys.count;
}

- (FSMoreZoneImageCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    FSMoreZoneImageCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[FSMoreZoneImageCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    FSImagePickerController *ip = (FSImagePickerController *)self.navigationController;
    NSString *key = [_allKeys objectAtIndex:indexPath.row];
    PHAssetCollection *collection = [_allImages objectForKey:key];
    cell.models = [ip.picker enumerateAssetsInAssetCollection:collection original:NO];
    if (cell.models.count) {
        FSIPModel *model = cell.models[cell.models.count - 1];
        cell.model = model;
    }
    cell.textLabel.text = [[NSString alloc] initWithFormat:@"%@ (%@)",[key isEqualToString:Key_CameraRoll]?@"相机胶卷":key,@(cell.models.count)];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FSMoreZoneImageCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    NSString *key = [_allKeys objectAtIndex:indexPath.row];
    
    FSAllImageController *moreImageController = [[FSAllImageController alloc] init];
    moreImageController.title = [key isEqualToString:Key_CameraRoll]?@"相机胶卷":key;
    moreImageController.dataSource = cell.models;
    [self.navigationController pushViewController:moreImageController animated:YES];
}

- (void)bbiRightAction
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
