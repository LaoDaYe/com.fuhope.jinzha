//
//  FSBeyondButton.m
//  FSImage
//
//  Created by fudon on 2016/10/10.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSBeyondButton.h"

@interface FSBeyondButton ()

@property (nonatomic,strong) UIImageView        *colorView;
@property (nonatomic,assign) BOOL               needCenter;

@end

@implementation FSBeyondButton

- (instancetype)initWithFrame:(CGRect)frame center:(BOOL)center
{
    self = [super initWithFrame:frame];
    if (self) {
        _needCenter = center;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapActionBeyond)];
        [self addGestureRecognizer:tap];
        
        _colorView = [[UIImageView alloc] initWithFrame:CGRectMake(15 - center * 5, 5 + center * 5, 24, 24)];// (10,10,24,24)   NO:(15,5,24,24)
        _colorView.image = [UIImage imageNamed:@"fsip_unselected"];
        [self addSubview:_colorView];
    }
    return self;
}

- (void)tapActionBeyond
{
    self.isSelected = !self.isSelected;
    if (_btnClickBlock) {
        _btnClickBlock(self);
    }
}

- (void)setIsSelected:(BOOL)isSelected
{
    if (_isSelected == isSelected) {
        return;
    }
    _isSelected = isSelected;
    if (isSelected) {
        _colorView.image = [UIImage imageNamed:@"fsip_selected"];
        __weak FSBeyondButton *this = self;
        [UIView animateWithDuration:.6 delay:0.1 usingSpringWithDamping:.3 initialSpringVelocity:.3 options:UIViewAnimationOptionCurveEaseOut animations:^{
            this.colorView.transform = CGAffineTransformMakeScale(1.4, 1.4);
        } completion:^(BOOL finished) {
            this.colorView.transform = CGAffineTransformMakeScale(1.2, 1.2);
        }];
    }else{
        _colorView.image = [UIImage imageNamed:@"fsip_unselected"];
        _colorView.transform = CGAffineTransformMakeScale(1, 1);
    }
}

@end
