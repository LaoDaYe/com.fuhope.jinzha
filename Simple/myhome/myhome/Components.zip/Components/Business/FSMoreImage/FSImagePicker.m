//
//  FSImagePicker.m
//  FSImage
//
//  Created by fudon on 2016/10/14.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSImagePicker.h"
#import <Photos/Photos.h>
#import <math.h>
#import <FSKit.h>
#import <FSUIKit.h>

@implementation FSImagePicker

#if DEBUG
- (void)dealloc
{
    NSLog(@"%s",__FUNCTION__);
}
#endif

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self requestAllResources];
    }
    return self;
}

- (void)requestAllResources
{
    _allThumbnails = [self allAssetCollection];
    _allModels = [self parseArrayFromDictionary:_allThumbnails];
}

- (NSArray *)parseArrayFromDictionary:(NSDictionary *)dic
{
    PHAssetCollection *collection = [dic objectForKey:Key_CameraRoll];
    return [self enumerateAssetsInAssetCollection:collection original:NO];
}

- (NSInteger)sizeOfSelectedImages
{
    __block CGFloat imageLength = 0;
    for (int x = 0; x < _selectedImages.count; x ++) {
        FSIPModel *model = [_selectedImages objectAtIndex:x];
        if (model.length) {
            imageLength += model.length;
        }else{
            imageLength += [self sizeForImageWithAsset:model.asset];
        }
    }
    return imageLength;
}

// 缩略图
+ (void)thumbnailsImageForModel:(FSIPModel *)model completion:(void(^)(UIImage *bImage))completion
{
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    options.resizeMode = PHImageRequestOptionsResizeModeFast;
    
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat width = (screenWidth - 25) / 4;
    NSInteger hvRate = MAX(model.asset.pixelHeight / model.asset.pixelWidth, 1);  // 高/宽
    CGFloat scale = 2.0;
    if (screenWidth > 700) {
        scale = 1.5;
    }
    NSInteger pWidth = width * scale;
    NSInteger pHeight = pWidth * hvRate;
    CGSize targetSize = CGSizeMake(pWidth, pHeight);
    
    // 从asset中获得图片
    [[PHImageManager defaultManager] requestImageForAsset:model.asset targetSize:targetSize contentMode:PHImageContentModeDefault options:options resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
        if (completion) {
            completion(result);
        }
    }];
}

- (NSInteger)sizeForImageWithAsset:(PHAsset *)asset
{
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    options.synchronous = YES;
    options.resizeMode = PHImageRequestOptionsResizeModeFast;
    
    __block NSInteger length = 0;
    __weak FSImagePicker *this = self;
    [[PHImageManager defaultManager] requestImageDataForAsset:asset options:options resultHandler:^(NSData * _Nullable imageData, NSString * _Nullable dataUTI, UIImageOrientation orientation, NSDictionary * _Nullable info) {
        length = imageData.length;
        for (int x = 0; x < this.selectedImages.count; x ++) {
            FSIPModel *model = this.selectedImages[x];
            if (model.asset == asset) {
                model.length = length;
            }
        }
    }];
    return length;
}

+ (NSInteger)sizeForAsset:(PHAsset *)asset
{
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    options.synchronous = YES;
    options.resizeMode = PHImageRequestOptionsResizeModeFast;
    
    __block NSInteger length = 0;
    [[PHImageManager defaultManager] requestImageDataForAsset:asset options:options resultHandler:^(NSData * _Nullable imageData, NSString * _Nullable dataUTI, UIImageOrientation orientation, NSDictionary * _Nullable info) {
        length = imageData.length;
    }];
    return length;
}

- (NSArray *)selectedAssetsWithModels
{
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:_selectedImages.count];
    for (int x = 0; x < _selectedImages.count; x ++) {
        FSIPModel *model = [_selectedImages objectAtIndex:x];
        if (model.asset) {
            [array addObject:model.asset];
        }
    }
    return array;
}

- (NSArray *)selectedImagesWithModels
{
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:_selectedImages.count];
    for (int x = 0; x < _selectedImages.count; x ++) {
        FSIPModel *model = [_selectedImages objectAtIndex:x];
        if (model.asset) {
            NSData *imageData = [self imageForModel:model];
            if (!_isOriginal) {
                UIImage *image = [FSUIKit compressImageData:imageData];
                NSData *data = UIImageJPEGRepresentation(image, 1.0f);
                if (!data) {
                    return nil;
                }
                [array addObject:data];
            }else{
                if (!imageData) {
                    return nil;
                }
                [array addObject:imageData];
            }
        }
    }
    return array;
}

- (NSData *)imageForModel:(FSIPModel *)model
{
    if (!model.asset) {
        return nil;
    }
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    options.synchronous = YES;
    __block __weak NSData *data = nil;
    [[PHImageManager defaultManager] requestImageDataForAsset:model.asset options:options resultHandler:^(NSData * _Nullable imageData, NSString * _Nullable dataUTI, UIImageOrientation orientation, NSDictionary * _Nullable info) {
        data = imageData;
    }];
    return data;
}

// 获取所有图片的Model集合
- (NSDictionary<NSString *,PHAssetCollection *> *)allAssetCollection
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    // 获得所有的自定义相簿
    PHFetchResult<PHAssetCollection *> *assetCollections = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    for (PHAssetCollection *assetCollection in assetCollections) {
        NSString *name = assetCollection.localizedTitle;
        if (name.length == 0) {
            name = @"自定义相册";
        }
        [dic setObject:assetCollection forKey:name];
    }
    
    // 获得相机胶卷
    PHAssetCollection *cameraRoll = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil].lastObject;
    if (cameraRoll) {
        [dic setObject:cameraRoll forKey:Key_CameraRoll];
    }
    return dic;
}

+ (UIImage *)theNewestImageFromAlbum{
    FSImagePicker *picker = [[FSImagePicker alloc] init];
    return [picker theNewestImageFromAlbum];
}

- (UIImage *)theNewestImageFromAlbum
{
    PHAssetCollection *cameraRoll = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil].lastObject;
    
    PHFetchOptions *fetchOptions = [[PHFetchOptions alloc] init];
    fetchOptions.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO]];
    
    PHFetchResult<PHAsset *> *assets = [PHAsset fetchAssetsInAssetCollection:cameraRoll options:fetchOptions];
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:assets.count];
    if (assets.count) {
        PHAsset *asset = assets[0];
        FSIPModel *model = [[FSIPModel alloc] init];
        model.asset = asset;
        [array addObject:model];
        UIImage *image = [[UIImage alloc] initWithData:[self imageForModel:model]];
        return image;
    }
    return nil;
}

/**
 *  遍历相簿中的所有图片
 *  @param assetCollection 相簿
 *  @param original        是否要原图
 */
- (NSArray *)enumerateAssetsInAssetCollection:(PHAssetCollection *)assetCollection original:(BOOL)original
{
    PHFetchOptions *fetchOptions = [[PHFetchOptions alloc] init];
    fetchOptions.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:YES]];
    
    // 获得某个相簿中的所有PHAsset对象
    PHFetchResult<PHAsset *> *assets = [PHAsset fetchAssetsInAssetCollection:assetCollection options:fetchOptions];
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:assets.count];
    for (PHAsset *asset in assets) {    // asset有一个mediaSubtypes属性可以用于区分全景图、最新图片等
        if (asset.mediaType != PHAssetMediaTypeImage) {
            continue;
        }
        if (asset.pixelWidth == 0 || asset.pixelHeight == 0) {
            continue;
        }
        
        FSIPModel *model = [[FSIPModel alloc] init];
        model.asset = asset;
        [array addObject:model];
    }
    return array;
}

void getImgWidth(long *width , int * index)
{
    if (*width < 160) {
        return ;
    }
    (*index) ++;
    *width /= 2;
    getImgWidth(width,index);
}

- (NSInteger)compressWidthForImageWidth:(long)imageWidth
{
    int  index = 0;
    getImgWidth(&imageWidth, &index);
    return index;
}

@end
