//
//  FSAllImageController.h
//  FSImage
//
//  Created by fudon on 2016/10/14.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSAllImageController : UIViewController

@property (nonatomic,strong) NSArray            *dataSource;

@end
