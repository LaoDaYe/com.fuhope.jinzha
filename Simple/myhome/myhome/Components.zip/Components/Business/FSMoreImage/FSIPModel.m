//
//  FSIPModel.m
//  FSImage
//
//  Created by fudon on 2016/11/29.
//  Copyright © 2016年 Fudongdong. All rights reserved.
//

#import "FSIPModel.h"

@implementation FSIPModel

#if DEBUG
- (void)dealloc
{
    NSLog(@"%s",__FUNCTION__);
}
#endif

@end
