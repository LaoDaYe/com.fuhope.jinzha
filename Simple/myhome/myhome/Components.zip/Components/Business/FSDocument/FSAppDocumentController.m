//
//  FSAppDocumentController.m
//  FSDocument
//
//  Created by fudon on 2016/12/17.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSAppDocumentController.h"
#import "FSShare.h"
#import "FSUIKit.h"
#import "FSToast.h"

@interface FSAppDocumentController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,strong) NSArray        *dataSource;

@end

@implementation FSAppDocumentController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    if (!self.title) {
        self.title = @"Home";
    }
    
    [self appHandleDatas];
}

- (void)appHandleDatas
{
    NSFileManager *manager = [NSFileManager defaultManager];
    if (!self.path) {
        self.path = NSHomeDirectory();
    }
    NSError *error = nil;
    NSArray *paths = [manager subpathsOfDirectoryAtPath:self.path error:&error];
    NSMutableArray *dataSource = [[NSMutableArray alloc] init];
    for (NSString *path in paths) {
        if (![path containsString:@"/"]) {
            [dataSource addObject:path];
        }
    }
    NSMutableArray *folders = [[NSMutableArray alloc] init];
    NSMutableArray *files = [[NSMutableArray alloc] init];
    
    for (int x = 0; x < dataSource.count; x ++) {
        NSString *name = dataSource[x];
        if ([FSAppDocumentController isDirPath:[self.path stringByAppendingPathComponent:name]]) {
            [folders addObject:name];
        }else{
            [files addObject:name];
        }
    }
    _dataSource = @[folders,files];
    if (!error) {
        if (_tableView) {
            [_tableView reloadData];
        }else{
            [self appDesignViews];
        }
    }
}

- (void)appDesignViews
{
    NSString *size = [[NSString alloc] initWithFormat:@"%.2fM",[FSAppDocumentController folderSizeAtPath:self.path]];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:size style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationItem.rightBarButtonItem = bbi;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.estimatedSectionHeaderHeight = 0;
    _tableView.estimatedSectionFooterHeight = 0;
    [self.view addSubview:_tableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = self.dataSource[section];
    return array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSString *text = _dataSource[indexPath.section][indexPath.row];
    cell.textLabel.text = text;
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *head = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, 40)];
    label.text = section == 0?@"文件夹":@"文件";
    [head addSubview:label];
    
    return head;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *fileName = _dataSource[indexPath.section][indexPath.row];
    NSString *path = [self.path stringByAppendingPathComponent:fileName];
    
    if (indexPath.section == 0) {
        FSAppDocumentController *app = [[FSAppDocumentController alloc] init];
        app.title = fileName;
        app.path = path;
        [self.navigationController pushViewController:app animated:YES];
    }else{
        NSFileManager *manager = [NSFileManager defaultManager];
        BOOL canDelete = [manager isDeletableFileAtPath:path];
        
        NSString *text = [[NSString alloc] initWithFormat:@"大小:%.2fM,%@",[FSAppDocumentController fileSizeAtPath:path] / (1024.0f * 1024),canDelete?@"可以删除":@"不可删除"];
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:fileName message:text actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
            NSData *data = [[NSData alloc] initWithContentsOfFile:path];
            if (![data isKindOfClass:NSData.class]) {
                [FSToast show:@"这文件不能导出"];
                return;
            }
            [FSShare emailShareWithSubject:fileName on:self messageBody:text recipients:nil fileData:[[NSData alloc] initWithContentsOfFile:path] fileName:fileName mimeType:@"db"];            
        }];
    }
}

+ (BOOL)isDirPath:(NSString *)path
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isDir;
    return [fileManager fileExistsAtPath:path isDirectory:&isDir] && isDir;
}

//单个文件的大小
+ (long long) fileSizeAtPath:(NSString*) filePath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}

//遍历文件夹获得文件夹大小，返回多少M
+ (float )folderSizeAtPath:(NSString*) folderPath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:folderPath]) return 0;
    NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath:folderPath] objectEnumerator];
    NSString* fileName;
    long long folderSize = 0;
    while ((fileName = [childFilesEnumerator nextObject]) != nil){
        NSString* fileAbsolutePath = [folderPath stringByAppendingPathComponent:fileName];
        folderSize += [self fileSizeAtPath:fileAbsolutePath];
    }
    return folderSize/(1024.0*1024.0);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
