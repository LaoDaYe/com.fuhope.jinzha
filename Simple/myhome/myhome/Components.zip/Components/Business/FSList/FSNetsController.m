//
//  FSNetsController.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/9.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSNetsController.h"
#import "FSWebKitController.h"
#import "FSDBSupport.h"
#import "FSNetModel.h"
#import "FSDBTool.h"
#import <FSUIKit.h>

@interface FSNetsController ()

@property (nonatomic,strong) NSArray    *list;

@end

@implementation FSNetsController{
    UITextField     *_textField;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    [self netDesignViews];
}

- (void)netHandleDatas{
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by cast(count as REAL) DESC;",_tb_net];
    self.list = [FSDBSupport querySQL:sql class:FSNetModel.class tableName:_tb_net];
    [self netDesignViews];
}

- (void)editNets{
    [FSKit pushToViewControllerWithClass:@"FSEditNetsController" navigationController:self.navigationController param:nil configBlock:nil];
}

- (void)netDesignViews{
    self.title = @"增加顶级域名";
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(editNets)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    _textField = [[UITextField alloc] initWithFrame:CGRectMake(15, 90, [UIScreen mainScreen].bounds.size.width - 30, 44)];
    _textField.placeholder = @"输入顶级域名，如com,net,org等";
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.view addSubview:_textField];
    [_textField becomeFirstResponder];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(15, 134, _textField.bounds.size.width, 1)];
    line.backgroundColor = THISCOLOR;
    [self.view addSubview:line];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(15, 164, [UIScreen mainScreen].bounds.size.width - 30, 44);
    button.backgroundColor = THISCOLOR;
    [button setTitle:@"添加" forState:UIControlStateNormal];
    button.layer.cornerRadius = 3;
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(affirm) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

- (void)affirm{
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:@"确定增加？" message:nil actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        [self addType];
    }];
}

- (void)addType{
    NSString *value = [FSKit cleanString:_textField.text];
    if (!value.length) {
        return;
    }
    if (![value hasPrefix:@"."]) {
        value = [[NSString alloc] initWithFormat:@".%@",value];
    }
    value = [value lowercaseString];
    
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE name = '%@';",_tb_net,value];
    NSArray *exists = [FSDBSupport querySQL:sql class:FSNetModel.class tableName:_tb_net];
    if (exists.count) {
        [FSToast show:[[NSString alloc] initWithFormat:@"%@已存在，不需添加",value]];
        return;
    }
    NSString *error = [master insert_fields_values:@{
                                                     @"time":@(_fs_timeIntevalSince1970()),
                                                     @"name":value,
                                                     @"count":@0
                                                     } table:_tb_net];    
    if (error) {
        [FSUIKit showAlertWithMessage:error controller:self];
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
