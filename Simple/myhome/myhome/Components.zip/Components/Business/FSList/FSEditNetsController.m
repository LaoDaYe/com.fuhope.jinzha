//
//  FSEditNetsController.m
//  myhome
//
//  Created by Fudongdong on 2017/8/14.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSEditNetsController.h"
#import "FSDBSupport.h"
#import "FSNetModel.h"
#import <MJRefresh.h>
#import "FSDBTool.h"
#import "FSBaseAPI.h"
#import <FSUIKit.h>


@interface FSEditNetsController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,assign) NSInteger          page;
@property (nonatomic,strong) UITableView        *tableView;
@property (nonatomic,strong) NSMutableArray     *list;

@end

@implementation FSEditNetsController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self editHandleDatas];
}

- (void)editHandleDatas{
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by cast(count as INT) ASC limit %@,10;",_tb_net,@(self.page * 10)];
    NSMutableArray *list = [FSDBSupport querySQL:sql class:FSNetModel.class tableName:_tb_net];
    if (self.page) {
        if (list.count) {
            [self.list addObjectsFromArray:list];
        }
    }else{
        self.list = list;
    }
    [self editDesignViews];
}

- (void)editDesignViews{
    if (_tableView) {
        [_tableView reloadData];
        [_tableView.mj_header endRefreshing];
        [_tableView.mj_footer endRefreshing];
        return;
    }
    self.title = @"操作顶级域名";
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIView new];
    _tableView.rowHeight = 50;
    _tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_tableView];
    WEAKSELF(this);
    _tableView.mj_header= [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        this.page = 0;
        [this editHandleDatas];
    }];
    this.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        this.page ++;
        [this editHandleDatas];
    }];
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    FSNetModel *model = self.list[indexPath.row];
    cell.textLabel.text = model.name;
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        FSNetModel *model = self.list[indexPath.row];
        [FSBaseAPI deleteModelBusiness:model table:_tb_net controller:self success:^{
            [self editHandleDatas];
        } fail:^(NSString *error) {
            [FSUIKit showAlertWithMessage:error controller:self];
        } cancel:^{
            tableView.editing = NO;
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
