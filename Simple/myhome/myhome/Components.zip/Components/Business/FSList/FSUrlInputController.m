//
//  FSUrlInputController.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/13.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSUrlInputController.h"
#import "FSInputTableView.h"
#import "FSWebKitController.h"
#import "FSDBSupport.h"
#import "FSNetModel.h"
#import "FSDBTool.h"

@interface FSUrlInputController ()

@property (nonatomic,strong) NSArray    *list;

@end

@implementation FSUrlInputController{
    UIBarButtonItem     *_bbi;
    FSInputTableView    *_iView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self urlHandleDatas];
}

- (void)urlHandleDatas{
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by cast(count AS INT) DESC limit 0,100;",_tb_net];
    self.list = [FSDBSupport querySQL:sql class:FSNetModel.class tableName:_tb_net];
    [self urlDesignViews];
}

- (void)bbiAction:(UIBarButtonItem *)bbi{
    NSString *str = bbi.title;
    if ([str isEqualToString:@"https"]) {
        bbi.title = @"http";
    }else{
        bbi.title = @"https";
    }
    NSString *text = _iView.textField.text;
    _iView.textField.text = text;
    [_iView.tableView reloadData];
}

- (void)urlDesignViews{
    self.title = @"输入网址";
    _bbi = [[UIBarButtonItem alloc] initWithTitle:@"https" style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction:)];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addDomain)];
    self.navigationItem.rightBarButtonItems = @[bbi,_bbi];
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (FSNetModel *model in self.list) {
        if (model.name) {
            [array addObject:model.name];
        }
    }
    if (array.count == 0) {
        array = (NSMutableArray *)@[@".com",@".org",@".net"];
    }
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    _iView = [[FSInputTableView alloc] initWithFrame:CGRectMake(0, 64, size.width, 76)];
    _iView.backgroundColor = FSAPPCOLOR;
    [_iView.textField becomeFirstResponder];
    [self.view addSubview:_iView];
    WEAKSELF(this);
    [_iView setTextCallback:^NSString *(NSString *input,NSInteger row) {
        return [this joinedString:input domain:array[row]];
    }];
    [_iView setNumberOfRowsInSection:^NSInteger{
        return array.count;
    }];
    [_iView setDidSelectCallback:^(NSString *input,NSInteger row) {
        NSString *url = [this joinedString:input domain:array[row]];
        if (this.selectUrlCallback) {
            this.selectUrlCallback(this, url);
        }else{
            FSWebKitController *kit = [[FSWebKitController alloc] init];
            kit.urlString = url;
            [this.navigationController pushViewController:kit animated:YES];
            [this updateCount:row];
        }
    }];
    _iView.tableHeight = size.height - 140;
}

- (void)addDomain{
    [FSKit pushToViewControllerWithClass:@"FSNetsController" navigationController:self.navigationController param:nil configBlock:nil];
}

- (NSString *)joinedString:(NSString *)input domain:(NSString *)domain{
    if ([input hasPrefix:@"https:"] || [input hasPrefix:@"http:"]) {
        return input;
    }else{
        return [[[NSString alloc] initWithFormat:@"%@://www.%@%@",_bbi.title,input,domain] lowercaseString];
    }
}

- (void)updateCount:(NSInteger)row{
    if (self.list.count > row) {
        FSNetModel *model = self.list[row];
        FSDBMaster *master = [FSDBMaster sharedInstance];
        NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET count = '%@' WHERE aid = %@;",_tb_net,@([model.count integerValue] + 1),model.aid];
        [master updateSQL:sql];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
