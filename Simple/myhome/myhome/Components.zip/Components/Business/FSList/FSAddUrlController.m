//
//  FSAddUrlController.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/18.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSAddUrlController.h"
#import "FSDBMaster.h"
#import "FSLabelTextField.h"
#import "FSDBTool.h"
#import "FSTextViewController.h"
#import <FSUIKit.h>
#import "FSURLAPI.h"
#import "FSTrackKeys.h"

@interface FSAddUrlController ()

@property (nonatomic,strong) FSLabelTextField   *textField;
@property (nonatomic,strong) FSTapCell          *cell;
@property (nonatomic,copy)   NSString           *url;

@end

@implementation FSAddUrlController

- (void)viewDidLoad{
    [super viewDidLoad];
    [self urlDesignViews];
}

- (void)urlDesignViews{
    self.title = _model?NSLocalizedString(@"Update URLs", nil):NSLocalizedString(@"Add URLs", nil);
    _textField = [[FSLabelTextField alloc] initWithFrame:CGRectMake(0, 10, WIDTHFC, 44) text:NSLocalizedString(@"Name url", nil) textFieldText:_model.name?:nil placeholder:NSLocalizedString(@"Please input", nil)];
    [self.scrollView addSubview:_textField];
    WEAKSELF(this);
    _cell = [FSViewManager tapCellWithText:NSLocalizedString(@"Addr url", nil) textColor:FS_TextColor_Normal font:[UIFont systemFontOfSize:15] detailText:NSLocalizedString(@"Please choose", nil) detailColor:FS_TextColor_Dark detailFont:[UIFont systemFontOfSize:15] block:^(FSTapCell *bCell){
        FSTextViewController *url = [[FSTextViewController alloc] init];
        if (this.model) {
            url.text = this.model.url;
        }else{
            url.text = @"https://www.";
        }
        [this.navigationController pushViewController:url animated:YES];
        url.callback = ^(FSTextViewController *bVC, NSString *bText) {
            this.url = bText;
            bCell.detailTextLabel.text = bText;
            [bVC.navigationController popViewControllerAnimated:YES];
        };
    }];
    _cell.backgroundColor = [UIColor whiteColor];
    _cell.top = _textField.bottom + 1;
    _cell.detailTextLabel.text = _model.url?:nil;
    [self.scrollView addSubview:_cell];
    self.url = _model.url?:nil;
    
    UIButton *button = [FSViewManager buttonWithFrame:CGRectMake(20, _cell.bottom + 20, WIDTHFC - 40, 40) title:_model?NSLocalizedString(@"Update", nil):NSLocalizedString(@"Add", nil) titleColor:[UIColor whiteColor] backColor:FSAPPCOLOR fontInt:0 tag:0 target:self selector:@selector(countAction)];
    [self.scrollView addSubview:button];
}

- (void)countAction{
    NSString *name = [FSKit cleanString:_textField.textField.text];
    if (name.length == 0) {
        return;
    }
    if (!_fs_isValidateString(self.url)) {
        return;
    }
    NSString *error = nil;
    FSDBMaster *master = [FSDBMaster sharedInstance];
    if (_model) {
        NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET name = '%@',url = '%@' WHERE aid = %@;",_tb_url,name,self.url,_model.aid];
        error = [master updateSQL:sql];
    }else{
        error = [FSURLAPI addUrl:name url:self.url];
    }
    if (error) {
        [FSUIKit showAlertWithMessage:error controller:self];
        return;
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:_Notifi_refreshUrlPage object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:_Notifi_sendSqlite3 object:nil];
    
    [FSTrack event:_UMeng_Event_url_add];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
