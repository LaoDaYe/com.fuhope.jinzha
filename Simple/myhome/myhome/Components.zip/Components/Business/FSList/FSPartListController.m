//
//  FSPartListController.m
//  myhome
//
//  Created by fudon on 2017/2/16.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSPartListController.h"
#import "FSWebKitController.h"
#import "FSDBSupport.h"
#import "FSUrlModel.h"
#import "FSAddUrlController.h"
#import "FSDBTool.h"
#import <MJRefresh.h>
#import <FSUIKit.h>
#import "FSURLAPI.h"
#import "FSTrack.h"
#import "FSTrackKeys.h"

@interface FSPartListController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView        *tableView;
@property (nonatomic,strong) NSMutableArray     *list;
@property (nonatomic,assign) NSInteger          page;

@end

@implementation FSPartListController{
    BOOL    _needRefresh;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_Notifi_refreshUrlPage object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [FSURLAPI initConfigForNewUsers:^{
        [self urlHandleDatas];        
    }];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (_needRefresh) {
        [self urlHandleDatas];
    }
}

- (void)urlHandleDatas{
    _fs_dispatch_global_main_queue_async(^{
        static NSInteger unit = 100;
        NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ order by cast(count as INT) DESC limit %@,%@;",_tb_url,@(self.page * unit),@(unit)];
        NSMutableArray *list = [FSDBSupport querySQL:sql class:FSUrlModel.class tableName:_tb_url];
        if (self.page) {
            [self.list addObjectsFromArray:list];
        }else{
            self.list = list;
        }
    }, ^{
        [self urlDesignViews];
    });
}

- (void)refreshAction{
    _needRefresh = YES;
}

- (void)pushDemo{
    [FSKit pushToViewControllerWithClass:@"FSDemoUrlController" navigationController:self.navigationController param:nil configBlock:nil];
}

- (void)urlDesignViews{
    if (_tableView) {
        [_tableView reloadData];
        [_tableView.mj_header endRefreshing];
        [_tableView.mj_footer endRefreshing];
        return;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshAction) name:_Notifi_refreshUrlPage object:nil];
    self.title = NSLocalizedString(@"Wap", nil);
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(bbiAction)];
    UIBarButtonItem *demo = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemOrganize target:self action:@selector(pushDemo)];
    self.navigationItem.rightBarButtonItems = @[bbi,demo];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height - 64) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIView new];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.rowHeight = 50;
    [self.view addSubview:_tableView];
    WEAKSELF(this);
    _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        this.page = 0;
        [this urlHandleDatas];
    }];
    _tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        this.page ++;
        [this urlHandleDatas];
    }];
}

- (void)bbiAction{
    [FSKit pushToViewControllerWithClass:@"FSAddUrlController" navigationController:self.navigationController param:nil configBlock:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.textLabel.font = FONTFC(15);
        cell.detailTextLabel.font = FONTFC(13);
        cell.detailTextLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
    }
    FSUrlModel *model = self.list[indexPath.row];
    cell.textLabel.text = model.name;
    cell.detailTextLabel.text = model.url;
    return cell;
}

- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewRowAction *action0 = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"编辑" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
        FSUrlModel *model = self.list[indexPath.row];
        [FSKit pushToViewControllerWithClass:@"FSAddUrlController" navigationController:self.navigationController param:@{@"model":model} configBlock:nil];
    }];
    action0.backgroundColor = THISCOLOR;
    
    UITableViewRowAction *action1 = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDefault title:NSLocalizedString(@"Delete", nil) handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
        FSUrlModel *model = self.list[indexPath.row];
        [FSBaseAPI deleteModelBusiness:model table:_tb_url controller:self success:^{
            [self.list removeObjectAtIndex:indexPath.row];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        } fail:^(NSString *error) {
            [FSUIKit showAlertWithMessage:error controller:self];
        } cancel:^{
            tableView.editing = NO;
        }];        
    }];
    return @[action1, action0];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    FSUrlModel *model = self.list[indexPath.row];
    FSWebKitController *webController = [[FSWebKitController alloc] init];
    webController.urlString = model.url;
    [self.navigationController pushViewController:webController animated:YES];
    [self updateCount:model];
    [FSTrack event:_UMeng_Event_url_tap];
}

- (void)updateCount:(FSUrlModel *)model{
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET count = '%@' WHERE aid = %@;",_tb_url,@([model.count integerValue] + 1),model.aid];
    [master updateSQL:sql];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
