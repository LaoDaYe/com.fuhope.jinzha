//
//  FSInputTableView.m
//  MVVM
//
//  Created by Fudongdong on 2017/8/7.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSInputTableView.h"

@interface FSInputTableView ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@end

@implementation FSInputTableView{
    CGFloat _initHeight;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _initHeight = frame.size.height;
        _textField = [[UITextField alloc] initWithFrame:CGRectMake(15, 20, self.frame.size.width - 30, self.frame.size.height - 40)];
        _textField.textAlignment = NSTextAlignmentCenter;
        _textField.backgroundColor = [UIColor whiteColor];
        _textField.placeholder = @"输入网址，如apple";
        _textField.delegate = self;
        _textField.keyboardType = UIKeyboardTypeASCIICapable;
        _textField.autocorrectionType = UITextAutocorrectionTypeNo;
        _textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _textField.spellCheckingType = UITextSpellCheckingTypeNo;
        _textField.font = [UIFont systemFontOfSize:15];
        _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        [_textField addTarget:self action:@selector(textFieldEdit:) forControlEvents:UIControlEventEditingChanged];
        [self addSubview:_textField];
    }
    return self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.numberOfRowsInSection) {
        return self.numberOfRowsInSection();
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if (self.textCallback) {
        cell.textLabel.text = self.textCallback(_textField.text,indexPath.row);
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_didSelectCallback) {
        _didSelectCallback(_textField.text,indexPath.row);
    }
    [self textFieldEdit:nil];
}

- (void)textFieldEdit:(UITextField *)textField{
    [self.superview bringSubviewToFront:self];
    CGFloat tableHeight = textField.text.length?_tableHeight:0;
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, tableHeight + _initHeight);
    [self.tableView reloadData];
    self.tableView.frame = CGRectMake(0, _initHeight, self.frame.size.width, tableHeight);
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [self textFieldEdit:textField];
    return YES;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _initHeight, self.frame.size.width, 0) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        [self addSubview:_tableView];
    }
    return _tableView;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
