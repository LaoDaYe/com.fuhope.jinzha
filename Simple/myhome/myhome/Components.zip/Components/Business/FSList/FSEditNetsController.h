//
//  FSEditNetsController.h
//  myhome
//
//  Created by Fudongdong on 2017/8/14.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSEditNetsController : FSBaseController

@end
