//
//  FSAddUrlController.h
//  myhome
//
//  Created by FudonFuchina on 2017/7/18.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"
#import "FSUrlModel.h"

@interface FSAddUrlController : FSBaseController

@property (nonatomic,strong) FSUrlModel     *model;

@end
