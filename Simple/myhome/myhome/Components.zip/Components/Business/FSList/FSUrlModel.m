//
//  FSUrlModel.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/18.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSUrlModel.h"

@implementation FSUrlModel

+ (NSArray<NSString *> *)tableFields{
    return @[@"time",@"name",@"url",@"type",@"count"];
}

@end
