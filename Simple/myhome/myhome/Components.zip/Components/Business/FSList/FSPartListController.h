//
//  FSPartListController.h
//  myhome
//
//  Created by fudon on 2017/2/16.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSPartListController : FSBaseController

@end
