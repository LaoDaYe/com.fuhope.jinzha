//
//  FSDemoUrlController.m
//  myhome
//
//  Created by FudonFuchina on 2017/7/25.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSDemoUrlController.h"
#import "FSShopClassView.h"
#import "FSWebKitController.h"
#import "FSSameKindController.h"
#import "FuSoft.h"
#import "FSTrackKeys.h"

@interface FSDemoUrlController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,assign) NSInteger          index;
@property (nonatomic,strong) UITableView        *tableView;
@property (nonatomic,strong) NSArray            *dataList;

@end

@implementation FSDemoUrlController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Wap navigation", nil);
    _dataList = [self configDatas];
    
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:self.dataList.count];
    for (int x = 0; x < self.dataList.count; x ++) {
        NSDictionary *dic = [self.dataList objectAtIndex:x];
        NSString *text = [dic objectForKey:@"text"];
        [array addObject:text];
    }
    
    FSShopClassView *shopClassView = [[FSShopClassView alloc] initWithFrame:CGRectMake(0, 64, 90, 455)];
    shopClassView.dataSource = array;
    [self.view addSubview:shopClassView];
    WEAKSELF(this);
    [shopClassView setSelectedBlock:^(FSShopClassView *bView, NSInteger bIndex) {
        this.index = bIndex;
    }];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(90, 64, self.view.bounds.size.width - 90, self.view.bounds.size.height - 64 - 49) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIView new];
    _tableView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_tableView];
    
    [FSTrack event:_UMeng_Event_wap_navigation];
}

- (void)setIndex:(NSInteger)index{
    if (_index != index) {
        _index = index;
        
        [_tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSDictionary *dic = self.dataList[_index];
    NSArray *array = dic[@"array"];
    return array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.textLabel.font = FONTFC(14);
        cell.detailTextLabel.font = FONTFC(10);
    }
    NSDictionary *dic = self.dataList[_index];
    NSArray *array = dic[@"array"];
    NSDictionary *value = [array objectAtIndex:indexPath.row];
    cell.textLabel.text = value[Text_Name];
    cell.detailTextLabel.text = value[Url_String];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = self.dataList[_index];
    NSArray *array = dic[@"array"];
    NSDictionary *value = [array objectAtIndex:indexPath.row];
    NSString *url = value[Url_String];
    
    FSWebKitController *webController = [[FSWebKitController alloc] init];
    webController.urlString = url;
    [self.navigationController pushViewController:webController animated:YES];
    [FSTrack event:_UMeng_Event_wap_nav_push];
}

- (NSArray *)configDatas{
    NSArray *confitDatas = @[
                             @{
                                 @"text":@"平时常用",
                                 @"array":  @[
                                         @{Text_Name:@"百度",Url_String:@"https://www.baidu.com"},
                                         @{Text_Name:@"天猫",Url_String:@"https://www.tmall.com"},
                                         @{Text_Name:@"京东商城",Url_String:@"http://m.jd.com"},
                                         @{Text_Name:@"淘宝",Url_String:@"https://m.taobao.com"},
                                         @{Text_Name:@"美团",Url_String:@"http://i.meituan.com"},
                                         @{Text_Name:@"饿了么",Url_String:@"http://m.ele.me"},
                                         @{Text_Name:@"hao123",Url_String:@"https://www.hao123.com"},
                                              ]
                                 },
                             
                             @{
                                 @"text":@"购物消费",
                                 @"array":@[
                                         @{Text_Name:@"天猫",Url_String:@"https://www.tmall.com"},
                                         @{Text_Name:@"京东商城",Url_String:@"http://m.jd.com"},
                                         @{Text_Name:@"淘宝",Url_String:@"https://m.taobao.com"},
                                         @{Text_Name:@"亚马逊",Url_String:@"https://www.amazon.cn"},
                                         @{Text_Name:@"国美电器",Url_String:@"http://m.gome.com.cn"},
                                         @{Text_Name:@"苏宁易购",Url_String:@"http://m.suning.com"},
                                         @{Text_Name:@"唯品会",Url_String:@"http://m.vip.com"},
                                         @{Text_Name:@"1688",Url_String:@"http://m.1688.com"},
                                         @{Text_Name:@"聚美优品",Url_String:@"http://m.jumei.com"},
                                         @{Text_Name:@"一号店",Url_String:@"http://m.yhd.com"},
                                         @{Text_Name:@"蘑菇街",Url_String:@"http://m.mogujie.com"},
                                         @{Text_Name:@"酒仙网",Url_String:@"http://m.jiuxian.com"},
                                         @{Text_Name:@"小米官网",Url_String:@"http://m.mi.com"},
                                         ],
                                 },
                             
                             @{
                                 @"text":@"生活服务",
                                 @"array":@[
                                         @{Text_Name:@"美团",Url_String:@"http://i.meituan.com"},
                                         @{Text_Name:@"百度外卖",Url_String:@"http://waimai.baidu.com"},
                                         @{Text_Name:@"饿了么",Url_String:@"http://m.ele.me"},
                                         @{Text_Name:@"百度糯米",Url_String:@"https://m.nuomi.com"},
                                         @{Text_Name:@"大众点评",Url_String:@"http://m.dianping.com"},
                                         @{Text_Name:@"58同城",Url_String:@"http://m.58.com"},
                                         @{Text_Name:@"赶集网",Url_String:@"http://m.ganji.com"},
                                         ],
                                 },
                             
                             @{
                                 @"text":@"新闻信息",
                                 @"array":@[
                                         @{Text_Name:@"腾讯新闻",Url_String:@"http://xw.qq.com"},
                                         @{Text_Name:@"网易",Url_String:@"http://3g.163.com"},
                                         @{Text_Name:@"新浪新闻",Url_String:@"http://www.sina.cn"},
                                         @{Text_Name:@"新浪博客",Url_String:@"http://blog.sina.cn"},
                                         @{Text_Name:@"新浪微博",Url_String:@"http://www.weibo.com"},
                                         @{Text_Name:@"搜狐",Url_String:@"http://www.sohu.com"},
                                         @{Text_Name:@"凤凰",Url_String:@"http://i.ifeng.com"},
                                         @{Text_Name:@"简书",Url_String:@"http://www.jianshu.com"},
                                         ]
                                 },
                             
                             @{
                                 @"text":@"影视娱乐",
                                 @"array":@[
                                         @{Text_Name:@"优酷",Url_String:@"http://www.youku.com"},
                                         @{Text_Name:@"爱奇艺",Url_String:@"http://m.iqiyi.com"},
                                         @{Text_Name:@"腾讯视频",Url_String:@"http://m.v.qq.com"},
                                         @{Text_Name:@"乐视视频",Url_String:@"http://m.le.com"},
                                         ],
                                 },
                             ];
    return confitDatas;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
