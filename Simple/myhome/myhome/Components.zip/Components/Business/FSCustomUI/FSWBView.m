//
//  FSWBView.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/8/13.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSWBView.h"
#import "FSImageLabelView.h"
#import "FuSoft.h"
#import "UIViewExt.h"

@interface FSWBView ()

@property (nonatomic,strong) UIView     *menuView;

@end

@implementation FSWBView

- (instancetype)initWithFrame:(CGRect)frame controller:(UIViewController *)controller{
    self = [super initWithFrame:frame controller:controller];
    if (self) {
        [self wbDesignViews];
    }
    return self;
}

- (void)wbDesignViews{
    self.frame = [UIScreen mainScreen].bounds;
    
    WEAKSELF(this);
    self.backTapBlock = ^ (){
        [this showWBView:NO];
    };
    
    CGFloat width = (WIDTHFC - 100) / 4;
    CGFloat height = (width + 45) * 2 + 45 + 10;
    _menuView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height, self.width, height + 34 * FS_iPhone_X)];
    _menuView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_menuView];
    [self showWBView:YES];
    
    NSArray *array = @[@"退出",@"刷新",@"复制链接",@"Safari打开",@"微信",@"收藏",@"邮件",@"短信"];
    NSArray *picArray = @[@"exit_icon",@"refresh_icon",@"wbview_copy",@"safari_icon",@"fsshare_wechat",@"apps_alert",@"fsshare_email",@"fsshare_msg"];
    
    for (int x = 0; x < array.count; x ++) {
        FSImageLabelView *imageView = [FSImageLabelView imageLabelViewWithFrame:CGRectMake(20 + (x % 4) * (width + 20), 45 + (x / 4) * (width + 45), width, width + 25) imageName:picArray[x] text:array[x]];
        imageView.block = ^ (FSImageLabelView *bImageLabelView){
            [this imageViewAction:bImageLabelView];
        };
        imageView.tag = TAG_IMAGEVIEW + x;
        [_menuView addSubview:imageView];
    }
}

- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, WIDTHFC - 40, 35)];
        _titleLabel.font = [UIFont systemFontOfSize:12];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.textColor = [UIColor colorWithRed:200 / 255.0 green:200 /255.0 blue:200 / 255.0 alpha:1.0];
        [_menuView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (void)imageViewAction:(FSImageLabelView *)bView{
    if (_block) {
        _block(self,bView.tag - TAG_IMAGEVIEW);
        [self showWBView:NO];
    }
}

- (void)tapAction{
    [self showWBView:NO];
}

- (void)showWBView:(BOOL)show{
    CGFloat width = (WIDTHFC - 100) / 4;
    CGFloat height = (width + 45) * 2 + 45 + 10;

    [UIView animateWithDuration:.3 animations:^{
        self.menuView.top = self.height - show * (height + 34 * FS_iPhone_X);
    } completion:^(BOOL finished) {
        if (!show) {
            [self removeFromSuperview];
        }
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
