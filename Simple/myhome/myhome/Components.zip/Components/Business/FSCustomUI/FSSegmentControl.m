//
//  FSSegmentControl.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/8/7.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSSegmentControl.h"
#import "FSViewManager.h"
#import "FSMacro.h"

@implementation FSSegmentControl

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self scDesignViews];
    }
    return self;
}

- (void)scDesignViews
{
    self.layer.cornerRadius = 3;
    self.layer.borderColor = FSAPPCOLOR.CGColor;
    self.layer.borderWidth = 1;

    for (int x = 0; x < 2; x ++) {
        UIButton *button = [FSViewManager buttonWithFrame:CGRectMake(self.width / 2 * x, 0, self.width / 2, self.height) title:x?@"下一月":@"上一月" titleColor:nil backColor:nil fontInt:13 tag:x target:self selector:@selector(buttonAction:)];
        [button setTitleColor:FSAPPCOLOR forState:UIControlStateNormal];
        [self addSubview:button];
        if (x) {
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, self.height)];
            lineView.backgroundColor = FSAPPCOLOR;
            [button addSubview:lineView];
        }
    }
}

- (void)buttonAction:(UIButton *)button
{
    button.backgroundColor = [UIColor whiteColor];
    [self performSelector:@selector(backButtonBackColor:) withObject:button];
    
    if (_block) {
        _block(self,button.tag);
    }
}

- (void)backButtonBackColor:(UIButton *)button
{
    [UIView animateWithDuration:.3 animations:^{        
        button.backgroundColor = [UIColor clearColor];
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
