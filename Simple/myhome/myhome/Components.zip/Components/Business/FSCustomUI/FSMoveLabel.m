//
//  FSMoveLabel.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/8/21.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSMoveLabel.h"

@interface FSMoveLabel ()

@property (nonatomic,strong) UILabel        *label;
@property (nonatomic,strong) UILabel        *backLabel;
@property (nonatomic,strong) CADisplayLink  *link;

@end

@implementation FSMoveLabel

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self moveDesignViews];
    }
    return self;
}

- (void)moveDesignViews{
    _label = [[UILabel alloc] initWithFrame:self.bounds];
    _label.textColor = [UIColor whiteColor];
    _label.font = [UIFont systemFontOfSize:13];
    [self addSubview:_label];
    
    _backLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.bounds.size.width, 0, self.bounds.size.width, self.bounds.size.height)];
    _backLabel.textColor = [UIColor whiteColor];
    _backLabel.font = [UIFont systemFontOfSize:13];
    [self addSubview:_backLabel];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [self addGestureRecognizer:tap];
    
    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(linkAction)];
    [_link addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)tapAction{
    if (_tapBlock) {
        _tapBlock(self);
    }
}

- (void)setText:(NSString *)text{
    if (_text != text) {
        _text = text;
        
        _label.text = text;
        [_label sizeToFit];
        _label.frame = CGRectMake(self.bounds.size.width / 4, 0, _label.bounds.size.width, self.bounds.size.height);
        
        _backLabel.text = text;
        [_backLabel sizeToFit];
        _backLabel.frame = CGRectMake(self.bounds.size.width, 0, _backLabel.bounds.size.width, self.bounds.size.height);
    }
}

- (void)setTextColor:(UIColor *)textColor{
    _textColor = textColor;
    _label.textColor = textColor;
    _backLabel.textColor = textColor;
}

- (void)linkAction{
    [self repeatDoing];
}

- (void)repeatDoing{
    CGFloat offset = .5f;
    self.label.frame = CGRectMake(self.label.frame.origin.x - offset, 0, self.label.bounds.size.width, self.label.bounds.size.height);
    if ((self.label.frame.origin.x < 0) && ((self.label.frame.origin.x + self.label.frame.size.width) < self.frame.size.width)){
        CGFloat left = self.bounds.size.width + self.label.frame.origin.x;
        if (left > (self.label.frame.origin.x + self.label.frame.size.width)) {
            self.backLabel.frame = CGRectMake(left, 0, self.backLabel.frame.size.width, self.backLabel.frame.size.height);
        }else{
            self.backLabel.frame = CGRectMake(self.label.frame.origin.x + self.label.frame.size.width + 60, 0, self.backLabel.bounds.size.width, self.backLabel.bounds.size.height);
        }
    }
    
    if ((self.label.frame.origin.x + self.label.frame.size.width) < 0) {
        self.label.frame = CGRectMake(self.backLabel.frame.origin.x, 0, self.label.bounds.size.width, self.label.bounds.size.height);
        self.backLabel.frame = CGRectMake(self.frame.size.width, 0, self.backLabel.bounds.size.width, self.backLabel.bounds.size.height);
    }
}

- (void)setHidden:(BOOL)hidden{
    [super setHidden:hidden];
    _link.paused = hidden;
}

- (void)start{
    _link.paused = NO;
}

- (void)stop{
    _link.paused = YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
