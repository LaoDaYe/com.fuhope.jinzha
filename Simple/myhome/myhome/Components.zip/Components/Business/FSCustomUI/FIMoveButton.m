//
//  FIMoveButton.m
//  FuHope
//
//  Created by FudonFuchina on 15/8/29.
//  Copyright (c) 2015年 ronglian. All rights reserved.
//

#import "FIMoveButton.h"

#define tarbarHeight     0
#define navbarHeight     64

@interface FIMoveButton ()

@property (nonatomic,strong) UILabel    *label;

@end

@implementation FIMoveButton{
    CGPoint             _staticPoint;
    UILabel             *_numberLabel;
    BOOL                _isDoubleTap;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self fbDesignViews];
    }
    return self;
}

- (void)fbDesignViews{
    [self doSomethingRepeatedly];
    
    CGFloat selfHeight = self.bounds.size.height;
    _label = [[UILabel alloc] initWithFrame:CGRectMake(.25 * selfHeight, 0.25 * selfHeight, 0.5 * selfHeight, 0.5 * selfHeight)];
    _label.textAlignment = NSTextAlignmentCenter;
    _label.textColor = [UIColor whiteColor];
    _label.text = @"^_^";
    [self addSubview:_label];
    
    UITapGestureRecognizer *singleTapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    [singleTapGestureRecognizer setNumberOfTapsRequired:1];
    [self addGestureRecognizer:singleTapGestureRecognizer];
    
    UITapGestureRecognizer *doubleTapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction2:)];
    [doubleTapGestureRecognizer setNumberOfTapsRequired:2];
    [self addGestureRecognizer:doubleTapGestureRecognizer];
    
    UITapGestureRecognizer *threeTapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction3:)];
    [threeTapGestureRecognizer setNumberOfTapsRequired:3];
    [self addGestureRecognizer:threeTapGestureRecognizer];
    
    //这行很关键，意思是只有当没有检测到doubleTapGestureRecognizer 或者 检测doubleTapGestureRecognizer失败，singleTapGestureRecognizer才有效
    [singleTapGestureRecognizer requireGestureRecognizerToFail:doubleTapGestureRecognizer];
    [doubleTapGestureRecognizer requireGestureRecognizerToFail:threeTapGestureRecognizer];
}

- (void)tapAction:(UITapGestureRecognizer *)tap{
    _label.text = @"^_^";
    if (_tapBlock) {
        _tapBlock(self,1);
    }
}

- (void)tapAction2:(UITapGestureRecognizer *)tap{
    _label.text = @"^_^";
    if (_tapBlock) {
        _tapBlock(self,2);
    }
}

- (void)tapAction3:(UITapGestureRecognizer *)tap{
    _label.text = @"^_^";
    if (_tapBlock) {
        _tapBlock(self,3);
    }
}

- (void)doSomethingRepeatedly{
    [self changeBackgroundColor];
    
    __weak typeof(self)this = self;
    double delayInSeconds = 10.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [this doSomethingRepeatedly];
    });
}

- (void)changeBackgroundColor{
    CGFloat r = arc4random_uniform(256) / 255.0;
    CGFloat g = arc4random_uniform(256) / 255.0;
    CGFloat b = arc4random_uniform(256) / 255.0;
    UIColor *randomColor = [UIColor colorWithRed:r green:g blue:b alpha:1];
    [UIView animateWithDuration:.3 animations:^{
        self.backgroundColor = randomColor;
    }];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    _label.text = @"^v^";
    
    UITouch *touch = [touches anyObject];
    _staticPoint = [touch locationInView:self.superview];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint currentLocation = [touch locationInView:self.superview];
    self.center = currentLocation;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    _label.text = @"^_^";

    CGFloat xPoint = self.center.x;
    CGFloat yPoint = self.center.y;
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    CGFloat selfHeight = self.bounds.size.height;
    
    if (yPoint > (size.height - selfHeight / 2 - tarbarHeight - 10)) {
        xPoint = self.center.x;
        yPoint = (size.height - selfHeight / 2 - tarbarHeight - 10);
    }else if (yPoint < (navbarHeight + selfHeight / 2 + 10)){
        xPoint = self.center.x;
        yPoint = navbarHeight + selfHeight / 2 + 10;
    }
    xPoint = MAX(xPoint, self.bounds.size.width / 2 + 10);
    xPoint = MIN(xPoint, size.width - self.bounds.size.width / 2 - 10);
    
    [UIView animateWithDuration:.3 animations:^{
        self.center = CGPointMake(xPoint, yPoint);
    }];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
