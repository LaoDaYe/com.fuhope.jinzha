//
//  FSGestureController.m
//  myhome
//
//  Created by FudonFuchina on 2017/8/31.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSGestureController.h"
#import "FSGestureView.h"
#import <FSKit.h>
#import "FSCryptorSupport.h"
#import "FSToast.h"
#import <FSUIKit.h>
#import "FSKeyValueCryptor.h"
#import <objc/runtime.h>

@interface FSGestureController ()

@property (nonatomic,strong) UILabel   *label;

@end

@implementation FSGestureController{
    FSGestureView   *_gestureView;
    NSString        *_setPwd;
}

#if DEBUG
- (void)dealloc{
    NSLog(@"%s",__FUNCTION__);
}
#endif

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self gestureDesignViews];
}

- (void)gestureDesignViews{
    self.title = (_mode == FSGestureModeChange?NSLocalizedString(@"Update gesture code", nil):NSLocalizedString(@"Set gesture code", nil));
    
    if (!_hiddenTopLeftCancelButton) {
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", nil) style:UIBarButtonItemStylePlain target:self action:@selector(cancelGesture)];
        self.navigationItem.leftBarButtonItem = bbi;
    }
    
    CGFloat width = self.view.bounds.size.width;
    _label = [[UILabel alloc] initWithFrame:CGRectMake(15, 80, width - 30, 30)];
    _label.font = [UIFont systemFontOfSize:14];
    _label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:_label];
    if (_mode == FSGestureModeChange) {
        _label.text = NSLocalizedString(@"Please input old password", nil);
    }else if (_mode == FSGestureModeSet){
        _label.text = NSLocalizedString(@"Please set password", nil);
    }
    
    _gestureView = [[FSGestureView alloc] initWithFrame:CGRectMake(15, 110, width - 30, width - 30)];
    [self.view addSubview:_gestureView];
    __weak typeof(self)this = self;
    _gestureView.result = ^(NSString *bResult) {
        [this handleResult:bResult];
    };
    _gestureView.start = ^{
        this.label.text = @"";
    };
}

- (void)cancelGesture{
    if (self.cancelInputPassword) {
        self.cancelInputPassword();
    }else{
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];        
    }
}

- (void)handleResult:(NSString *)result{
    switch (_mode) {
        case FSGestureModeSet:{
            if (result.length < 4) {
                [FSToast show:NSLocalizedString(@"Must 4 points or more", nil)];
                return;
            }
            if (_setPwd) {
                if ([result isEqualToString:_setPwd]) {
                    [FSKeyValueCryptor setGesturePassword:result];
                    [FSToast show:NSLocalizedString(@"Set success", nil)];
                    if (self.setedSuccess) {
                        self.setedSuccess(self);
                    }
                }else{
                    [self labelRedString:NSLocalizedString(@"The input is not consistent, please re-enter", nil)];
                    _setPwd = nil;
                }
            }else{
                _setPwd = result;
                [self labelBlackString:NSLocalizedString(@"Please input again to confirm", nil)];
            }
        }break;
        case FSGestureModeChange:{
            NSString *pwd = [FSKeyValueCryptor gesturePassword];
            if ([pwd isEqualToString:result]) {
                _mode = FSGestureModeSet;
                [self labelBlackString:NSLocalizedString(@"Please set a new gesture pwd", nil)];
            }else{
                [self labelRedString:NSLocalizedString(@"Verify fail,please input again", nil)];
            }
        }break;
        default:
            break;
    }
}

- (void)labelRedString:(NSString *)string{
    _label.text = string;
    _label.textColor = [UIColor redColor];
}

- (void)labelBlackString:(NSString *)string{
    _label.text = string;
    _label.textColor = [UIColor blackColor];
}

+ (BOOL)hasSettedPassword{
    NSString *pwd = [FSKeyValueCryptor gesturePassword];
    return _fs_isValidateString(pwd);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

+ (void)setHavedBeUnlockGesture:(BOOL)did{
    _haveUnlockedGesture = did;
}

+ (BOOL)isNeedUnlockGesture{
    return _haveUnlockedGesture == NO;
}

+ (BOOL)shouldAlertGesture{
    return _shouldAlertGesture;
}

+ (void)setShouldAlertGesture:(BOOL)shouldAlert{
    _shouldAlertGesture = shouldAlert;
}

static BOOL _haveUnlockedGesture = NO;
static BOOL _shouldAlertGesture = NO;

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
