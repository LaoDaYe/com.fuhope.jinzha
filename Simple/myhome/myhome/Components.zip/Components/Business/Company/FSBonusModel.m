//
//  FSBonusModel.m
//  myhome
//
//  Created by FudonFuchina on 2017/11/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBonusModel.h"

@implementation FSBonusModel

+ (NSArray<NSString *> *)tableFields{
    return @[@"time",@"name",@"year",@"cash"];
}

@end
