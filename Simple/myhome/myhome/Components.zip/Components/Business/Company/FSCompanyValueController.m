//
//  FSCompanyValueController.m
//  Expand
//
//  Created by Fudongdong on 2017/11/21.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSCompanyValueController.h"
#import <FSTuple.h>
#import "FSBonusController.h"
#import "FSSelectController.h"
#import "FSDBMaster.h"
#import "FSDBSupport.h"

@interface FSCompanyValueController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;

@end

@implementation FSCompanyValueController{
    NSArray     *_list;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self companyValueHandleDatas];
}

- (void)companyValueHandleDatas{
    CGFloat fz = [_model.fz doubleValue];
    CGFloat zzc = MAX(0.1, [_model.zzc doubleValue]);
    CGFloat zcfzlNumber = fz / zzc;
    NSString *zcfzl = [[NSString alloc] initWithFormat:@"%.2f%%",zcfzlNumber * 100];
    CGFloat yushou = [_model.yskx doubleValue];
    CGFloat nysZZFZL = fz - yushou;
    NSString *wuyszcfzl = [[NSString alloc] initWithFormat:@"%.2f%%",(nysZZFZL / zzc) * 100];

    // 过去的分红
    NSString *year = [_model.period substringWithRange:NSMakeRange(0, 4)];
    NSInteger yn = [year integerValue];
    NSString *upOne = @(yn -1).stringValue;
    NSString *upTwo = @(yn - 2).stringValue;
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE (year = '%@' OR year = '%@' OR year = '%@') and name = '%@';",_tb_bs_bonus,year,upOne,upTwo,_model.name];
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSArray *list = [master querySQL:sql tableName:_tb_bs_bonus];
    CGFloat bonus = 0;
    for (NSDictionary *dic in list) {
        NSString *cash = dic[@"cash"];
        bonus += [cash doubleValue];
    }
    CGFloat rate = [_model.gsymgs doubleValue] / MAX(0.1, [_model.syzqy doubleValue]);
    CGFloat value = ([_model.ldzc doubleValue] + [_model.fldzc doubleValue] * .5 + 0 - [_model.fz doubleValue]) * rate;
    NSString *price = [[NSString alloc] initWithFormat:@"%.2f(%.2f) 亿",value + bonus,bonus];

    _list = @[
              [Tuple2 v1:zcfzl v2:@"资产负债率"],
              [Tuple2 v1:wuyszcfzl v2:@"资产负债率(-预收)"],
              [Tuple2 v1:price v2:@"公司价值"],
              ];
    
    
    [self companyValueDesignViews];
}

- (void)companyValueDesignViews{
    if (!_tableView) {
        self.title = _model.name;
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:@"三年分红" style:UIBarButtonItemStylePlain target:self action:@selector(bonusEvent)];
        self.navigationItem.rightBarButtonItem = bbi;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 55;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
        
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
    }
}

- (void)bonusEvent{
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE name = '%@';",_tb_bs_bonus,_model.name];
    NSArray *list = [FSDBSupport querySQL:sql class:FSBonusModel.class tableName:_tb_bs_bonus];
    if (!list.count) {
        FSBonusController *b = [[FSBonusController alloc] init];
        b.name = _model.name;
        [self.navigationController pushViewController:b animated:YES];
        return;
    }
    FSSelectController *select = [[FSSelectController alloc] init];
    select.title = _model.name;
    select.array = list;
    [self.navigationController pushViewController:select animated:YES];
    select.configCell = ^(UITableViewCell *bCell, NSIndexPath *bIndexPath, NSArray *bArray) {
        FSBonusModel *model = bArray[bIndexPath.row];
        bCell.textLabel.text = model.year;
        bCell.detailTextLabel.text = model.cash;
    };
    WEAKSELF(this);
    select.block = ^(FSSelectController *bSelectController, NSIndexPath *bIndexPath, NSArray *bArray) {
        FSBonusModel *model = bArray[bIndexPath.row];
        FSBonusController *b = [[FSBonusController alloc] init];
        b.model = model;
        [this.navigationController pushViewController:b animated:YES];
    };
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:16];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
    }
    Tuple2 *t = _list[indexPath.row];
    cell.textLabel.text = t._2;
    cell.detailTextLabel.text = t._1;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 1) {
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
