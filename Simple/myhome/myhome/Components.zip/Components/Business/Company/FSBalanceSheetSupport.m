//
//  FSBalanceSheetSupport.m
//  Expand
//
//  Created by Fudongdong on 2017/11/21.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSBalanceSheetSupport.h"
#import "FSMacro.h"
#import "FSDBMaster.h"
#import <FSUIKit.h>

@implementation FSBalanceSheetSupport

+ (void)addBalanceSheet:(FSBalanceSheetModel *)_model controller:(UIViewController *)controller completion:(void(^)(void))comp{
    if (![_model isKindOfClass:FSBalanceSheetModel.class]) {
        return;
    }
    if (![controller isKindOfClass:UIViewController.class]) {
        return;
    }
    if (!_fs_isValidateString(_model.name)) {
        [FSToast show:@"请填写正确的公司名字"];
        return;
    }
    if (!(_fs_isValidateString(_model.period) && _model.period.length == 6 && _fs_isPureInt(_model.period))) {
        [FSToast show:@"请填写年期，格式如：201704，表示2017年年报"];
        return;
    }
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *sql = [[NSString alloc] initWithFormat:@"INSERT INTO %@ (time,name,period,bz,hbzj,jyxjrzc,yspj,yszk,yfkx,yslx,ysgl,qtysk,ch,ynndq,qtldzc,ldzc,kgcsjr,dqtz,cqysk,cqgqtz,tzxfdc,gdzc,zjgc,gcwz,gdzcql,scxswzc,yqzc,wxzc,kfzc,sy,cqdtfy,dysds,qtfldzc,fldzc,zzc,dqjk,jyxjrfz,yfpj,yfzk,yskx,yfzgxc,yjsf,yflx,yfgl,qtyfk,ynndqfz,qtldfz,ldfz,cqjk,yfzq,cqyfk,zxyfk,dysdsfz,qtfldfz,fldfz,fz,sszb,zbgj,kcg,yygj,wfplr,gsymgs,ssgdqy,syzqy) VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\");",
                     _tb_bs_vanke,
                     @(_fs_integerTimeIntevalSince1970()),
                     _model.name,
                     _model.period,
                     _model.bz,
                     _model.hbzj,
                     _model.jyxjrzc,
                     _model.yspj,
                     _model.yszk,
                     _model.yfkx,
                     _model.yslx,
                     _model.ysgl,
                     _model.qtysk,
                     _model.ch,
                     _model.ynndq,
                     _model.qtldzc,
                     _model.ldzc,
                     _model.kgcsjr,
                     _model.dqtz,
                     _model.cqysk,
                     _model.cqgqtz,
                     _model.tzxfdc,
                     _model.gdzc,
                     _model.zjgc,
                     _model.gcwz,
                     _model.gdzcql,
                     _model.scxswzc,
                     _model.yqzc,
                     _model.wxzc,
                     _model.kfzc,
                     _model.sy,
                     _model.cqdtfy,
                     _model.dysds,
                     _model.qtfldzc,
                     _model.fldzc,
                     _model.zzc,
                     _model.dqjk,
                     _model.jyxjrfz,
                     _model.yfpj,
                     _model.yfzk,
                     _model.yskx,
                     _model.yfzgxc,
                     _model.yjsf,
                     _model.yflx,
                     _model.yfgl,
                     _model.qtyfk,
                     _model.ynndqfz,
                     _model.qtldfz,
                     _model.ldfz,
                     _model.cqjk,
                     _model.yfzq,
                     _model.cqyfk,
                     _model.zxyfk,
                     _model.dysdsfz,
                     _model.qtfldfz,
                     _model.fldfz,
                     _model.fz,
                     _model.sszb,
                     _model.zbgj,
                     _model.kcg,
                     _model.yygj,
                     _model.wfplr,
                     _model.gsymgs,
                     _model.ssgdqy,
                     _model.syzqy];
    
    NSString *error = @"未实现";
    if (error) {
        [FSUIKit showAlertWithMessage:error controller:controller];
    }else{
        [FSToast show:@"已保存"];
        if (comp) {
            comp();
        }
    }
}

@end
