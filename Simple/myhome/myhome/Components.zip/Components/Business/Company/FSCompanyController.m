//
//  FSCompanyController.m
//  Expand
//
//  Created by Fudongdong on 2017/11/21.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSCompanyController.h"
#import "FSSubjectsController.h"
#import "FSDBMaster.h"
#import "FSMacro.h"
#import "FSDBSupport.h"
#import "FSSelectController.h"

@interface FSCompanyController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView     *tableView;
@property (nonatomic,strong) NSMutableArray  *list;
@property (nonatomic,assign) NSInteger       page;

@end

@implementation FSCompanyController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1.0];
    [self companyHandleDatas];
}

- (void)companyHandleDatas{
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT DISTINCT name FROM %@;",_tb_bs_vanke];
    NSMutableArray *array = [master querySQL:sql tableName:_tb_bs_vanke];
    if (_page == 0) {
        _list = array;
    }else{
        [_list addObjectsFromArray:array];
    }
    [self companyDesignViews];
}

- (void)companyDesignViews{
    if (!_tableView) {
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(bbiAction)];
        self.navigationItem.rightBarButtonItem = bbi;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 55;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
        
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
    }
}

- (void)bbiAction{
    FSSubjectsController *subject = [[FSSubjectsController alloc] init];
    subject.mode = FSSubjectModeAdd;
    subject.title = @"增加";
    [self.navigationController pushViewController:subject animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.textLabel.font = [UIFont systemFontOfSize:16];
    }
    NSDictionary *dic = [_list objectAtIndex:indexPath.row];
    cell.textLabel.text = [dic objectForKey:@"name"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *dic = [_list objectAtIndex:indexPath.row];
    NSString *name = dic[@"name"];
    if (!_fs_isValidateString(name)) {
        return;
    }
    NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@ WHERE name = '%@';",_tb_bs_vanke,name];
    NSArray *list = [FSDBSupport querySQL:sql class:FSBalanceSheetModel.class tableName:_tb_bs_vanke];
    if (list.count == 0) {
        return;
    }
    
    FSSelectController *select = [[FSSelectController alloc] init];
    select.title = name;
    select.array = list;
    [self.navigationController pushViewController:select animated:YES];
    select.configCell = ^(UITableViewCell *bCell, NSIndexPath *bIndexPath, NSArray *bArray) {
        FSBalanceSheetModel *model = bArray[bIndexPath.row];
        bCell.textLabel.text = model.period;
    };
    WEAKSELF(this);
    select.block = ^(FSSelectController *bSelectController, NSIndexPath *bIndexPath, NSArray *bArray) {
        FSBalanceSheetModel *model = bArray[bIndexPath.row];
        FSSubjectsController *subject = [[FSSubjectsController alloc] init];
        subject.mode = FSSubjectModeDefault;
        subject.title = name;
        subject.model = model;
        [this.navigationController pushViewController:subject animated:YES];
    };
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
