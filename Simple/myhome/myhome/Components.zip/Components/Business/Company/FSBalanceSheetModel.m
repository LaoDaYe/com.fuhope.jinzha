//
//  FSBalanceSheetModel.m
//  Expand
//
//  Created by Fudongdong on 2017/11/21.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSBalanceSheetModel.h"
#import <FSKit.h>
#import <FSRuntime.h>

@implementation FSBalanceSheetModel

+ (NSArray<NSString *> *)tableFiels{
    NSArray *ps = [FSRuntime propertiesForClass:NSClassFromString(@"FSBalanceSheetModel")];
    return ps;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        NSArray *list = [FSRuntime propertiesForClass:self.class];
        for (NSString *name in list) {
            [FSRuntime setValue:@"-1" forPropertyName:name ofObject:self];
        }
    }
    return self;
}

+ (NSString *)hansForSubjectOfBalanceSheetModel:(NSString *)subject{
    if (!([subject isKindOfClass:NSString.class] && subject.length)) {
        return @"";
    }
    static NSDictionary *all = nil;
    if (!all) {
        all = @{
                @"name":@"公司名字",
                @"period":@"年期",
                @"bz":@"备注",
                @"hbzj":@"货币资金",
                @"jyxjrzc":@"交易性金融资产",
                @"yspj":@"应收票据",
                @"yszk":@"应收账款",
                @"yfkx":@"预付款项",
                @"yslx":@"应收利息",
                @"ysgl":@"应收股利",
                @"qtysk":@"其他应收款",
                @"ch":@"存货",
                @"ynndq":@"一年内到期的非流动资产",
                @"qtldzc":@"其他流动资产",
                @"ldzc":@"流动资产",    // 1
                @"kgcsjr":@"可供出售金融资产",
                @"dqtz":@"持有至到期投资",
                @"cqysk":@"长期应收款",
                @"cqgqtz":@"长期股权投资",
                @"tzxfdc":@"投资性房地产",
                @"gdzc":@"固定资产",
                @"zjgc":@"在建工程",
                @"gcwz":@"工程物资",
                @"gdzcql":@"固定资产清理",
                @"scxswzc":@"生产性生物资产",
                @"yqzc":@"油气资产",
                @"wxzc":@"无形资产",
                @"kfzc":@"开发支出",
                @"sy":@"商誉",
                @"cqdtfy":@"长期待摊费用",
                @"dysds":@"递延所得税资产",
                @"qtfldzc":@"其他非流动资产",
                @"fldzc":@"非流动资产",  // 2
                @"zzc":@"资产总计",      // 3
                @"dqjk":@"短期借款",
                @"jyxjrfz":@"交易性金融负债",
                @"yfpj":@"应付票据",
                @"yfzk":@"应付账款",
                @"yskx":@"预收款项",
                @"yfzgxc":@"应付职工薪酬",
                @"yjsf":@"应交税费",
                @"yflx":@"应付利息",
                @"yfgl":@"应付股利",
                @"qtyfk":@"其他应付款",
                @"ynndqfz":@"一年内到期的非流动负债",
                @"qtldfz":@"其他流动负债",
                @"ldfz":@"流动负债",
                @"cqjk":@"长期借款",
                @"yfzq":@"应付债券",
                @"cqyfk":@"长期应付款",
                @"zxyfk":@"专项应付款",
                @"dysdsfz":@"递延所得税负债",
                @"qtfldfz":@"其他非流动负债",
                @"fldfz":@"非流动负债",
                @"fz":@"负债合计",
                @"sszb":@"实收资本",
                @"zbgj":@"资本公积",
                @"kcg":@"库存股",
                @"yygj":@"盈余公积",
                @"wfplr":@"未分配利润",
                @"gsymgs":@"归属于母公司股东权益",
                @"ssgdqy":@"少数股东权益",
                @"syzqy":@"所有者权益",
                };
    }
    NSString *hans = [all objectForKey:subject];
    return hans?:@"";
}

@end
