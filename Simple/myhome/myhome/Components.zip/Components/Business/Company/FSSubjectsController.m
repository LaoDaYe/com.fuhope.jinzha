//
//  FSSubjectsController.m
//  Expand
//
//  Created by Fudongdong on 2017/11/21.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSSubjectsController.h"
#import "UIViewController+BackButtonHandler.h"
#import "FSDBMaster.h"
#import "FSMacro.h"
#import "FSBalanceSheetSupport.h"
#import "FSCompanyValueController.h"
#import <FSUIKit.h>
#import <FSRuntime.h>

@interface FSSubjectsController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;

@end

@implementation FSSubjectsController{
    NSArray             *_subjects;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1.0];
    NSMutableArray *array = [[FSRuntime propertiesForClass:FSBalanceSheetModel.class] mutableCopy];
    [array removeObject:@"aid"];
    [array removeObject:@"time"];
    _subjects = [array copy];
    if (_mode == FSSubjectModeAdd) {
        _model = [[FSBalanceSheetModel alloc] init];
        [self subjectDesignViews];
    }else{
        [self subjectHandleDatas];
    }
}

- (void)subjectHandleDatas{
    [self subjectDesignViews];
}

- (void)subjectDesignViews{
    if (!_tableView) {
        UIBarButtonItem *bbi = nil;
        if (_mode == FSSubjectModeAdd) {
            bbi = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Add", nil) style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
        }else if (_mode == FSSubjectModeDefault){
            bbi = [[UIBarButtonItem alloc] initWithTitle:@"操作" style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
        }
        if (bbi) {
            self.navigationItem.rightBarButtonItem = bbi;
        }

        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 55;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
        
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
    }
}

- (void)bbiAction{
    BOOL isAdd = (_mode == FSSubjectModeAdd);
    NSString *check = @"检验";
    NSString *save = isAdd?@"保存":@"计算价值";
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[save,check] styles:@[@(UIAlertActionStyleDefault),@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        if (isAdd) {
            if ([action.title isEqualToString:check]) {
                [self checkData];
            }else if ([action.title isEqualToString:save]){
                [self addAction];
            }
        }else{
            if ([action.title isEqualToString:check]) {
                [self checkData];
            }else if ([action.title isEqualToString:save]){
                FSCompanyValueController *value = [[FSCompanyValueController alloc] init];
                value.model = self->_model;
                [self.navigationController pushViewController:value animated:YES];
            }
        }
    }];
}

- (void)checkData{
    // 1.检验 总资产 = 总负债 + 净资产
    CGFloat assert = [_model.zzc doubleValue];
    CGFloat fz = [_model.fz doubleValue];
    CGFloat jjz = [_model.syzqy doubleValue];
    if (fabs((assert - fz - jjz)) > 0.2) {
        [FSToast show:@"（总资产 = 净资产 + 负债）不成立"];
        return;
    }
    
    // 各个科目校验
    CGFloat ldzc = [_model.ldzc doubleValue];
    CGFloat hbzj = [_model.hbzj doubleValue];
    CGFloat jyxjrzc = [_model.jyxjrzc doubleValue];
    CGFloat yspj = [_model.yspj doubleValue];
    CGFloat yszk = [_model.yszk doubleValue];
    CGFloat yfkx = [_model.yfkx doubleValue];
    CGFloat yslx = [_model.yslx doubleValue];
    CGFloat ysgl = [_model.ysgl doubleValue];
    CGFloat qtysk = [_model.qtysk doubleValue];
    CGFloat ch = [_model.ch doubleValue];
    CGFloat yyndqfldzc = [_model.ynndq doubleValue];
    CGFloat qtldzc = [_model.qtldzc doubleValue];
    BOOL ldzcSubjects = hbzj + jyxjrzc + yspj + yszk + yfkx + yslx + ysgl + qtysk + ch + yyndqfldzc + qtldzc;
    CGFloat check = ldzc - ldzcSubjects;
    if (fabs(check) > 0.2) {
        [FSToast show:@"流动资产记录有错"];
        return;
    }
    
    // 各个子科目校验
}

- (void)addAction{
    [FSBalanceSheetSupport addBalanceSheet:_model controller:self completion:^{
        [self.navigationController popViewControllerAnimated:YES];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _subjects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:16];
        cell.textLabel.font = [UIFont systemFontOfSize:14];
    }
    NSString *object = _subjects[indexPath.row];
    cell.textLabel.text = [FSBalanceSheetModel hansForSubjectOfBalanceSheetModel:object];
    cell.detailTextLabel.text = [FSRuntime valueForGetSelectorWithPropertyName:object object:_model];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *object = _subjects[indexPath.row];
    if (_mode == FSSubjectModeAdd) {
        [self action:object table:tableView ip:indexPath isUpdate:NO];
    }else if (_mode == FSSubjectModeDefault){
        [self action:object table:tableView ip:indexPath isUpdate:YES];
    }
}

- (void)action:(NSString *)subject table:(UITableView *)tableView ip:(NSIndexPath *)indexPath isUpdate:(BOOL)update{
    BOOL requireFloat = YES;
    if (indexPath.row == 0 || indexPath.row == 2) {
        requireFloat = NO;
    }
    [FSUIKit alertInput:1 controller:self title:[FSBalanceSheetModel hansForSubjectOfBalanceSheetModel:subject] message:nil ok:NSLocalizedString(@"Confirm", nil) handler:^(UIAlertController *bAlert, UIAlertAction *action) {
        UITextField *tf = bAlert.textFields.firstObject;
        NSString *value = tf.text;
        if (value.length == 0) {
            return;
        }
        if (requireFloat) {
            if (!_fs_isPureFloat(value)) {
                [FSToast show:@"请输入正确的数字"];
                return;
            }
        }
        [FSRuntime setValue:value forPropertyName:subject ofObject:self->_model];
        if (update) {
            FSDBMaster *master = [FSDBMaster sharedInstance];
            NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET %@ = '%@' WHERE aid = %@;",_tb_bs_vanke,subject,value,self->_model.aid];
            NSString *error = [master updateSQL:sql];
            if (error) {
                [FSUIKit showAlertWithMessage:error controller:self];
                return;
            }
        }
        
        NSArray *ips = @[indexPath];
        [tableView reloadRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationAutomatic];
    } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:^(UITextField *textField) {
        textField.keyboardType = requireFloat?UIKeyboardTypeDecimalPad:UIKeyboardTypeDefault;
        if (update) {
            NSString *value = [FSRuntime valueForGetSelectorWithPropertyName:subject object:self->_model];
            if (![value isEqualToString:@"-1"]) {
                textField.text = value;
            }
        }
    } completion:nil];
}

-(BOOL)navigationShouldPopOnBackButton{
    if (_mode == FSSubjectModeDefault) {
        return YES;
    }
    NSString *notice = @"正在录值，退出将需要重新录入";
    NSString *exit = @"退出";
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:notice message:nil actionTitles:@[exit] styles:@[@(UIAlertActionStyleDestructive)] handler:^(UIAlertAction *action) {
        [self.navigationController popViewControllerAnimated:YES];
    }];
    return NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
