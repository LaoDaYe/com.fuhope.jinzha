//
//  FSCompanyValueController.h
//  Expand
//
//  Created by Fudongdong on 2017/11/21.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSBalanceSheetModel.h"
#import <UIKit/UIKit.h>

@interface FSCompanyValueController : UIViewController

@property (nonatomic,strong) FSBalanceSheetModel    *model;

@end
