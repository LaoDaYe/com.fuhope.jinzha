//
//  FSBonusController.m
//  myhome
//
//  Created by FudonFuchina on 2017/11/22.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSBonusController.h"
#import "FSDBMaster.h"
#import "FSBonusModel.h"
#import <FSUIKit.h>
#import <FSRuntime.h>
#import "FSMacro.h"

@interface FSBonusController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;
@property (nonatomic,assign) BOOL           isUpdate;

@end

@implementation FSBonusController{
    UIBarButtonItem     *_bbi;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"记录分红";
    if (_model) {
        _isUpdate = YES;
    }else{
        _model = [FSBonusModel new];
    }
    [self bonusDesignViews];
}

- (void)bonusDesignViews{
    if (!_tableView) {
        _bbi = [[UIBarButtonItem alloc] initWithTitle:@"增加" style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
        _bbi.enabled = _model.year && _model.cash;
        self.navigationItem.rightBarButtonItem = _bbi;
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 55;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:_tableView];
        
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-64-[_tableView]-0-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_tableView)]];
    }
}

- (void)bbiAction{
    if (_isUpdate) {
        FSBonusController *b = [[FSBonusController alloc] init];
        b.name = _model.name;
        [self.navigationController pushViewController:b animated:YES];
        return;
    }
    if (!_fs_isValidateString(_name)) {
        return;
    }
    if (!_fs_isValidateString(_model.year)) {
        return;
    }
    if (!_fs_isValidateString(_model.cash)) {
        return;
    }
    FSDBMaster *master = [FSDBMaster sharedInstance];    
    NSString *error = [master insert_fields_values:@{
                                                     @"time":@(_fs_integerTimeIntevalSince1970()),
                                                     @"name":_name,
                                                     @"year":_model.year,
                                                     @"cash":_model.cash
                                                     } table:_tb_bs_bonus];
    
    if (error) {
        [FSUIKit showAlertWithMessage:error controller:self];
        return;
    }
    [FSToast show:@"增加成功"];
    [FSKit popToController:@"FSCompanyValueController" navigationController:self.navigationController animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        cell.textLabel.font = [UIFont systemFontOfSize:16];
    }
    cell.textLabel.text = indexPath.row?@"金额/亿":@"年份";
    cell.detailTextLabel.text = indexPath.row?_model.cash:_model.year;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    __weak typeof(self)this = self;
    [FSUIKit alertInput:1 controller:self title:indexPath.row?@"金额/亿":@"年份" message:nil ok:NSLocalizedString(@"Confirm", nil) handler:^(UIAlertController *bAlert, UIAlertAction *action) {
        UITextField *tf = bAlert.textFields.firstObject;
        NSString *value = tf.text;
        if (value.length == 0) {
            return;
        }
        if (indexPath.row) {
            if (!_fs_isPureFloat(value)) {
                [FSToast show:@"请输入正确的数字"];
                return;
            }
            this.model.cash = value;
        }else{
            this.model.year = value;
        }
        NSString *subject = indexPath.row?@"cash":@"year";
        [FSRuntime setValue:value forPropertyName:subject ofObject:this.model];
        if (this.isUpdate) {
            FSDBMaster *master = [FSDBMaster sharedInstance];
            NSString *sql = [[NSString alloc] initWithFormat:@"UPDATE %@ SET %@ = '%@' WHERE aid = %@;",_tb_bs_bonus,subject,value,this.model.aid];
            NSString *error = [master updateSQL:sql];
            if (error) {
                [FSUIKit showAlertWithMessage:error controller:this];
                return;
            }
        }
        
        NSArray *ips = @[indexPath];
        [tableView reloadRowsAtIndexPaths:ips withRowAnimation:UITableViewRowAnimationAutomatic];
        if (!this.isUpdate) {
            [this checkEnabled];
        }
    } cancel:NSLocalizedString(@"Cancel", nil) handler:nil textFieldConifg:^(UITextField *textField) {
        textField.keyboardType = indexPath.row?UIKeyboardTypeDecimalPad:UIKeyboardTypeNumberPad;
        textField.text = indexPath.row?this.model.cash:this.model.year;
    } completion:nil];
}

- (void)checkEnabled{
    BOOL year = _fs_isPureInt(_model.year) && _model.year.length == 4;
    BOOL cash = _fs_isPureFloat(_model.cash);
    _bbi.enabled = year && cash;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
