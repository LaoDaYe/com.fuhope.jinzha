//
//  FSHTMLController.m
//  ShareEconomy
//
//  Created by fudon on 2016/9/1.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSHTMLController.h"
#import <WebKit/WebKit.h>
#import <FSKit.h>
#import <FSUIKit.h>
#import "FuSoft.h"
#import "FSToast.h"

#define ScriptMessageName_FlowMeter   @"FlowMeter"

@interface FSHTMLController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler>

@property (nonatomic,assign) BOOL           isDesignedSuccess;
@property (nonatomic,strong) WKWebView      *webView;

@end

@implementation FSHTMLController

- (void)viewDidDisappear:(BOOL)animated
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [super viewDidDisappear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (!_isDesignedSuccess) {
        _isDesignedSuccess = YES;
        [self webViewDesignViews];
    }
}

- (void)webViewDesignViews
{
    if ( _localUrlString == nil) {
        return;
    }
    
    NSURL *fileURL = [NSURL fileURLWithPath:_localUrlString];
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.preferences = [[WKPreferences alloc] init];
    config.preferences.minimumFontSize = 10;    // 默认为零
    config.preferences.javaScriptEnabled = YES;
    config.preferences.javaScriptCanOpenWindowsAutomatically = YES;
    
    _webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) configuration:config];
    _webView.navigationDelegate = self;
    _webView.UIDelegate = self;
    [self.view addSubview:_webView];
        
    if (IOSGE(9)) {
        // iOS9. One year later things are OK.
        [_webView loadFileURL:fileURL allowingReadAccessToURL:fileURL];
    }else{
        // iOS8. Things can be workaround-ed
        //   Brave people can do just this
        //   fileURL = try! pathForBuggyWKWebView8(fileURL)
        //   webView.loadRequest(NSURLRequest(URL: fileURL))
        
        NSURL *fileURL = [FSKit fileURLForBuggyWKWebView8:[NSURL fileURLWithPath:_localUrlString]];
        NSURLRequest *request = [NSURLRequest requestWithURL:fileURL];
        [_webView loadRequest:request];
    }
}

- (void)copyUrlAddress{
    NSString *urlString = _webView.URL.absoluteString;
    [FSKit copyToPasteboard:urlString];
    NSString *text = [[NSString alloc] initWithFormat:@"网址已经复制到粘贴板:\n%@",urlString];
    [FSUIKit showAlertWithMessage:text controller:self];
}

#pragma mark WKWebView_NavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSString *urlString = navigationAction.request.URL.absoluteString;
    if ([urlString hasPrefix:@"file://"]) {
        decisionHandler(WKNavigationActionPolicyAllow);
    }else if ([urlString hasPrefix:@"tel:"]) {
        NSRange range = [urlString rangeOfString:@"tel:"];
        NSString *phone = [urlString substringFromIndex:range.length];
        [FSKit call:phone];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([urlString hasPrefix:@"sms:"]){
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([urlString hasPrefix:@"mailto:"]){
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if (navigationAction.targetFrame == nil){ // 解决a标签link不跳转
        [webView loadRequest:navigationAction.request];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([urlString isEqualToString:@"about:blank"]) {
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([self isOpenApp:urlString]){
        decisionHandler(WKNavigationActionPolicyCancel);
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
    }else if ([urlString containsString:@"itunes.apple.com"]){
        if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:urlString]]) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
        }
        decisionHandler(WKNavigationActionPolicyCancel);
    }else{
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
{
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    //    [self showTitle:@"didReceiveServerRedirect"];
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    [FSToast show:error.localizedDescription];
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation
{
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *__nullable credential))completionHandler
{
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView NS_AVAILABLE(10_11, 9_0)
{
    //    [self showTitle:@"ProcessDidTerminate"];
}

#pragma mark UIDelegate

- (nullable WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures
{
    configuration.preferences = [[WKPreferences alloc] init];
    configuration.preferences.minimumFontSize = 10;    // 默认为零
    configuration.preferences.javaScriptEnabled = YES;
    configuration.preferences.javaScriptCanOpenWindowsAutomatically = YES;
    
    WKWebView *newWebView = [[WKWebView alloc] initWithFrame:webView.frame configuration:configuration];
    [newWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:webView.URL.absoluteString]]];
    return newWebView;
}

- (void)webViewDidClose:(WKWebView *)webView
{
    [FSToast show:@"webViewDidClose"];
}

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Confirm", nil)
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action) {
                                                          completionHandler();
                                                      }]];
    [self presentViewController:alertController animated:YES completion:^{
    }];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL result))completionHandler
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Confirm", nil)
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction *action) {
                                                          completionHandler(YES);
                                                      }]];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil)
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action){
                                                          completionHandler(NO);
                                                      }]];
    [self presentViewController:alertController animated:YES completion:^{
    }];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * __nullable result))completionHandler
{
    completionHandler(@"Client Not handler");
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    // NSLog(@"message.body:%@",message.body);// 支持NSNumber,NSString,NSDate,NSArray,NSDictionary,NSNull
    if ([message.name isEqualToString:ScriptMessageName_FlowMeter]) {
        //        NSString *string = message.body;
        //        NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
        //        NSData *urlData = [_urlString dataUsingEncoding:NSUTF8StringEncoding];
        ////        NSDictionary *dic = @{Swizzle_URLString:_urlString,Swizzle_Read:@(data.length),Swizzle_Write:@(urlData.length),Swizzle_Name:self.name?self.name:@"未知"};
        //        [[NSNotificationCenter defaultCenter] postNotificationName:FlowMeter_HasGetWebDataNotification object:dic];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString:@"estimatedProgress"]) {

    }
}

- (BOOL)isOpenApp:(NSString *)string
{
    NSString *pipei = @"://";
    if (![string containsString:pipei]) {
        return NO;
    }
    
    NSArray *array = [string componentsSeparatedByString:pipei];
    if (array.count < 2) {
        return NO;
    }
    NSString *frontString = array[0];
    if ([frontString isEqualToString:@"http"] || [frontString isEqualToString:@"https"] || [frontString isEqualToString:@"ftp"]) {
        return NO;
    }
    return YES;
}

- (void)dealloc
{
    FSLog(@"");
    _webView.UIDelegate = nil;
    _webView.navigationDelegate = nil;
    _webView.scrollView.delegate = nil;  //这里不释放会导致pop时崩溃.fdd.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
