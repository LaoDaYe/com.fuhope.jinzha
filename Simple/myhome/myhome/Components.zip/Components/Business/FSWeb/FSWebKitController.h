//
//  FSWebKitController.h
//  myhome
//
//  Created by FudonFuchina on 2017/1/4.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FSWebKitController : UIViewController

@property (nonatomic,copy) NSString     *urlString;         // 网页URL

@end
