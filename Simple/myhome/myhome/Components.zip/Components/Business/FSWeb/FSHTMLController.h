//
//  FSHTMLController.h
//  ShareEconomy
//
//  Created by fudon on 2016/9/1.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSBaseController.h"

@interface FSHTMLController : FSBaseController

@property (nonatomic,copy) NSString     *localUrlString;    // 本地URL

@end
