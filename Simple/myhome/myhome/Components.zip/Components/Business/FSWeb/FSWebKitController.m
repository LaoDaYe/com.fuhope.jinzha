//
//  FSWebKitController.m
//  myhome
//
//  Created by FudonFuchina on 2017/1/4.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#import "FSWebKitController.h"
#import <WebKit/WebKit.h>
#import "FuSoft.h"
#import "FSLeftItem.h"
#import "FSWBView.h"
#import "FSShare.h"
#import "FSDBMaster.h"
#import "FSUrlModel.h"
#import "FSDBTool.h"
#import <FSUIKit.h>

#define ScriptMessageName_FlowMeter   @"FlowMeter"

@interface FSWebKitController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler,UIScrollViewDelegate>

@property (nonatomic,strong) UIView             *progressView;
@property (nonatomic,strong) WKWebView          *webView;
@property (nonatomic,strong) UIBarButtonItem    *closeBBI;

@end

@implementation FSWebKitController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)viewDidDisappear:(BOOL)animated{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [_webView.configuration.userContentController removeScriptMessageHandlerForName:ScriptMessageName_FlowMeter];// 不移除会无法释放
    [super viewDidDisappear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (!_webView) {
        [self webViewDesignViews];
    }
}

- (void)bbiAction:(UIBarButtonItem *)bbi{
    if (bbi == _closeBBI){
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self.view endEditing:YES];
        
        FSWBView *wbView = [[FSWBView alloc] initWithFrame:CGRectZero controller:self];
        wbView.titleLabel.text = self.webView.URL.absoluteString;
        [self.navigationController.view addSubview:wbView];
        WEAKSELF(this);
        wbView.block = ^ (FSWBView *bView,NSInteger bIndex){
            switch (bIndex) {
                case 0:{
                    [this.navigationController popViewControllerAnimated:YES];
                }break;
                case 1:{
                    [this.webView reload];
                }break;
                case 2:{
                    [this copyUrlAddress];
                }break;
                case 3:{
                    NSString *urlString = this.webView.URL.absoluteString;
                    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:urlString]]) {
                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
                    }else{
                        [FSUIKit showAlertWithMessage:@"不能打开" controller:self];
                    }
                }break;
                case 4:{
                    [FSShare wxUrlShareTitle:this.webView.title description:this.webView.title url:this.webView.URL.absoluteString];
                }break;
                case 5:{
                    [FSUIKit alert:UIAlertControllerStyleAlert controller:this title:@"确定收藏？" message:@"将会添加到[导航]" actionTitles:@[@"收藏"] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
                        FSDBMaster *master = [FSDBMaster sharedInstance];
                        NSString *error = [master insert_fields_values:@{
                                                                         @"time":@(_fs_integerTimeIntevalSince1970()),
                                                                         @"name":this.webView.title,
                                                                         @"url":this.webView.URL.absoluteString,
                                                                         @"type":@"默认分类",
                                                                         @"count":@0
                                                                         } table:_tb_url];
                        
                        if (!error) {
                            [FSToast show:@"收藏成功"];
                        }
                    }];
                }break;
                case 6:{
                    [FSShare emailShareWithSubject:this.webView.title on:this messageBody:[[NSString alloc] initWithFormat:@"%@ > %@",this.webView.title,this.webView.URL.absoluteString] recipients:nil fileData:nil fileName:nil mimeType:nil];
                }break;
                case 7:{
                    [FSShare messageShareWithMessage:[[NSString alloc] initWithFormat:@"%@ > %@",this.webView.title,this.webView.URL.absoluteString] on:this recipients:nil data:nil fileName:nil fileType:nil];
                }break;
                default:
                    break;
            }
        };
    }
}

- (void)webViewDesignViews{
    BOOL validate = _fs_isValidateString(_urlString);
    if (!validate) {
        NSAssert(validate == YES, @"url为空");
        return;
    }
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    WEAKSELF(this);
    FSLeftItem *item = [[FSLeftItem alloc] initWithFrame:CGRectMake(0, 20, 44, 44)];
    item.textLabel.text = @"返回";
    item.tapBlock = ^ (){
        [this popActionBase];
    };
    UIBarButtonItem *backBBI = [[UIBarButtonItem alloc] initWithCustomView:item];
    _closeBBI = [[UIBarButtonItem alloc] initWithTitle:@"关闭" style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction:)];
    [_closeBBI setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:16],NSFontAttributeName, nil] forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItems = @[backBBI,_closeBBI];
    
    UIBarButtonItem *rBBI = [[UIBarButtonItem alloc] initWithTitle:@"..." style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction:)];
    self.navigationItem.rightBarButtonItem = rBBI;
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.preferences = [[WKPreferences alloc] init];
    config.preferences.minimumFontSize = 10;    // 默认为零
    config.preferences.javaScriptEnabled = YES;
    config.preferences.javaScriptCanOpenWindowsAutomatically = YES;
    
    //        NSString *js = @"window.webkit.messageHandlers.observe.postMessage(document.body.innerText);";
    NSString *js = @"window.webkit.messageHandlers.FlowMeter.postMessage(document.getElementsByTagName('html')[0].innerHTML);";
    WKUserScript *scriptUser = [[WKUserScript alloc] initWithSource:js injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
    config.userContentController = [[WKUserContentController alloc] init];
    [config.userContentController addUserScript:scriptUser];
    [config.userContentController addScriptMessageHandler:self name:ScriptMessageName_FlowMeter];
    
    NSURL *url = [NSURL URLWithString:_urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30];
    
    _webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64) configuration:config];
    _webView.navigationDelegate = self;
    _webView.UIDelegate = self;
    _webView.scrollView.delegate = self;
    [_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:NULL];
    [_webView loadRequest:request];
    [self.view addSubview:_webView];
    
    _progressView = [[UIView alloc] initWithFrame:CGRectMake(0, 64 + (FS_iPhone_X * 22), 0, 2)];
    _progressView.backgroundColor = THISCOLOR;
    [self.navigationController.view addSubview:_progressView];
}

- (void)popActionBase{
    if ([_webView canGoBack]) {
        NSArray *list = _webView.backForwardList.backList;
        if (list.count) {
            WKBackForwardListItem *item = list[list.count - 1];
            [_webView goToBackForwardListItem:item];
        }else{
            [self.navigationController popViewControllerAnimated:YES];
        }
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)copyUrlAddress{
    NSString *urlString = _webView.URL.absoluteString;
    [FSKit copyToPasteboard:urlString];
    NSString *text = [[NSString alloc] initWithFormat:@"网址已经复制到粘贴板:\n%@",urlString];
    [FSUIKit showAlertWithMessage:text controller:self];
}

#pragma mark WKWebView_NavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    NSString *urlString = navigationAction.request.URL.absoluteString;
    if ([urlString hasPrefix:@"tel:"]) {
        NSRange range = [urlString rangeOfString:@"tel:"];
        NSString *phone = [urlString substringFromIndex:range.length];
        [FSKit call:phone];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([urlString hasPrefix:@"sms:"]){
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if (navigationAction.targetFrame == nil){ // 解决a标签link不跳转
        [webView loadRequest:navigationAction.request];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([urlString isEqualToString:@"about:blank"]) {
        decisionHandler(WKNavigationActionPolicyCancel);
    }else if ([self isOpenApp:urlString]){
        decisionHandler(WKNavigationActionPolicyCancel);
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
    }else if ([urlString containsString:@"itunes.apple.com"]){
        if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:urlString]]) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
        }
        decisionHandler(WKNavigationActionPolicyCancel);
    }else{
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    [FSUIKit showAlertWithMessage:error.localizedDescription controller:self];
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation{
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    self.title = webView.title;
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    _progressView.width = 0;
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *__nullable credential))completionHandler{
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView NS_AVAILABLE(10_11, 9_0){
}

#pragma mark UIDelegate

- (nullable WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures{
//    configuration.preferences = [[WKPreferences alloc] init];
//    configuration.preferences.minimumFontSize = 10;    // 默认为零
//    configuration.preferences.javaScriptEnabled = YES;
//    configuration.preferences.javaScriptCanOpenWindowsAutomatically = YES;
//    
//    WKWebView *newWebView = [[WKWebView alloc] initWithFrame:webView.frame configuration:configuration];
//    [newWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:webView.URL.absoluteString]]];
//    return newWebView;
    
    WKFrameInfo *frameInfo = navigationAction.targetFrame;
    if (![frameInfo isMainFrame]) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}

- (void)webViewDidClose:(WKWebView *)webView{
    [FSToast show:@"webViewDidClose"];
}

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Confirm", nil)
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action) {
                                                          completionHandler();
                                                      }]];
    [self presentViewController:alertController animated:YES completion:^{
    }];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL result))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:message
                                                                             message:nil
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Confirm", nil)
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction *action) {
                                                          completionHandler(YES);
                                                      }]];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil)
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction *action){
                                                          completionHandler(NO);
                                                      }]];
    [self presentViewController:alertController animated:YES completion:^{
    }];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * __nullable result))completionHandler{
    completionHandler(@"Client Not handler");
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
    // NSLog(@"message.body:%@",message.body);// 支持NSNumber,NSString,NSDate,NSArray,NSDictionary,NSNull
    if ([message.name isEqualToString:ScriptMessageName_FlowMeter]) {
        //        NSString *string = message.body;
        //        NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
        //        NSData *urlData = [_urlString dataUsingEncoding:NSUTF8StringEncoding];
        ////        NSDictionary *dic = @{Swizzle_URLString:_urlString,Swizzle_Read:@(data.length),Swizzle_Write:@(urlData.length),Swizzle_Name:self.name?self.name:@"未知"};
        //        [[NSNotificationCenter defaultCenter] postNotificationName:FlowMeter_HasGetWebDataNotification object:dic];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        WKWebView *webView = object;
        if (webView.estimatedProgress < .8) {
            self.progressView.width = webView.estimatedProgress * WIDTHFC;
        }else{
            self.progressView.width = 0;
        }
    }
}

- (BOOL)isOpenApp:(NSString *)string{
    NSString *pipei = @"://";
    if (![string containsString:pipei]) {
        return NO;
    }
    
    NSArray *array = [string componentsSeparatedByString:pipei];
    if (array.count < 2) {
        return NO;
    }
    NSString *frontString = array[0];
    if ([frontString isEqualToString:@"http"] || [frontString isEqualToString:@"https"] || [frontString isEqualToString:@"ftp"]) {
        return NO;
    }
    return YES;
}

- (void)dealloc{
#if DEBUG
    FSLog(@"");
#endif
    [_progressView removeFromSuperview];
    _progressView = nil;
    
    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
    _webView.UIDelegate = nil;
    _webView.navigationDelegate = nil;
    _webView.scrollView.delegate = nil;  //这里不释放会导致pop时崩溃.fdd.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
