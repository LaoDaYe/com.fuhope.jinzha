//
//  FSShareAppController.m
//  Expand
//
//  Created by Fudongdong on 2017/10/17.
//  Copyright © 2017年 china. All rights reserved.
//

#import "FSShareAppController.h"
#import "FSTrackKeys.h"
#import "FSShare.h"
#import <FSUIKit.h>
#import <FSCalculator.h>
#import "FSToast.h"
#import "FSMacro.h"

@interface FSShareAppController ()

@end

@implementation FSShareAppController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self shareAppDesignViews];
}

- (void)shareAppDesignViews{
    self.title = @"推荐给微信朋友";
    self.scrollView.backgroundColor = [UIColor whiteColor];
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(shareAction)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(30, 60, 90, 90)];
    imageView.layer.cornerRadius = 10;
    imageView.clipsToBounds = YES;
    imageView.image = [UIImage imageNamed:@"logo_share"];
    [self.scrollView addSubview:imageView];
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(135, imageView.top, 100, 30)];
    nameLabel.font = [UIFont boldSystemFontOfSize:18];
    nameLabel.text = [[NSString alloc] initWithFormat:@"%@(zha)",[FSKit appName]];
    [self.scrollView addSubview:nameLabel];
    
    NSString *dl = @"记账，密码管理，记朋友生日等";
    CGSize size = [UIScreen mainScreen].bounds.size;
    CGFloat h = [FSCalculator textHeight:dl font:FONTFC(14) labelWidth:size.width - 120 - 15];
    h = MAX(h, 30);
    UILabel *descLabel = [[UILabel alloc] initWithFrame:CGRectMake(135, nameLabel.bottom, size.width - 135 - 30, h)];
    descLabel.font = [UIFont systemFontOfSize:14];
    descLabel.textColor = [UIColor grayColor];
    descLabel.numberOfLines = 0;
    descLabel.text = dl;
    [self.scrollView addSubview:descLabel];
    
    NSString *str = [[NSString alloc] initWithFormat:@"Hi，分享给你一个不错的软件，去App Store搜索%@(根据logo识别哈)下载。它可以记账，记朋友生日等很多不错的功能，着重保护您的个人隐私数据，希望你会喜欢。",[FSKit appName]];
    NSString *point = [FSKit appName];
    NSAttributedString *attr = [FSKit attributedStringFor:str strings:@[point] color:APPCOLOR fontStrings:nil font:nil];
    CGFloat height = [FSCalculator textHeight:str font:FONTFC(15) labelWidth:size.width - 60];
    UILabel *noteLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, imageView.bottom + 30, size.width - 60, height)];
    noteLabel.font = [UIFont systemFontOfSize:15];
    noteLabel.numberOfLines = 0;
    noteLabel.attributedText = attr;
    [self.scrollView addSubview:noteLabel];

    static UIImage *qrImg = nil;
    if (!qrImg) {
        qrImg = [FSUIKit QRImageFromString:[self appstoreLink]];
    }
    UIImageView *qrImage = [[UIImageView alloc] initWithFrame:CGRectMake(size.width / 2 - 100, noteLabel.frame.origin.y + noteLabel.frame.size.height + 20, 200, 200)];
    qrImage.image = qrImg;
    [self.scrollView addSubview:qrImage];
    
    self.scrollView.contentSize = CGSizeMake(WIDTHFC, MAX(HEIGHTFC + 10, qrImage.bottom + 30));
}

- (void)shareAction{
    NSString *friends = @"分享图片";
    NSString *zone = @"分享链接";
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:NSLocalizedString(@"Please share to your friends", nil) message:nil actionTitles:@[friends,zone] styles:@[@(UIAlertActionStyleDefault),@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        [FSTrack event:_UMeng_Event_share_confirm];
        if ([action.title isEqualToString:friends]) {
            UIImage *image = [FSUIKit captureScrollView:self.scrollView];
            [FSShare wxImageShareActionWithImage:image controller:self result:^(NSString *bResult) {
                [FSToast show:@"分享成功"];
            }];
        }else if ([action.title isEqualToString:zone]){
            [FSShare wxUrlShareTitle:[FSKit appName] description:@"Hi，推荐一个不错的app，打开链接下载吧" url:[self appstoreLink]];
        }
    }];
}

- (NSString *)appstoreLink{
    return @"https://itunes.apple.com/app/id1291692536";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
