//
//  FSSqlite3BroswerController.h
//  FSKit_Example
//
//  Created by Fudongdong on 2018/2/6.
//  Copyright © 2018年 topchuan. All rights reserved.
//

#import "FSBaseController.h"

@interface FSSqlite3BroswerController : FSBaseController

@property (nonatomic,copy) NSString     *path;

@end
