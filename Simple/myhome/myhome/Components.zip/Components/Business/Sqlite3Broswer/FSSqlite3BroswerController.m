//
//  FSSqlite3BroswerController.m
//  FSKit_Example
//
//  Created by Fudongdong on 2018/2/6.
//  Copyright © 2018年 topchuan. All rights reserved.
//

#import "FSSqlite3BroswerController.h"
#import "FSKit.h"
#import "FSDBMaster.h"
#import "FSSqlite3DataController.h"
#import "FSDBSupport.h"
#import "FSUIKit.h"

@interface FSSqlite3BroswerController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView    *tableView;

@end

@implementation FSSqlite3BroswerController{
@private    NSArray *_tables;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self sqlite3HandleDatas];
}

- (void)sqlite3HandleDatas{
//    NSFileManager *manager = [NSFileManager defaultManager];
//    BOOL fileExist = [manager fileExistsAtPath:_path];
//    if (!fileExist) {
//        [FSKit showAlertWithMessage:@"文件不存在" controller:self];
//        return;
//    }
//    NSString *lastComponent = [self.path lastPathComponent];
//    self.title = lastComponent;
    
    FSDBMaster *master = [FSDBMaster sharedInstance];
    _tables = [master allTables];
    [self sqlite3DesignViews];
}

- (void)sqlite3DesignViews{
    if (!_tableView) {
        self.title = [[NSString alloc] initWithFormat:@"%@个表",@(_tables.count)];
        
        CGSize size = [UIScreen mainScreen].bounds.size;
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, size.width, size.height - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _tables.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    NSString *table = [_tables objectAtIndex:indexPath.row];
    cell.textLabel.text = table;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    BOOL what = YES;
    if (what) {
        [self pushToData:indexPath.row];
        return;
    }
    static NSString *option1 = @"添加sid字段";
    static NSString *option2 = @"查看每条数据";
    NSNumber *type = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[option1,option2] styles:@[type,type] handler:^(UIAlertAction *action) {
        if ([action.title isEqualToString:option1]) {
//            [self actionHandle:indexPath.row];
        }else if ([action.title isEqualToString:option2]){
            [self pushToData:indexPath.row];
        }
    }];
}

- (void)actionHandle:(NSInteger)index{
    FSDBMaster *master = [FSDBMaster sharedInstance];
    NSString *table = [_tables objectAtIndex:index];
    NSArray<NSDictionary *> *fs = [master allFields:table];
    for (NSDictionary *f in fs) {
        NSString *fn = [f objectForKey:@"field_name"];
        if ([fn isEqualToString:@"sid"]) {
            [FSToast show:@"sid字段已存在"];
            return;
        }
    }
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:@"给表添加字段:sid?" message:nil actionTitles:@[@"确定"] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        NSString *error = [FSDBSupport addField:@"sid" defaultValue:@"0" toTable:table];
        if (error) {
            [FSUIKit showAlertWithMessage:error controller:self];
        }else{
            NSString *sql = [[NSString alloc] initWithFormat:@"SELECT * FROM %@",table];
            NSArray *list = [master querySQL:sql tableName:table];
            for (NSDictionary *dic in list) {
                NSString *nSQL = [[NSString alloc] initWithFormat:@"UPDATE %@ SET sid = '%@' WHERE aid = %@;",table,dic[@"aid"],dic[@"aid"]];
                NSString *e = [master updateSQL:nSQL];
                if (e) {
                    [FSUIKit showAlertWithMessage:e controller:self];
                    return;
                }
            }
        }
        [FSToast show:@"处理完成"];
    }];
    
}

- (void)pushToData:(NSInteger)index{
    NSString *table = [_tables objectAtIndex:index];
    FSSqlite3DataController *data = [[FSSqlite3DataController alloc] init];
    data.table = table;
    [self.navigationController pushViewController:data animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
