//
//  FSQRController.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/5/14.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSQRController.h"
#import <AVFoundation/AVFoundation.h>
#import "FSQRResultController.h"
#import "FSWebKitController.h"
#import "FSDBExportHelper.h"
#import <FSUIKit.h>
#import <FSAVKit.h>
#import "FSKit.h"
#import "FuSoft.h"
#import "FSViewManager.h"
#import "UIViewExt.h"

@interface FSQRController ()<AVCaptureMetadataOutputObjectsDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (nonatomic, strong) AVCaptureSession          *captureSession;
@property (nonatomic, strong) AVCaptureMetadataOutput   *captureOutput;
@property (nonatomic, strong) UIImageView               *sweepLineView;/**< 扫描条 */
@property (nonatomic, strong) UIView                    *zoneBackView;

@end

@implementation FSQRController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (self.captureSession) {
        [self.captureSession startRunning];
    }
}

- (void)openPhotoLibrary{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Tips", nil) message:NSLocalizedString(@"Please [Set-privacy-photos] open it", nil) actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
//            NSString *urlString = @"prefs:root=Privacy&path=PHOTOS";
//            NSURL *url = [NSURL URLWithString:urlString];
//            UIApplication *app = [UIApplication sharedApplication];
//            if ([app canOpenURL:url]) {
//                [app openURL:url];
//            }
        }];
        return;
    }
    [self.captureSession stopRunning];

    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)makeQRCode{
     NSString *photoLibrary = NSLocalizedString(@"From Album", nil);
     NSString *makeORCode = NSLocalizedString(@"Make QRCode", nil);
    NSNumber *type = @(UIAlertActionStyleDefault);
    [FSUIKit alert:UIAlertControllerStyleActionSheet controller:self title:nil message:nil actionTitles:@[makeORCode,photoLibrary] styles:@[type,type] handler:^(UIAlertAction *action) {
        if ([action.title isEqualToString:photoLibrary]) {
            [self openPhotoLibrary];
        }else if ([action.title isEqualToString:makeORCode]){
            [FSKit pushToViewControllerWithClass:@"FSMakeQRController" navigationController:self.navigationController param:nil configBlock:nil];
        }
    }];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"QRCode", nil);
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(makeQRCode)];
    self.navigationItem.rightBarButtonItem = bbi;

    if ([[AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo] count] <= 0) {
        [FSUIKit showAlertWithMessage:NSLocalizedString(@"Your device don't support to take a picture", nil) controller:self];
        return;
    }
    
    if([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo] == AVAuthorizationStatusDenied) {
        [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Tips", nil) message:NSLocalizedString(@"Please [Set-privacy-photos] open it", nil) actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
        }];
        return;
    }
    
    AVCaptureDevice  *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    AVCaptureDeviceInput *captureInput = [AVCaptureDeviceInput deviceInputWithDevice:captureDevice error:nil];
    self.captureOutput = [[AVCaptureMetadataOutput alloc] init];
    [_captureOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    self.captureSession = [[AVCaptureSession alloc] init];
    [_captureSession setSessionPreset:AVCaptureSessionPresetHigh];
    
    if ([_captureSession canAddInput:captureInput]) {
        [_captureSession addInput:captureInput];
    }
    
    if ([_captureSession canAddOutput:_captureOutput]) {
        [_captureSession addOutput:_captureOutput];
    }
//    _captureOutput.metadataObjectTypes = @[AVMetadataObjectTypeQRCode];
    
    //扫码类型
    [_captureOutput setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode,        //二维码
                                     AVMetadataObjectTypeCode39Code,            //条形码   韵达和申通
                                     AVMetadataObjectTypeCode128Code,           //CODE128条码  顺丰用的
                                     AVMetadataObjectTypeCode39Mod43Code,
                                     AVMetadataObjectTypeEAN13Code,
                                     AVMetadataObjectTypeEAN8Code,
                                     AVMetadataObjectTypeCode93Code,            //条形码,星号来表示起始符及终止符,如邮政EMS单上的条码
                                     AVMetadataObjectTypeUPCECode]];
    
    CGRect rect = CGRectMake((WIDTHFC - 250) / 2, (HEIGHTFC - 250 - 72)/2, 250, 250);
    AVCaptureVideoPreviewLayer *previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:_captureSession];
    previewLayer.frame = CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64);
    previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer addSublayer:previewLayer];
    
    _captureOutput.rectOfInterest = [previewLayer metadataOutputRectOfInterestForRect:rect];
    [_captureSession startRunning];
    
    UIView *maskView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, WIDTHFC, HEIGHTFC - 64)];
    maskView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
    [self.view addSubview:maskView];
    
    UIBezierPath *rectPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, WIDTHFC, HEIGHTFC)];
    //    [rectPath appendPath:[[UIBezierPath bezierPathWithRect:CM((SCREEN_WIDTH - 250) / 2, 66, 250, 250)] bezierPathByReversingPath]];
    [rectPath appendPath:[[UIBezierPath bezierPathWithRoundedRect:CGRectMake((WIDTHFC - 250) / 2, (HEIGHTFC - 250 - 72)/2 - 64, 250, 250) cornerRadius:1] bezierPathByReversingPath]];
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = rectPath.CGPath;
    maskView.layer.mask = shapeLayer;
    
    _zoneBackView = [[UIView alloc] initWithFrame:rect];
    [self.view addSubview:_zoneBackView];
    UILabel *label = [FSViewManager labelWithFrame:CGRectMake(rect.origin.x,rect.origin.y - 25, rect.size.width, 20) text:NSLocalizedString(@"Let QRCode be in the frame", nil) textColor:[UIColor whiteColor] backColor:nil font:nil textAlignment:NSTextAlignmentCenter];
    label.font = FONTFC(13);
    [self.view addSubview:label];
    
    UIButton *lightButton = [FSViewManager buttonWithFrame:CGRectMake(WIDTHFC / 2 - 25, _zoneBackView.bottom + 20, 50, 50) title:nil titleColor:nil backColor:nil fontInt:0 tag:0 target:self selector:@selector(lightButtonClick:)];
    [lightButton setImage:[UIImage imageNamed:@"fsqrlightoff"] forState:UIControlStateNormal];
    [lightButton setImage:[UIImage imageNamed:@"fsqrlighton"] forState:UIControlStateSelected];
    [self.view addSubview:lightButton];
    
    for (int x = 0; x < 4; x ++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((x % 2) * (_zoneBackView.width - 20), (x / 2) * (_zoneBackView.height - 20), 20, 20)];
        NSString *imageName = [[NSString alloc] initWithFormat:@"fsqr%d",1 + x];
        imageView.image = [UIImage imageNamed:imageName];
        [_zoneBackView addSubview:imageView];
    }
    
    self.sweepLineView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 20, 230, 30)];
    _sweepLineView.image = [UIImage imageNamed:@"fsqrline"];
    [_zoneBackView addSubview:_sweepLineView];
    [self sweepAnimation];
}

- (void)sweepAnimation{
    WEAKSELF(this);
    [UIView animateWithDuration:2 animations:^{
        [this sweepBusiness];
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:2 animations:^{
            [this sweepLineBusiness];
        } completion:^(BOOL finished) {
            [this sweepAnimation];
        }];
    }];
}

- (void)sweepBusiness{
    _sweepLineView.top = _zoneBackView.height - _sweepLineView.height * 2;
}

- (void)sweepLineBusiness{
    _sweepLineView.top = 0;
}

#pragma mark AVCaptureMetadataOutputObjectsDelegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    if (metadataObjects != nil && [metadataObjects count] > 0) {
        [self.captureSession stopRunning];
        [FSAVKit playSongs:@"fsqrmsg" type:@"wav"];
        
        AVMetadataMachineReadableCodeObject *metadataObj = [metadataObjects objectAtIndex:0];
        if ([[metadataObj type] isEqualToString:AVMetadataObjectTypeQRCode]) {
            
            NSString *valueString = [metadataObj stringValue];
            valueString = [FSKit urlDecodedString:valueString];
            
            BOOL isWebPage = [FSKit isURLString:valueString];
            BOOL isPhone = (valueString.length == 11 && _fs_isPureInt(valueString));
            WEAKSELF(this);
            if (isWebPage) {
                [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"It may be a link", nil) message:valueString actionTitles:@[NSLocalizedString(@"Open", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
                    FSWebKitController *webController = [[FSWebKitController alloc] init];
                    webController.urlString = valueString;
                    [this.navigationController pushViewController:webController animated:YES];
                } cancelTitle:NSLocalizedString(@"Cancel", nil) cancel:^(UIAlertAction *action) {
                    [this.captureSession startRunning];
                } completion:nil];
            }else if (isPhone){
                [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"It may be a phone NO.", nil) message:valueString actionTitles:@[NSLocalizedString(@"Call", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
                    [FSKit callPhoneWithNoNotice:valueString];
                } cancelTitle:NSLocalizedString(@"Cancel", nil) cancel:^(UIAlertAction *action) {
                    [this.captureSession startRunning];
                } completion:nil];
            }else{
                NSString *json = [FSKit textFromBase64String:valueString];
                NSDictionary *dic = [FSKit objectFromJSonstring:json];
                if ([dic isKindOfClass:NSDictionary.class]) {
                    [this handleDictionary:dic];
                }else{
                    [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Result", nil) message:valueString actionTitles:@[NSLocalizedString(@"Confirm", nil)] styles:@[@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
                        [this.captureSession startRunning];
                    } cancelTitle:NSLocalizedString(@"Cancel", nil) cancel:^(UIAlertAction *action) {
                        [this.captureSession startRunning];
                    } completion:nil];
                }
            }
        }else{
            NSString *valueString = [metadataObj stringValue];
            [FSUIKit showAlertWithTitle:[metadataObj type] message:valueString ok:@"OK" controller:self handler:nil];
        }
    }
}

- (void)handleDictionary:(NSDictionary *)dic{
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    [picker dismissViewControllerAnimated:YES completion:^{
        UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
        NSString *result = [FSKit scanQRCode:image];
        if (_fs_isValidateString(result)) {
            FSQRResultController *vc = [[FSQRResultController alloc] init];
            vc.text = result;
            [self.navigationController pushViewController:vc animated:YES];
        }else{
            [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"The qr code is not recognized", nil) message:NSLocalizedString(@"Please scan next one", nil) actionTitles:nil styles:nil handler:nil cancelTitle:@"OK" cancel:nil completion:nil];
        }
    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:^{
        [self.captureSession startRunning];
    }];
}

- (void)lightButtonClick:(UIButton *)button{
    button.selected = !button.selected;
    if (button.isSelected) {
        if (![self isLightOpened]) {
            [self openLight:YES];
        }
    }else{
        if ([self isLightOpened]) {
            [self openLight:NO];
        }
    }
}

//闪光灯
- (BOOL)isLightOpened{
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType: AVMediaTypeVideo];
    if (![device hasTorch]) {
        return NO;
    }else{
        if ([device torchMode] == AVCaptureTorchModeOn) {
            return YES;
        } else {
            return NO;
        }
    }
}

- (void)openLight:(BOOL)open{
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType: AVMediaTypeVideo];//[self.reader.readerView device];
    if (![device hasTorch]) {
    } else {
        if (open) {
            // 开启闪光灯
            if(device.torchMode != AVCaptureTorchModeOn ||
               device.flashMode != AVCaptureFlashModeOn){
                [device lockForConfiguration:nil];
                [device setTorchMode:AVCaptureTorchModeOn];
                [device setFlashMode:AVCaptureFlashModeOn];
                [device unlockForConfiguration];
            }
        } else {
            // 关闭闪光灯
            if(device.torchMode != AVCaptureTorchModeOff ||
               device.flashMode != AVCaptureFlashModeOff){
                [device lockForConfiguration:nil];
                [device setTorchMode:AVCaptureTorchModeOff];
                [device setFlashMode:AVCaptureFlashModeOff];
                [device unlockForConfiguration];
            }
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
