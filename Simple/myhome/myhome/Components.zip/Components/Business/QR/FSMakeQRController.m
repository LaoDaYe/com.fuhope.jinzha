//
//  FSMakeQRController.m
//  ShareEconomy
//
//  Created by FudonFuchina on 16/7/3.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSMakeQRController.h"
#import "FSShare.h"
#import <FSUIKit.h>
#import "FuSoft.h"
#import "UIViewExt.h"
#import "FSToast.h"
#import "FSTrackKeys.h"

@interface FSMakeQRController ()<UITextViewDelegate>

@property (nonatomic,strong) UITextView             *textView;
@property (nonatomic,strong) UIImageView            *imageView;

@end

@implementation FSMakeQRController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Make QRCode", nil);
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Make", nil) style:UIBarButtonItemStylePlain target:self action:@selector(makeAQRCode)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    _textView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, WIDTHFC - 20, 200)];
    _textView.delegate = self;
    _textView.backgroundColor = [UIColor clearColor];
    [self.scrollView addSubview:_textView];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self->_textView becomeFirstResponder];
    });
    
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, _textView.bottom + 20, WIDTHFC - 40, WIDTHFC - 40)];
    _imageView.userInteractionEnabled = YES;
    [self.scrollView addSubview:_imageView];
    CGFloat offset = _imageView.bottom + 20;
    [self addKeyboardNotificationWithBaseOn:offset];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapClickImage)];
    [_imageView addGestureRecognizer:tap];
}

- (void)tapClickImage{
    [self saveAction];
}

- (void)saveAction{
    [self.view endEditing:YES];
    if (!_imageView.image) {
        return;
    }
    NSString *toAlbum = NSLocalizedString(@"Save to album", nil);
    NSString *toWechat = NSLocalizedString(@"Send to Wechat", nil);
    [FSUIKit alert:UIAlertControllerStyleAlert controller:self title:NSLocalizedString(@"Save", nil) message:nil actionTitles:@[toWechat,toAlbum] styles:@[@(UIAlertActionStyleDefault),@(UIAlertActionStyleDefault)] handler:^(UIAlertAction *action) {
        if ([action.title isEqualToString:toAlbum]) {
            UIImageWriteToSavedPhotosAlbum(self->_imageView.image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
        }else if ([action.title isEqualToString:toWechat]){
            [FSShare wxImageShareActionWithImage:self->_imageView.image controller:self result:nil];
        }
    }];
}

- (void)makeAQRCode{
    [FSTrack event:_UMeng_Event_makeQR];
    [self.view endEditing:YES];
    if (_textView.text.length == 0) {
        return;
    }
    UIImage *image = [FSUIKit QRImageFromString:_textView.text];
    if (!image) {
        [FSUIKit showAlertWithMessage:NSLocalizedString(@"Failure to generate may be too many characters", nil) controller:self];
        return;
    }
    _imageView.image = image;
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *) error contextInfo:(void *)contextInfo{
    if (error) {
        [FSToast show:error.localizedDescription];
    }else{
        [FSToast show:NSLocalizedString(@"Save to album successfully", nil)];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
