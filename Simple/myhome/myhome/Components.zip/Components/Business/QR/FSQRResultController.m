//
//  FSQRResultController.m
//  myhome
//
//  Created by FudonFuchina on 2016/12/23.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSQRResultController.h"
#import "FSKit.h"
#import "FuSoft.h"
#import "FSToast.h"

@interface FSQRResultController ()

@end

@implementation FSQRResultController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"扫描结果";
    
    [self resultDesignViews];
}

- (void)bbiAction{
    if (_text) {
        [FSKit copyToPasteboard:_text];
        [FSToast show:@"复制成功"];
    }
}

- (void)resultDesignViews{
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.view.backgroundColor = RGBCOLOR(46, 49, 50, 1);
    
    UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithTitle:@"复制" style:UIBarButtonItemStylePlain target:self action:@selector(bbiAction)];
    self.navigationItem.rightBarButtonItem = bbi;
    
    UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, WIDTHFC, HEIGHTFC - 64 - 50)];
    textView.backgroundColor = [UIColor whiteColor];
    textView.text = self.text;
    textView.editable = NO;
    [self.scrollView addSubview:textView];
    
//    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
//    button.frame = CGRectMake(0, HEIGHTFC - 50, WIDTHFC, 50);
//    button.titleLabel.font = [UIFont systemFontOfSize:16];
//    button.backgroundColor = THISCOLOR;
//    [button setTitle:@"我要解析" forState:UIControlStateNormal];
//    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [button addTarget:self action:@selector(parseData) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:button];
}

- (void)parseData{
    [FSToast show:@"待完善"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
