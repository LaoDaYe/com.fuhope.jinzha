//
//  FSQRResultController.h
//  myhome
//
//  Created by FudonFuchina on 2016/12/23.
//  Copyright © 2016年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSQRResultController : FSBaseController

@property (nonatomic,copy) NSString     *text;

@end
