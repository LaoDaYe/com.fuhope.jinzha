//
//  FSMakeQRController.h
//  ShareEconomy
//
//  Created by FudonFuchina on 16/7/3.
//  Copyright © 2016年 FudonFuchina. All rights reserved.
//

#import "FSBaseController.h"

@interface FSMakeQRController : FSBaseController

@end
