//
//  AppConfiger.h
//  myhome
//
//  Created by FudonFuchina on 2017/11/5.
//  Copyright © 2017年 fuhope. All rights reserved.
//

#ifndef AppConfiger_h
#define AppConfiger_h

static NSString *_Watch_Account  = @"";

static NSString *_appCfg_receivedEmail = @"cfgEmail";   // 文件导出的接收邮箱
static NSString *_appCfg_pdfPassword = @"cfgpdf";       // 导出的Pdf文件的密码
static NSString *_appCfg_lockTime = @"cfglock";         // app退到后台需要重新输入密码的时间

#endif /* AppConfiger_h */
