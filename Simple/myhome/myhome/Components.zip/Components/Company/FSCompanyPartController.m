//
//  FSCompanyPartController.m
//  myhome
//
//  Created by FudonFuchina on 2018/1/24.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSCompanyPartController.h"
#import <FSTuple.h>
#import "FSImageLabelView.h"
#import "FSAccountsController.h"
#import "FSCompanyOverviewController.h"
#import "FSInventoryController.h"
#import "FSGestureController.h"
#import "FSABOverviewController.h"
#import "FSKit.h"
#import "FSTrackKeys.h"
#import "FSToast.h"
#import "FSUseGestureView+Factory.h"

typedef NS_ENUM(NSInteger, FSActionType) {
    FSActionTypeInventoryControl = 1,           //  库存管理
    FSActionTypeAccountCompany = 2,             //  公司账本
    FSActionTypeAccountPerson = 3,              //  个人账本
    FSActionTypeCompany = 4,                    //  公司
    FSActionTypeEncrypt = 5,                    //  加密
    FSActionTypeDouying = 6,                    //
};

@interface FSCompanyPartController ()

@end

@implementation FSCompanyPartController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self companyDesignViews];
}

- (void)companyDesignViews{
    self.title = NSLocalizedString(@"Development", nil);
    
#if DEBUG
    NSArray *ts = @[
                    [Tuple3 v1:NSLocalizedString(@"Account",nil) v2:@"apps_write" v3:@(FSActionTypeAccountPerson)],
                    [Tuple3 v1:NSLocalizedString(@"Account",nil) v2:@"apps_write" v3:@(FSActionTypeAccountCompany)],
                    [Tuple3 v1:@"地址" v2:@"apps_counter" v3:@(FSActionTypeInventoryControl)],
                    [Tuple3 v1:@"公司" v2:@"loanCounter_logo" v3:@(FSActionTypeCompany)],
                    [Tuple3 v1:@"二维码" v2:@"saoma_too" v3:@(FSActionTypeEncrypt)],
                    [Tuple3 v1:@"二维码" v2:@"saoma_too" v3:@(FSActionTypeDouying)],
                    ];
#else
    NSArray *ts = @[
                    [Tuple3 v1:NSLocalizedString(@"Account",nil) v2:@"apps_write" v3:@(FSActionTypeAccountPerson)],
//                    [Tuple3 v1:@"地址" v2:@"apps_counter" v3:@(FSActionTypeInventoryControl)],
//                    [Tuple3 v1:@"二维码" v2:@"saoma_too" v3:@(FSActionTypeEncrypt)],
                    ];
#endif
    
    CGFloat width = (WIDTHFC - 100) / 4;
    WEAKSELF(this);
    for (int x = 0; x < ts.count; x ++) {
        Tuple3 *t = ts[x];
        FSImageLabelView *imageView = [FSImageLabelView imageLabelViewWithFrame:CGRectMake(20 + (x % 4) * (width + 20), 40 + (x / 4) * (width + 45), width, width + 25) imageName:t._2 text:t._1];
        imageView.block = ^ (FSImageLabelView *bImageLabelView){
            [this actionForType:t];
        };
        [self.scrollView addSubview:imageView];
    }
}

- (void)actionForType:(Tuple3 *)t{
    if ([t._3 integerValue] == 5) {
        [self actionForTypeEvent:t];
    }else{
        [FSUseGestureView verify:self.tabBarController.view success:^(FSUseGestureView *view) {
            [self actionForTypeEvent:t];
        }];
    }
}

- (void)actionForTypeEvent:(Tuple3 *)t{
    FSActionType type = [t._3 integerValue];
    switch (type) {
        case FSActionTypeAccountPerson:{
            [self pushToAccount:2];
        }break;
        case FSActionTypeAccountCompany:{
            [self pushToAccount:1];
        }break;
        case FSActionTypeInventoryControl:{
            [FSKit pushToViewControllerWithClass:@"FSLocationController" navigationController:self.navigationController param:nil configBlock:nil];
        }break;
        case FSActionTypeCompany:{
            [FSKit pushToViewControllerWithClass:@"FSCompanyController" navigationController:self.navigationController param:nil configBlock:nil];
        }break;
        case FSActionTypeEncrypt:{
            [FSKit pushToViewControllerWithClass:@"FSQRController" navigationController:self.navigationController param:nil configBlock:nil];
            [FSTrack event:_UMeng_Event_scanQR];
        }break;
        case FSActionTypeDouying:{
            [FSKit pushToViewControllerWithClass:@"FSDouyingController" navigationController:self.navigationController param:nil configBlock:nil];
        }break;
        default:
            break;
    }
}

- (void)pushToAccount:(NSInteger)type{
    FSAccountsController *accounts = [[FSAccountsController alloc] init];
    accounts.type = type;
    [self.navigationController pushViewController:accounts animated:YES];
    __weak typeof(self)this = self;
    accounts.push = ^(NSString *table, NSString *name) {
        if (type == 1) {
            FSCompanyOverviewController *company = [[FSCompanyOverviewController alloc] init];
            company.accountName = table;
            company.title = name;
            [this.navigationController pushViewController:company animated:YES];
        }else if (type == 3){
            FSInventoryController *i = [[FSInventoryController alloc] init];
            i.table = table;
            i.title = name;
            [this.navigationController pushViewController:i animated:YES];
        }else if (type == 2){
            FSABOverviewController *door = [[FSABOverviewController alloc] init];
            door.accountName = table;
            door.title = name;
            [this.navigationController pushViewController:door animated:YES];
            [FSToast show:@"这个账本将不再维护，请使用首页的账本"];
        }
    };
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
