//
//  FSCompanyPartController.h
//  myhome
//
//  Created by FudonFuchina on 2018/1/24.
//  Copyright © 2018年 fuhope. All rights reserved.
//

#import "FSBaseController.h"

@interface FSCompanyPartController : FSBaseController

@end
